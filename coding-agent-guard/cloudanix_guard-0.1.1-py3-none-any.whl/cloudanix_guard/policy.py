"""Policy engine — the 6-mode enforcement spectrum.

Takes a list of :class:`Finding` from the inspector and a YAML policy
file, and produces a :class:`Decision` carrying one of six modes:

- ``observe``               — log only, no friction
- ``warn_continue``         — log + dev-visible nudge, pass through
- ``redact``                — rewrite the sensitive span in place, continue
- ``warn_self_justify``     — block until the user grants a self-exception (Phase B)
- ``warn_external_approve`` — block until an external approver consents (Phase D)
- ``block``                 — hard stop, no override

Two of the six (``warn_self_justify`` / ``warn_external_approve``) are
new in Phase A. The approval-store infrastructure for them lands in
Phase B / D — until then the engine routes them through ``block``
with a mode-specific stderr hint.

Schema (see ``config/policy.yaml``):

    default_mode: observe              # when no rule matches and no override fires
    logging:      prudent              # or `verbose`

    # Layer 1 — defaults by (type, severity)
    modes:
      secret:
        critical: block
        high:     warn_self_justify
        medium:   redact
        low:      warn_continue
      pii:
        ...

    # Layer 2 — per-rule overrides (optional)
    rule_overrides:
      secret/openai-api-key:        block
      secret/generic-high-entropy-hex:  warn_continue
      pii/ipv4:                     observe

"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

import yaml

from cloudanix_guard.inspector.types import Finding, FindingType, Severity


# ─── Mode enum ────────────────────────────────────────────────────

class Mode(str, Enum):
    """The 6-mode enforcement spectrum.

    Order in the enum mirrors strictness ordering; :meth:`rank` is what
    the decide loop actually consults. New modes go between the
    existing ones — DO NOT reorder.
    """

    OBSERVE = "observe"
    WARN_CONTINUE = "warn_continue"
    REDACT = "redact"
    WARN_SELF_JUSTIFY = "warn_self_justify"
    WARN_EXTERNAL_APPROVE = "warn_external_approve"
    BLOCK = "block"

    def rank(self) -> int:
        """Higher rank = stricter. Used by the strictest-wins resolver."""
        return _MODE_RANK[self]

    def is_blocking(self) -> bool:
        """True if this mode currently produces exit-2 from the hook.

        In Phase A, the two new modes degrade to blocking (Phase B / D
        add the approval-store check that lets them pass through when
        an active exception exists)."""
        return self in (Mode.BLOCK, Mode.WARN_SELF_JUSTIFY, Mode.WARN_EXTERNAL_APPROVE)


_MODE_RANK: Dict[Mode, int] = {
    Mode.OBSERVE: 0,
    Mode.WARN_CONTINUE: 1,
    Mode.REDACT: 2,
    Mode.WARN_SELF_JUSTIFY: 3,
    Mode.WARN_EXTERNAL_APPROVE: 4,
    Mode.BLOCK: 5,
}


# ─── Logging granularity ─────────────────────────────────────────

class LoggingMode(str, Enum):
    """Controls which decision events get pushed to the audit / telemetry.

    Set on the policy (not per-device) so an admin can dial it
    consistently across the fleet.

    - ``prudent`` (default): only events with findings OR a non-trivial
      mode. Clean-allow events are skipped — gives the security team
      the audit-worthy bits without "user typed 47 prompts today"
      surveillance.
    - ``verbose``: every hook invocation, regardless. Use when
      compliance demands full coverage.

    Neither mode logs raw prompt content. NF-PRIV-1 is absolute.
    """

    PRUDENT = "prudent"
    VERBOSE = "verbose"


# ─── Decision ────────────────────────────────────────────────────

@dataclass
class Decision:
    """The outcome of applying policy to a set of findings.

    .. note::

       The field is named ``mode`` (Phase A rename from ``action``).
       Old callers reading ``decision.action`` need to update to
       ``decision.mode``; the wire format JSON field is also ``mode``.
    """

    mode: Mode
    reasons: List[str] = field(default_factory=list)
    findings: List[Finding] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "mode": self.mode.value,
            "reasons": self.reasons,
            "findings": [f.to_dict() for f in self.findings],
        }


# ─── Inline bypass (in-prompt directive) config ──────────────────

@dataclass
class InlineBypassConfig:
    """Controls the `cloudanix:allow` in-prompt directive surface.

    The directive lets a developer say "yes, this is expected" without
    leaving their editor — paid for with a logged, time-bounded,
    rule-scoped exception. Security teams can disable it entirely or
    restrict which rule classes it covers (default: PII only; secrets
    keep the side-band CLI path).
    """

    enabled: bool = True
    max_ttl_seconds: int = 3600           # 1 hour cap regardless of request
    default_ttl_seconds: int = 300        # 5 minutes if request omits one
    allowed_rules: List[str] = field(default_factory=lambda: ["pii/*"])
    require_reason_min_chars: int = 5
    # How long a stashed pending-block stays valid for the no-args
    # `cloudanix:allow` autofill. Beyond this, the autofill rejects
    # with a clear message and the user has to type the full directive
    # (or trigger a fresh block). Default matches default_ttl_seconds
    # so the mental model is "the resolution lives as long as the
    # grant it would produce".
    pending_block_max_age_seconds: int = 300

    def rule_is_allowed(self, rule: str) -> bool:
        rule = (rule or "").strip().lower()
        return any(fnmatch.fnmatchcase(rule, pat.lower()) for pat in self.allowed_rules)

    def validate(self, rule: str, ttl_seconds: int, reason: str) -> Optional[str]:
        """Return None if the directive passes the policy gate, else a
        short human-readable reason for the rejection. Caller surfaces
        the rejection text on the block stderr."""
        if not self.enabled:
            return "inline bypass is disabled by your org's policy"
        if not self.rule_is_allowed(rule):
            return f"rule {rule!r} is not bypassable inline; use `cloudanix-guard request-exception` instead"
        if len(reason.strip()) < self.require_reason_min_chars:
            return f"reason must be at least {self.require_reason_min_chars} chars"
        if ttl_seconds <= 0:
            return "ttl must be positive"
        return None

    def cap_ttl(self, requested_ttl_seconds: int) -> int:
        return min(requested_ttl_seconds, self.max_ttl_seconds)


# ─── Read content scan config ────────────────────────────────────

@dataclass
class ReadContentScanConfig:
    """Controls the proactive file-content scan on `PreToolUse` Read.

    Without this, the hook only sees the *path* on a Read tool call.
    Anything not on the path catalog (``passwords.txt``, ``notes.md``
    with embedded API keys, …) would slip past the firewall and end
    up in the LLM's next callback with no further hook event to
    intercept. With this on, the hook reads up to ``max_scan_bytes``
    of the file and feeds it through the regular inspector chain so
    the existing secrets / PII / Presidio / Gitleaks scanners can fire
    on real content.

    Trade-offs:
    - ``max_scan_bytes`` bounds the per-call I/O cost. Files over the
      cap are skipped (allowed without scan; logged to telemetry so the
      audit trail is honest about coverage).
    - Cache keyed on ``(path, mtime, size)`` keeps re-reads cheap.
    - Binaries are skipped via a magic-byte check — they don't trip
      text scanners anyway and would just waste CPU.
    """

    enabled: bool = True
    max_scan_bytes: int = 102_400  # 100 KB
    skip_binary: bool = True
    cache_enabled: bool = True
    cache_ttl_seconds: int = 3600
    cache_max_entries: int = 2000
    # Path-allowlist for the proactive Read scan. Default (empty list)
    # means "use the runtime default" — cwd-ancestry + $HOME. An
    # explicit list overrides; set e.g. ["/home/dev/work", "/tmp"] to
    # narrow scan scope. Refusing to scan paths outside this list is
    # what keeps the guard from becoming an exfil oracle for
    # /etc/shadow / /proc/self/environ / other users' homes.
    allow_roots: List[str] = field(default_factory=list)


def _parse_read_content_scan(raw) -> ReadContentScanConfig:
    """Best-effort parse of the ``read_content_scan`` YAML block.

    Missing or malformed values fall back to the dataclass defaults.
    An explicit ``enabled: false`` reverts to path-only Read behaviour.
    """
    cfg = ReadContentScanConfig()
    if not isinstance(raw, dict):
        return cfg
    if "enabled" in raw:
        cfg.enabled = bool(raw["enabled"])
    if "max_scan_bytes" in raw:
        try:
            cfg.max_scan_bytes = max(0, int(raw["max_scan_bytes"]))
        except (TypeError, ValueError):
            pass
    if "skip_binary" in raw:
        cfg.skip_binary = bool(raw["skip_binary"])
    if "allow_roots" in raw and isinstance(raw["allow_roots"], list):
        cfg.allow_roots = [str(p) for p in raw["allow_roots"] if p]
    cache_raw = raw.get("cache")
    if isinstance(cache_raw, dict):
        if "enabled" in cache_raw:
            cfg.cache_enabled = bool(cache_raw["enabled"])
        if "ttl_seconds" in cache_raw:
            try:
                cfg.cache_ttl_seconds = max(0, int(cache_raw["ttl_seconds"]))
            except (TypeError, ValueError):
                pass
        if "max_entries" in cache_raw:
            try:
                cfg.cache_max_entries = max(0, int(cache_raw["max_entries"]))
            except (TypeError, ValueError):
                pass
    return cfg


# ─── PolicyEngine ────────────────────────────────────────────────

class PolicyEngine:
    """Apply a YAML policy to a list of findings."""

    def __init__(
        self,
        modes: Dict[FindingType, Dict[Severity, Mode]],
        default_mode: Mode = Mode.OBSERVE,
        rule_overrides: Optional[Dict[str, Mode]] = None,
        logging_mode: LoggingMode = LoggingMode.PRUDENT,
        inline_bypass: Optional[InlineBypassConfig] = None,
        read_content_scan: Optional[ReadContentScanConfig] = None,
    ):
        self._modes = modes
        self._default = default_mode
        self._rule_overrides = rule_overrides or {}
        self._logging_mode = logging_mode
        self._inline_bypass = inline_bypass or InlineBypassConfig()
        self._read_content_scan = read_content_scan or ReadContentScanConfig()

    # ---------------------------------------------------------------- factory

    @classmethod
    def from_yaml(cls, path: str | Path) -> "PolicyEngine":
        raw = yaml.safe_load(Path(path).read_text()) or {}

        default_mode = Mode(str(raw.get("default_mode", "observe")).strip().lower())

        # Layer 1 — type/severity defaults.
        modes: Dict[FindingType, Dict[Severity, Mode]] = {}
        for type_name, severities in (raw.get("modes") or {}).items():
            if not severities:
                continue
            ftype = FindingType(type_name)
            modes[ftype] = {
                Severity(sev): Mode(str(mode_name).strip().lower())
                for sev, mode_name in severities.items()
            }

        # Layer 2 — per-rule overrides.
        rule_overrides: Dict[str, Mode] = {
            str(rule_id): Mode(str(mode_name).strip().lower())
            for rule_id, mode_name in (raw.get("rule_overrides") or {}).items()
        }

        # Logging granularity — defaults to prudent.
        logging_raw = raw.get("logging") or "prudent"
        try:
            logging_mode = LoggingMode(str(logging_raw).strip().lower())
        except ValueError:
            logging_mode = LoggingMode.PRUDENT

        # Inline bypass — optional block. Missing or malformed falls
        # back to defaults; an explicit `enabled: false` disables.
        inline_bypass = _parse_inline_bypass(raw.get("inline_bypass"))

        # Read-content scan — optional block. Defaults are on; an
        # explicit `enabled: false` reverts to path-only behaviour.
        read_content_scan = _parse_read_content_scan(raw.get("read_content_scan"))

        return cls(
            modes,
            default_mode,
            rule_overrides,
            logging_mode,
            inline_bypass,
            read_content_scan,
        )

    @classmethod
    def default(cls) -> "PolicyEngine":
        """Load the active policy. Prefers the synced cache at
        ``~/.cloudanix-guard/policy.yaml`` when present; falls back
        to the packaged default otherwise.

        The cached file is written by ``sync.py`` after a successful
        ``GET /v2/coding_agent_guard/policy`` against the console.
        """
        # Late import — config_file's `config_dir` is the one place
        # the override env var is honoured (tests use it).
        from cloudanix_guard.config_file import config_dir
        cached = config_dir() / "policy.yaml"
        if cached.exists():
            return cls.from_yaml(cached)
        default_path = Path(__file__).resolve().parent / "config" / "policy.yaml"
        return cls.from_yaml(default_path)

    # ---------------------------------------------------------------- properties

    @property
    def logging_mode(self) -> LoggingMode:
        return self._logging_mode

    @property
    def inline_bypass(self) -> InlineBypassConfig:
        return self._inline_bypass

    @property
    def read_content_scan(self) -> ReadContentScanConfig:
        return self._read_content_scan

    # ---------------------------------------------------------------- decide

    def decide(self, findings: List[Finding]) -> Decision:
        """Resolve all findings into a single mode.

        Strictest mode across all findings wins. Reasons from every
        finding that contributed to the chosen mode are preserved for
        audit and developer feedback.
        """
        if not findings:
            return Decision(mode=self._default)

        chosen = Mode.OBSERVE
        reasons: List[str] = []
        contributing: List[Finding] = []

        for f in findings:
            mode = self._mode_for(f)
            if mode.rank() > chosen.rank():
                chosen = mode
                reasons = [self._reason(f, mode)]
                contributing = [f]
            elif mode.rank() == chosen.rank() and mode is not Mode.OBSERVE:
                reasons.append(self._reason(f, mode))
                contributing.append(f)

        if chosen is Mode.OBSERVE:
            # All findings resolved to observe — surface them so the
            # caller can still record them under verbose logging.
            return Decision(mode=Mode.OBSERVE, findings=findings)

        return Decision(mode=chosen, reasons=reasons, findings=contributing)

    # ---------------------------------------------------------------- helpers

    def _mode_for(self, f: Finding) -> Mode:
        """Layer 2 (rule override) wins over Layer 1 (type/severity).

        Rule-override key is ``"<type>/<rule_id>"``. Falls back through:
        the per-(type, severity) table, then the engine's default mode.
        """
        override_key = f.qualified_rule_id
        if override_key in self._rule_overrides:
            return self._rule_overrides[override_key]
        # Some scanners may produce a finding whose rule_id already
        # includes a "scanner/" prefix (e.g. "presidio/email_address"
        # has type=PII rule_id="presidio/email_address"). Try the
        # rule_id alone too — supports overrides like
        # `presidio/email_address: redact`.
        if f.rule_id in self._rule_overrides:
            return self._rule_overrides[f.rule_id]

        by_type = self._modes.get(f.type)
        if not by_type:
            return self._default
        return by_type.get(f.severity, self._default)

    @staticmethod
    def _reason(f: Finding, mode: Mode) -> str:
        where = f.source
        return (
            f"[{mode.value}] {f.type.value}/{f.severity.value} "
            f"{f.rule_id} in {where}: {f.message}"
        )


def _parse_inline_bypass(raw) -> InlineBypassConfig:
    """Best-effort parse of the `inline_bypass` YAML block. Unknown
    keys are ignored; absent or malformed values fall back to defaults."""
    if not isinstance(raw, dict):
        return InlineBypassConfig()
    cfg = InlineBypassConfig()
    if "enabled" in raw:
        cfg.enabled = bool(raw["enabled"])
    if "max_ttl_seconds" in raw:
        try:
            cfg.max_ttl_seconds = int(raw["max_ttl_seconds"])
        except (TypeError, ValueError):
            pass
    if "default_ttl_seconds" in raw:
        try:
            cfg.default_ttl_seconds = int(raw["default_ttl_seconds"])
        except (TypeError, ValueError):
            pass
    if "allowed_rules" in raw and isinstance(raw["allowed_rules"], list):
        cfg.allowed_rules = [str(p) for p in raw["allowed_rules"] if p]
    if "require_reason_min_chars" in raw:
        try:
            cfg.require_reason_min_chars = int(raw["require_reason_min_chars"])
        except (TypeError, ValueError):
            pass
    if "pending_block_max_age_seconds" in raw:
        try:
            cfg.pending_block_max_age_seconds = int(raw["pending_block_max_age_seconds"])
        except (TypeError, ValueError):
            pass
    return cfg


