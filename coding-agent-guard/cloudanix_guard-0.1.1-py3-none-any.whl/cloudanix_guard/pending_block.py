"""Pending-block stash for the in-prompt ``cloudanix:allow`` autofill
shortcut.

When the hook produces a blocking decision (block / warn_self_justify /
warn_external_approve / redact-on-hook), we stash a small JSON
descriptor of what just blocked. The next ``UserPromptSubmit`` whose
directive is the no-args form (``cloudanix:allow`` alone on the first
non-empty line) consumes that stash and auto-fills the rule + a default
TTL + a synthesized reason — turning a 4-step "leave session → write
directive → resend → ask agent to retry" flow into a one-word resend.

Design properties (T16 — see project docs for the full rationale):

- **One stash file per profile.** Lives in ``config_dir()`` so the
  T13 profile primitive isolates it automatically. Newest block wins
  on overwrite (the last-block-wins semantic the user signed off on).
- **Time-bounded.** Reads older than ``max_age_seconds`` return
  ``None`` and self-clean. Default 5 min, configurable via
  ``inline_bypass.pending_block_max_age_seconds``.
- **Single-use.** A successful consume deletes the file, so a stale
  re-fire of ``cloudanix:allow`` doesn't double-grant.
- **No secrets ever touch this file.** It carries rule name, source
  label, tool name, timestamp, hook event, mode — categorical
  metadata only. Safe for the audit trail.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from cloudanix_guard.config_file import config_dir


def _path() -> Path:
    return config_dir() / "pending_block.json"


def stash(
    *,
    rule: str,
    source_label: str,
    tool_name: Optional[str],
    hook_event: Optional[str],
    mode_value: str,
) -> None:
    """Record what just blocked so the next no-args ``cloudanix:allow``
    can resolve it. Best-effort — any IO error is swallowed so the
    blocking decision itself is unaffected."""
    payload = {
        "rule": rule,
        "source_label": source_label or "",
        "tool_name": tool_name or "",
        "hook_event": hook_event or "",
        "mode": mode_value,
        "blocked_at": _iso_now(),
    }
    try:
        # Atomic rename + 0600 mode + 0700 parent — centralised in
        # _safe_io so every state file on disk carries the same
        # conservative permissions.
        from cloudanix_guard._safe_io import safe_atomic_write
        safe_atomic_write(_path(), json.dumps(payload) + "\n")
    except OSError:
        pass


def consume_if_fresh(max_age_seconds: int) -> Optional[dict]:
    """Read the stash, return its dict if not older than
    ``max_age_seconds``, and delete the file on a successful read.

    Returns ``None`` if the stash is missing, malformed, or stale.
    Stale stashes are self-cleaned so the next read isn't fooled.
    """
    p = _path()
    if not p.exists():
        return None

    try:
        raw = p.read_text()
        payload = json.loads(raw) if raw.strip() else {}
    except (OSError, json.JSONDecodeError):
        _safely_unlink(p)
        return None

    blocked_at = payload.get("blocked_at")
    if not _is_fresh(blocked_at, max_age_seconds):
        _safely_unlink(p)
        return None

    _safely_unlink(p)
    return payload


def peek() -> Optional[dict]:
    """Read the stash without consuming it. Diagnostic helper —
    `status` could use this to surface 'there is a pending block
    waiting for cloudanix:allow' if we want to add it later. Returns
    ``None`` on missing / malformed."""
    p = _path()
    if not p.exists():
        return None
    try:
        raw = p.read_text()
        return json.loads(raw) if raw.strip() else None
    except (OSError, json.JSONDecodeError):
        return None


def peek_if_fresh(max_age_seconds: int) -> Optional[dict]:
    """Read the stash if it exists and isn't stale, without consuming.

    Stale stashes are self-cleaned (returned None and file removed)
    same as ``consume_if_fresh``; fresh stashes are returned but the
    file is left in place so the caller can ``clear()`` it only after
    the downstream grant actually succeeds.

    This is the "consume only on success" primitive: the older
    ``consume_if_fresh`` deletes on a successful read regardless of
    whether the caller could then act on it, which causes silent
    data-loss if validate or grant rejects.
    """
    p = _path()
    if not p.exists():
        return None

    try:
        raw = p.read_text()
        payload = json.loads(raw) if raw.strip() else {}
    except (OSError, json.JSONDecodeError):
        _safely_unlink(p)
        return None

    blocked_at = payload.get("blocked_at")
    if not _is_fresh(blocked_at, max_age_seconds):
        _safely_unlink(p)
        return None
    return payload


def clear() -> None:
    """Explicit deletion — exposed for tests and any future
    'cancel the pending block' surface."""
    _safely_unlink(_path())


# ─── helpers ──────────────────────────────────────────────────────

def _iso_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _is_fresh(blocked_at: Optional[str], max_age_seconds: int) -> bool:
    if not isinstance(blocked_at, str):
        return False
    try:
        when = datetime.fromisoformat(blocked_at)
    except ValueError:
        return False
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - when).total_seconds()
    return 0 <= age <= max_age_seconds


def _safely_unlink(p: Path) -> None:
    try:
        p.unlink(missing_ok=True)
    except OSError:
        pass
