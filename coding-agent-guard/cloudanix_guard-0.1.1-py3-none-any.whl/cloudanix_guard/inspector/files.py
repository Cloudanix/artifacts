"""Sensitive file-path scanner.

Emits a finding for any file in the payload whose *path* matches a
known-sensitive pattern (``.env``, SSH private keys, cloud credentials,
kubeconfigs, etc.), regardless of content.

Rationale: a `.env` file is sensitive by convention even if, in a
given moment, it happens to contain only innocuous settings. Blocking
on *path* is a cheap, high-precision signal.
"""

from __future__ import annotations

import fnmatch
import os
from dataclasses import dataclass
from typing import Iterable, List

from cloudanix_guard.inspector.types import (
    Finding,
    FindingType,
    Payload,
    Severity,
)


@dataclass
class FileRule:
    """A sensitive-file path rule."""

    id: str
    description: str
    severity: Severity
    # List of glob patterns, matched against the file's basename AND its
    # full path (so ``.env`` matches ``/foo/bar/.env`` and ``.env.local``).
    patterns: List[str]

    @classmethod
    def from_dict(cls, raw: dict) -> "FileRule":
        return cls(
            id=raw["id"],
            description=raw.get("description", raw["id"]),
            severity=Severity(raw.get("severity", "critical")),
            patterns=list(raw["patterns"]),
        )

    def matches(self, path: str) -> bool:
        basename = os.path.basename(path)
        for pat in self.patterns:
            if fnmatch.fnmatch(basename, pat) or fnmatch.fnmatch(path, pat):
                return True
        return False


class FilePathScanner:
    """Check each file path in the payload against a set of rules."""

    name = "files"

    def __init__(self, rules: Iterable[FileRule]):
        self._rules = list(rules)

    def scan(self, payload: Payload) -> List[Finding]:
        findings: List[Finding] = []
        for f in payload.files:
            path = f.get("path", "")
            if not path:
                continue
            for rule in self._rules:
                if rule.matches(path):
                    findings.append(
                        Finding(
                            rule_id=rule.id,
                            type=FindingType.FILE,
                            severity=rule.severity,
                            message=f"{rule.description} ({path})",
                            source=path,
                            start=None,
                            end=None,
                            match=None,
                            metadata={"scanner": self.name, "path": path},
                        )
                    )
        return findings
