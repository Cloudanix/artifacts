"""Presidio scanner — richer PII detection via Microsoft Presidio.

Wraps :class:`presidio_analyzer.AnalyzerEngine` so it slots into the
firewall as just another :class:`Scanner`. Entity types, confidence
threshold, and entity→severity mapping are all data in
``rules.yaml`` — code never needs to change to retune.

Heavy dependency by design: importing ``presidio_analyzer`` pulls
spaCy and a language model (~500MB). For that reason the import is
deferred until ``scan`` is first called, and the scanner advertises
itself as *available* only when the import succeeds. Configs that
enable Presidio on a machine without it installed get a single
informational note on stderr — no crash, no impact on the other
scanners.

Anti-noise defaults:
- ``score_threshold``: 0.85 (Presidio scores 0–1; below 0.85 is
  almost always false-positive territory for the entity types we ship).
- ``entities``: a curated allowlist focused on security-relevant PII
  (financial / health / identifiers). Generic categories like
  ``PERSON`` or ``LOCATION`` are off by default — they fire on almost
  every prompt and are usually not what a developer needs blocked.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from cloudanix_guard.inspector.types import (
    Finding,
    FindingType,
    Payload,
    Severity,
)


# Default entity → severity. Tunable in YAML; this is just the
# starting point so the scanner is usable out of the box.
_DEFAULT_ENTITY_SEVERITY: Dict[str, Severity] = {
    "CREDIT_CARD": Severity.HIGH,
    "US_SSN": Severity.HIGH,
    "US_BANK_NUMBER": Severity.HIGH,
    "US_ITIN": Severity.HIGH,
    "US_PASSPORT": Severity.HIGH,
    "US_DRIVER_LICENSE": Severity.HIGH,
    "IBAN_CODE": Severity.HIGH,
    "MEDICAL_LICENSE": Severity.HIGH,
    "CRYPTO": Severity.HIGH,
    "EMAIL_ADDRESS": Severity.MEDIUM,
    "PHONE_NUMBER": Severity.MEDIUM,
    "IP_ADDRESS": Severity.LOW,
    # Off by default — uncomment in YAML if you want them:
    # "PERSON": Severity.LOW,
    # "LOCATION": Severity.LOW,
    # "DATE_TIME": Severity.LOW,
    # "URL": Severity.LOW,
    # "NRP": Severity.LOW,
}


@dataclass
class PresidioConfig:
    """Configuration block parsed from ``rules.yaml``."""

    enabled: bool = False
    score_threshold: float = 0.85
    language: str = "en"
    # Subset of Presidio entity types to fire on. ``None`` means "use
    # the default keys of ``entity_severity``".
    entities: Optional[List[str]] = None
    # Entity name → severity. Drives policy routing.
    entity_severity: Dict[str, Severity] = field(
        default_factory=lambda: dict(_DEFAULT_ENTITY_SEVERITY)
    )

    @classmethod
    def from_dict(cls, raw: dict) -> "PresidioConfig":
        cfg = cls()
        cfg.enabled = bool(raw.get("enabled", False))
        if "score_threshold" in raw:
            cfg.score_threshold = float(raw["score_threshold"])
        if "language" in raw:
            cfg.language = str(raw["language"])
        # Allow YAML to override / extend the entity→severity map.
        if isinstance(raw.get("entity_severity"), dict):
            cfg.entity_severity = {
                str(k): Severity(v) for k, v in raw["entity_severity"].items()
            }
        if isinstance(raw.get("entities"), list):
            cfg.entities = [str(e) for e in raw["entities"]]
        return cfg

    def active_entities(self) -> List[str]:
        if self.entities:
            return list(self.entities)
        return list(self.entity_severity.keys())


class PresidioScanner:
    """Run Presidio's :class:`AnalyzerEngine` against a payload.

    Constructed lazily: the heavy ``AnalyzerEngine`` is built on the
    first ``scan`` call so module import stays cheap even when
    Presidio isn't actually used.
    """

    name = "presidio"

    def __init__(self, config: PresidioConfig):
        self._config = config
        self._analyzer = None  # lazily built
        self._unavailable_logged = False

    # ------------------------------------------------------------------ availability

    def _ensure_analyzer(self) -> bool:
        """Return True if the analyzer is ready, False if Presidio is missing."""
        if self._analyzer is not None:
            return True
        try:
            from presidio_analyzer import AnalyzerEngine  # type: ignore
        except ImportError:
            if not self._unavailable_logged:
                sys.stderr.write(
                    "cloudanix-guard: presidio enabled in rules but "
                    "'presidio_analyzer' is not importable. "
                    "Install with: pip install 'cloudanix-guard[presidio]' "
                    "(skipping presidio scanner)\n"
                )
                self._unavailable_logged = True
            return False
        try:
            self._analyzer = AnalyzerEngine()
        except Exception as e:  # spaCy model missing, etc.
            if not self._unavailable_logged:
                sys.stderr.write(
                    f"cloudanix-guard: presidio failed to initialise "
                    f"({e.__class__.__name__}: {e}). Skipping presidio scanner.\n"
                )
                self._unavailable_logged = True
            return False
        return True

    # ------------------------------------------------------------------ scan

    def scan(self, payload: Payload) -> List[Finding]:
        if not self._config.enabled:
            return []
        if not self._ensure_analyzer():
            return []

        findings: List[Finding] = []
        findings.extend(self._scan_text(payload.prompt, source="prompt"))
        for f in payload.files:
            findings.extend(
                self._scan_text(f.get("content", ""), source=f.get("path", "file"))
            )
        return findings

    # ------------------------------------------------------------------ internals

    def _scan_text(self, text: str, source: str) -> List[Finding]:
        if not text or self._analyzer is None:
            return []
        results = self._analyzer.analyze(
            text=text,
            language=self._config.language,
            entities=self._config.active_entities(),
            score_threshold=self._config.score_threshold,
        )
        out: List[Finding] = []
        for r in results:
            severity = self._config.entity_severity.get(r.entity_type, Severity.MEDIUM)
            out.append(
                Finding(
                    rule_id=f"presidio/{r.entity_type.lower()}",
                    type=FindingType.PII,
                    severity=severity,
                    message=f"Presidio: {r.entity_type} (score={r.score:.2f})",
                    source=source,
                    start=r.start,
                    end=r.end,
                    match=text[r.start:r.end],
                    metadata={
                        "scanner": self.name,
                        "entity": r.entity_type,
                        "score": round(float(r.score), 3),
                    },
                )
            )
        return out
