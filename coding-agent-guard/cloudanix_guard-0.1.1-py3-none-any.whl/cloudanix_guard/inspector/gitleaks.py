"""Gitleaks scanner — high-recall secret detection via the upstream Go binary.

We shell out to ``gitleaks detect`` because:

- The Go binary is the only authoritative implementation (rule set,
  entropy heuristics, allowlist syntax all live there).
- It is the same artefact security teams already trust in CI.
- A Python port would be perpetually out of date.

Wire-up
-------

For each scan call we materialise the payload (prompt + each attached
file's content) into a fresh temp directory and run::

    gitleaks detect --source <tmpdir> --no-git --no-banner \
                    --report-format json --report-path <out.json>

``--no-git`` makes gitleaks treat the directory as plain files instead
of a git tree. The JSON report contains line / column spans which we
translate to character offsets against the same content we wrote out,
so :mod:`enforce` can redact in place.

Behaviour when the binary is missing
------------------------------------

We do **not** make ``gitleaks`` a hard dependency — most dev machines
won't have it. If the binary isn't on ``$PATH`` we log one note to
stderr and return no findings. The rest of the firewall is unaffected.

Anti-noise default
------------------

Every gitleaks rule maps to ``Severity.MEDIUM`` unless overridden in
``rules.yaml``. Combined with the default policy
(``secret.medium → redact``) that means turning gitleaks on adds
redaction coverage but does not start blocking flows. Promote
individual rule IDs in the YAML map once you have a sense of the
noise profile.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from cloudanix_guard.inspector.types import (
    Finding,
    FindingType,
    Payload,
    Severity,
)


# Gitleaks flags that — if a compromised console pushed them via a
# synced policy — would let an attacker repurpose the local gitleaks
# binary as a file-read / file-write oracle. We drop them silently.
# The legitimate use of `extra_args` is for tuning (`--verbose`,
# `--max-target-megabytes`); anything that lets the attacker name
# arbitrary host paths is denied here regardless of policy source.
_DENIED_GITLEAKS_FLAGS = {
    "--config", "-c",
    "--baseline-path", "-b",
    "--report-path", "-r",
    "--source", "-s",          # we control --source ourselves
    "--log-opts",
    "--config-path",
    "--gitleaks-ignore-path",
}


def _sanitize_extra_args(args: List[str]) -> List[str]:
    """Drop any flag in :data:`_DENIED_GITLEAKS_FLAGS` plus its value.

    A flag and its argument count as one logical pair; if we see
    ``--config /attacker/path`` we drop both tokens. The `=` form
    (``--config=/attacker/path``) is also handled — it's one token.
    """
    out: List[str] = []
    skip_next = False
    for a in args:
        if skip_next:
            skip_next = False
            continue
        head = a.split("=", 1)[0]
        if head in _DENIED_GITLEAKS_FLAGS:
            # If it's the bare-flag form, the value is the next token.
            if "=" not in a:
                skip_next = True
            continue
        out.append(a)
    return out


# Rules we know are virtually never false positives — bump them up so
# the default policy hits them with ``block``. Everything else defaults
# to ``Severity.MEDIUM`` (= redact, not block).
_DEFAULT_RULE_SEVERITY: Dict[str, Severity] = {
    "aws-access-token": Severity.CRITICAL,
    "aws-secret-key": Severity.CRITICAL,
    "private-key": Severity.CRITICAL,
    "rsa-private-key": Severity.CRITICAL,
    "openai-api-key": Severity.CRITICAL,
    "anthropic-api-key": Severity.CRITICAL,
    "stripe-access-token": Severity.CRITICAL,
    "stripe-secret-key": Severity.CRITICAL,
    "gcp-service-account": Severity.CRITICAL,
    "github-pat": Severity.HIGH,
    "github-fine-grained-pat": Severity.HIGH,
    "github-oauth": Severity.HIGH,
    "github-app-token": Severity.HIGH,
    "slack-bot-token": Severity.HIGH,
    "slack-user-token": Severity.HIGH,
}


@dataclass
class GitleaksConfig:
    """Configuration block parsed from ``rules.yaml``."""

    enabled: bool = False
    binary: str = "gitleaks"
    # Extra args passed verbatim, e.g. ["--config", "/path/to/.gitleaks.toml"].
    extra_args: List[str] = field(default_factory=list)
    # rule_id → severity. Overrides _DEFAULT_RULE_SEVERITY.
    rule_severity: Dict[str, Severity] = field(default_factory=dict)
    # Hard timeout for the binary so a runaway scan can't stall a prompt.
    timeout_seconds: float = 10.0
    # Severity to use when neither rule_severity nor _DEFAULT_RULE_SEVERITY
    # has the rule. MEDIUM → redact under the default policy.
    default_severity: Severity = Severity.MEDIUM

    @classmethod
    def from_dict(cls, raw: dict) -> "GitleaksConfig":
        cfg = cls()
        cfg.enabled = bool(raw.get("enabled", False))
        if "binary" in raw:
            cfg.binary = str(raw["binary"])
        if isinstance(raw.get("extra_args"), list):
            cfg.extra_args = _sanitize_extra_args(
                [str(a) for a in raw["extra_args"]]
            )
        if isinstance(raw.get("rule_severity"), dict):
            cfg.rule_severity = {
                str(k): Severity(v) for k, v in raw["rule_severity"].items()
            }
        if "timeout_seconds" in raw:
            cfg.timeout_seconds = float(raw["timeout_seconds"])
        if "default_severity" in raw:
            cfg.default_severity = Severity(raw["default_severity"])
        return cfg

    def severity_for(self, rule_id: str) -> Severity:
        if rule_id in self.rule_severity:
            return self.rule_severity[rule_id]
        return _DEFAULT_RULE_SEVERITY.get(rule_id, self.default_severity)


class GitleaksScanner:
    """Invoke ``gitleaks detect`` on a temp copy of the payload."""

    name = "gitleaks"

    def __init__(self, config: GitleaksConfig):
        self._config = config
        self._unavailable_logged = False

    # ------------------------------------------------------------------ scan

    def scan(self, payload: Payload) -> List[Finding]:
        if not self._config.enabled:
            return []
        binary = shutil.which(self._config.binary)
        if not binary:
            if not self._unavailable_logged:
                sys.stderr.write(
                    f"cloudanix-guard: gitleaks enabled in rules but "
                    f"'{self._config.binary}' is not on $PATH. "
                    f"Install from https://github.com/gitleaks/gitleaks "
                    f"(skipping gitleaks scanner)\n"
                )
                self._unavailable_logged = True
            return []

        # Materialise the payload into a temp dir and remember the
        # (temp filename → source label, content) mapping so we can
        # translate gitleaks's line/column offsets back to char offsets.
        with tempfile.TemporaryDirectory(prefix="cdx-guard-gl-") as tmp_str:
            tmp = Path(tmp_str)
            mapping: Dict[str, Tuple[str, str]] = {}  # temp_name → (source, content)

            if payload.prompt:
                name = "_prompt.txt"
                (tmp / name).write_text(payload.prompt, encoding="utf-8")
                mapping[name] = ("prompt", payload.prompt)

            for idx, entry in enumerate(payload.files):
                content = entry.get("content") or ""
                if not content:
                    # Nothing to scan textually — path-based detection is
                    # the files scanner's job, not ours.
                    continue
                base = os.path.basename(entry.get("path") or f"file_{idx}")
                # Disambiguate identical basenames across files.
                name = f"{idx:03d}_{base}"
                (tmp / name).write_text(content, encoding="utf-8")
                mapping[name] = (entry.get("path") or name, content)

            if not mapping:
                return []

            report = tmp / "_report.json"
            cmd = [
                binary,
                "detect",
                "--source", str(tmp),
                "--no-git",
                "--no-banner",
                "--report-format", "json",
                "--report-path", str(report),
                *self._config.extra_args,
            ]
            try:
                subprocess.run(
                    cmd,
                    capture_output=True,
                    timeout=self._config.timeout_seconds,
                    check=False,
                )
            except subprocess.TimeoutExpired:
                sys.stderr.write(
                    f"cloudanix-guard: gitleaks timed out after "
                    f"{self._config.timeout_seconds:.1f}s; skipping.\n"
                )
                return []
            except OSError as e:
                sys.stderr.write(
                    f"cloudanix-guard: gitleaks failed to launch: {e}. "
                    f"Skipping gitleaks scanner.\n"
                )
                return []

            if not report.exists():
                # No findings at all → gitleaks may skip writing the report.
                return []
            try:
                raw = json.loads(report.read_text() or "[]")
            except json.JSONDecodeError:
                return []

        return list(self._findings_from_report(raw, mapping))

    # ------------------------------------------------------------------ internals

    def _findings_from_report(
        self,
        raw: list,
        mapping: Dict[str, Tuple[str, str]],
    ) -> List[Finding]:
        out: List[Finding] = []
        for item in raw or []:
            if not isinstance(item, dict):
                continue
            file_field = item.get("File") or ""
            # gitleaks emits the absolute path it was given; we only need
            # the basename to look up our mapping.
            temp_name = os.path.basename(file_field)
            if temp_name not in mapping:
                continue
            source, content = mapping[temp_name]

            rule_id = str(item.get("RuleID") or "unknown")
            description = str(item.get("Description") or rule_id)
            match_text = str(item.get("Secret") or item.get("Match") or "")
            severity = self._config.severity_for(rule_id)

            start, end = _line_col_to_offsets(
                content,
                start_line=int(item.get("StartLine") or 0),
                start_col=int(item.get("StartColumn") or 0),
                end_line=int(item.get("EndLine") or 0),
                end_col=int(item.get("EndColumn") or 0),
                fallback_match=match_text,
            )

            out.append(
                Finding(
                    rule_id=f"gitleaks/{rule_id}",
                    type=FindingType.SECRET,
                    severity=severity,
                    message=f"Gitleaks: {description}",
                    source=source,
                    start=start,
                    end=end,
                    match=match_text or None,
                    metadata={
                        "scanner": self.name,
                        "gitleaks_rule": rule_id,
                        "entropy": item.get("Entropy"),
                    },
                )
            )
        return out


def _line_col_to_offsets(
    content: str,
    *,
    start_line: int,
    start_col: int,
    end_line: int,
    end_col: int,
    fallback_match: str = "",
) -> Tuple[Optional[int], Optional[int]]:
    """Translate gitleaks 1-based (line, column) spans into char offsets.

    gitleaks columns are 1-based and inclusive on both ends. We return
    half-open ``[start, end)`` to match the rest of the codebase.

    If the conversion looks bogus (lines past the end, etc.) we fall
    back to a substring search for ``fallback_match`` so the finding
    still carries a redactable span when possible.
    """
    if start_line <= 0 or end_line <= 0:
        return _fallback_span(content, fallback_match)

    # Cumulative char offset at the start of each 1-based line.
    line_offsets: List[int] = [0]
    for line in content.splitlines(keepends=True):
        line_offsets.append(line_offsets[-1] + len(line))

    if start_line > len(line_offsets) or end_line > len(line_offsets):
        return _fallback_span(content, fallback_match)

    # gitleaks columns are 1-based inclusive.
    start = line_offsets[start_line - 1] + max(0, start_col - 1)
    end = line_offsets[end_line - 1] + max(0, end_col)

    if start >= end or start < 0 or end > len(content):
        return _fallback_span(content, fallback_match)
    return start, end


def _fallback_span(content: str, match: str) -> Tuple[Optional[int], Optional[int]]:
    if not match:
        return None, None
    idx = content.find(match)
    if idx < 0:
        return None, None
    return idx, idx + len(match)
