"""Persistent cache for `PreToolUse` Read content scans.

The hook process is short-lived — each tool call is its own subprocess,
so any in-memory cache is cold every time. This module keeps a small
JSON file on disk keyed by ``path`` so a re-read of the same unchanged
file doesn't re-run the scanners (and, when ``has_findings`` is false,
doesn't re-read the file off disk at all).

Entry shape (one per path):

    {
      "<path>": {
        "mtime": 1716480000.0,         # st_mtime at scan time
        "size":  1234,                 # st_size at scan time
        "scanned_at": 1716480001.5,    # epoch seconds — TTL gating
        "has_findings": true,          # short-circuit allow when false
        "findings": [                  # per-finding metadata; lets the
          {"rule_id": "aws-access-key-id",
           "type":    "secret",
           "severity":"critical",
           "message": "AWS Access Key ID",
           "source":  "/Users/.../passwords.txt"}
        ]                              # caller replay through CURRENT
                                       # policy without re-reading the
                                       # file (so a policy change between
                                       # scans is honoured). `match` is
                                       # never persisted — NF-PRIV-1.
      }
    }

A cache **HIT** requires path present, mtime AND size match, and
``scanned_at`` within ``ttl_seconds``. On a HIT for a clean file we
short-circuit to allow without touching the disk; on a HIT for a dirty
file the caller re-evaluates the stored rule_ids against the current
policy so a policy change between scans is honoured.

Eviction is opportunistic LRU at ``max_entries`` (we drop the oldest
``scanned_at`` entries). Expired entries are cleaned at read time.

Atomic write via ``os.replace`` mirrors the pattern in
``pending_block.py``. Best-effort throughout: any IO error is swallowed
so a corrupted cache file can never break a hook.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from cloudanix_guard.config_file import config_dir
from cloudanix_guard.inspector.types import Finding, FindingType, Severity


_CACHE_FILE = "read_scan_cache.json"


@dataclass
class CacheEntry:
    """One cached scan result.

    ``findings`` stores the categorical metadata needed to reconstruct
    a :class:`Finding` for policy replay. Critically, ``match`` (the
    raw matched string) is NEVER persisted — NF-PRIV-1 says no
    detected secret/PII ever touches disk in the cache.
    """

    mtime: float
    size: int
    scanned_at: float
    has_findings: bool
    findings: List[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "mtime": self.mtime,
            "size": self.size,
            "scanned_at": self.scanned_at,
            "has_findings": self.has_findings,
            "findings": list(self.findings),
        }

    @classmethod
    def from_dict(cls, raw: dict) -> Optional["CacheEntry"]:
        try:
            findings_raw = raw.get("findings") or []
            findings = [f for f in findings_raw if isinstance(f, dict)]
            return cls(
                mtime=float(raw["mtime"]),
                size=int(raw["size"]),
                scanned_at=float(raw["scanned_at"]),
                has_findings=bool(raw["has_findings"]),
                findings=findings,
            )
        except (KeyError, TypeError, ValueError):
            return None

    def replay_findings(self, *, source: str) -> List[Finding]:
        """Reconstruct :class:`Finding` objects from the persisted dicts
        so the caller can feed them through the policy engine without
        re-reading the source file. Bad/partial dicts are skipped."""
        out: List[Finding] = []
        for raw in self.findings:
            try:
                out.append(
                    Finding(
                        rule_id=str(raw["rule_id"]),
                        type=FindingType(str(raw["type"])),
                        severity=Severity(str(raw["severity"])),
                        message=str(raw.get("message") or ""),
                        source=str(raw.get("source") or source),
                        start=raw.get("start"),
                        end=raw.get("end"),
                        match=None,  # never persisted
                        metadata={"scanner": "file_content_cache_replay"},
                    )
                )
            except (KeyError, ValueError, TypeError):
                continue
        return out


def _path() -> Path:
    return config_dir() / _CACHE_FILE


def _load() -> Dict[str, CacheEntry]:
    p = _path()
    if not p.exists():
        return {}
    try:
        raw = p.read_text()
        data = json.loads(raw) if raw.strip() else {}
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(data, dict):
        return {}
    out: Dict[str, CacheEntry] = {}
    for k, v in data.items():
        if not isinstance(v, dict):
            continue
        entry = CacheEntry.from_dict(v)
        if entry is not None:
            out[str(k)] = entry
    return out


def _save(entries: Dict[str, CacheEntry]) -> None:
    try:
        from cloudanix_guard._safe_io import safe_atomic_write
        body = json.dumps({k: v.to_dict() for k, v in entries.items()})
        safe_atomic_write(_path(), body + "\n")
    except OSError:
        pass


def lookup(path: str, *, ttl_seconds: int) -> Optional[CacheEntry]:
    """Return a fresh cache entry for ``path`` if one exists and the
    file on disk hasn't changed since it was scanned. ``None`` on miss
    / stale / missing-file.

    Stale (TTL-expired) entries are *not* removed here — that happens on
    the next ``store`` call to keep the read path zero-write.
    """
    entries = _load()
    entry = entries.get(path)
    if entry is None:
        return None
    if (time.time() - entry.scanned_at) > ttl_seconds:
        return None
    try:
        st = os.stat(path)
    except OSError:
        return None
    if st.st_mtime != entry.mtime or st.st_size != entry.size:
        return None
    return entry


def store(
    path: str,
    *,
    mtime: float,
    size: int,
    has_findings: bool,
    findings: Optional[List[Finding]] = None,
    max_entries: int = 2000,
    ttl_seconds: int = 3600,
) -> None:
    """Insert or replace a cache entry for ``path``. Best-effort —
    failures are swallowed.

    Performs opportunistic cleanup before writing: expired entries are
    dropped, and if we still exceed ``max_entries`` we LRU-evict by
    oldest ``scanned_at``.
    """
    entries = _load()
    now = time.time()

    # Expire-then-LRU. Expired drop first so the LRU choice isn't
    # forced to evict an otherwise-fresh entry.
    entries = {
        k: v for k, v in entries.items() if (now - v.scanned_at) <= ttl_seconds
    }

    # Serialize findings via to_dict so `match` is stripped — NF-PRIV-1.
    finding_dicts: List[dict] = []
    for f in findings or []:
        d = f.to_dict()
        d.pop("match", None)
        d.pop("metadata", None)  # scanner-specific noise; not needed for replay
        finding_dicts.append(d)

    entries[path] = CacheEntry(
        mtime=mtime,
        size=size,
        scanned_at=now,
        has_findings=has_findings,
        findings=finding_dicts,
    )

    if max_entries > 0 and len(entries) > max_entries:
        ordered = sorted(entries.items(), key=lambda kv: kv[1].scanned_at)
        keep = ordered[-max_entries:]
        entries = dict(keep)

    _save(entries)


def clear() -> None:
    """Remove the cache file entirely. Test helper + future ``status``
    command surface."""
    p = _path()
    try:
        p.unlink(missing_ok=True)
    except OSError:
        pass
