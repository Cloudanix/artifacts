"""PII scanner.

For the POC we ship a minimal, dependency-free regex-based detector
covering the most common PII types (email, US SSN, credit-card-like
numbers, IPv4, phone). In production this module should be swapped
for (or augmented with) Microsoft Presidio, which provides NER-based
detection and a much richer recogniser catalogue.

The regex catalogue deliberately errs on the side of *recall* —
false positives can be filtered at the policy layer (e.g. treat
``medium`` severity as warn-only).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable, List

from cloudanix_guard.inspector.types import (
    Finding,
    FindingType,
    Payload,
    Severity,
)


@dataclass
class PIIRule:
    """A compiled PII-detection rule."""

    id: str
    description: str
    severity: Severity
    regex: re.Pattern[str]
    validator: str | None = None  # e.g. "luhn" for credit cards

    @classmethod
    def from_dict(cls, raw: dict) -> "PIIRule":
        return cls(
            id=raw["id"],
            description=raw.get("description", raw["id"]),
            severity=Severity(raw.get("severity", "medium")),
            regex=re.compile(raw["pattern"], re.MULTILINE),
            validator=raw.get("validator"),
        )


def _luhn_check(number: str) -> bool:
    """Return True if ``number`` (digits only) passes the Luhn checksum."""
    digits = [int(d) for d in number if d.isdigit()]
    if len(digits) < 12:
        return False
    checksum = 0
    parity = len(digits) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0


class PIIScanner:
    """Run a list of :class:`PIIRule` against a payload."""

    name = "pii"

    def __init__(self, rules: Iterable[PIIRule]):
        self._rules = list(rules)

    def scan(self, payload: Payload) -> List[Finding]:
        findings: List[Finding] = []
        findings.extend(self._scan_text(payload.prompt, source="prompt"))
        for f in payload.files:
            findings.extend(self._scan_text(f.get("content", ""), source=f.get("path", "file")))
        return findings

    # ------------------------------------------------------------------ internals

    def _scan_text(self, text: str, source: str) -> List[Finding]:
        if not text:
            return []
        out: List[Finding] = []
        for rule in self._rules:
            for m in rule.regex.finditer(text):
                matched = m.group(0)
                if rule.validator == "luhn" and not _luhn_check(matched):
                    continue
                out.append(
                    Finding(
                        rule_id=rule.id,
                        type=FindingType.PII,
                        severity=rule.severity,
                        message=rule.description,
                        source=source,
                        start=m.start(),
                        end=m.end(),
                        match=matched,
                        metadata={"scanner": self.name},
                    )
                )
        return out
