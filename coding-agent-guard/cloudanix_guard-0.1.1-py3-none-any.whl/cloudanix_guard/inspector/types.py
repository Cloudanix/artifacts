"""Core types used across scanners.

Every scanner emits a list of :class:`Finding` objects with character
offsets into the original text. Those offsets let the enforcement layer
redact in place, so multiple scanners can operate independently on the
same payload.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Protocol


class Severity(str, Enum):
    """Finding severity. Ordered from lowest to highest."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    def rank(self) -> int:
        order = [Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]
        return order.index(self)


class FindingType(str, Enum):
    """Top-level category a finding belongs to. Drives policy routing."""

    SECRET = "secret"
    PII = "pii"
    FILE = "file"
    CODE = "code"  # reserved for future source-code sensitivity scanner


@dataclass
class Finding:
    """A single detection inside a payload.

    Attributes:
        rule_id: Stable identifier of the rule that fired (e.g. ``aws-access-key``).
        type:    Top-level category (:class:`FindingType`).
        severity: Severity level, used by the policy engine.
        message: Human-readable description, shown to the developer.
        source:  Where the finding was detected. ``"prompt"`` for the main
                 prompt text, or the path of the attached file.
        start:   Character offset (inclusive) in the source text. May be
                 ``None`` for findings without a text span (e.g. file-path
                 findings where the whole file is the issue).
        end:     Character offset (exclusive) in the source text.
        match:   The matched substring (kept for debugging / audit only —
                 never echoed back to the user by default).
        metadata: Scanner-specific extra context.
    """

    rule_id: str
    type: FindingType
    severity: Severity
    message: str
    source: str = "prompt"
    start: Optional[int] = None
    end: Optional[int] = None
    match: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def qualified_rule_id(self) -> str:
        """The ``"<type>/<rule_id>"`` form used everywhere a finding is
        referred to by name — policy rule_overrides keys, exception
        store rules, inline-bypass allowlist patterns, telemetry
        events. Centralised here so callers stop building the string
        ad-hoc and we have one place to change it."""
        return f"{self.type.value}/{self.rule_id}"

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable dict (omits the raw match by default)."""
        return {
            "rule_id": self.rule_id,
            "type": self.type.value,
            "severity": self.severity.value,
            "message": self.message,
            "source": self.source,
            "start": self.start,
            "end": self.end,
            "metadata": self.metadata,
        }


@dataclass
class Payload:
    """The full payload an agent is about to send to the LLM.

    Attributes:
        prompt: The main user/agent prompt text.
        files:  Files the agent has attached as context. Each entry is a
                ``{"path": str, "content": str}`` dict.
    """

    prompt: str = ""
    files: List[Dict[str, str]] = field(default_factory=list)


class Scanner(Protocol):
    """Minimal scanner interface.

    Implementations receive the full :class:`Payload` and return a list
    of findings. Scanners must be side-effect free and safe to call in
    parallel on independent payloads.
    """

    name: str

    def scan(self, payload: Payload) -> List[Finding]:  # pragma: no cover - protocol
        ...
