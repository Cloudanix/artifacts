"""Inspector orchestrator.

Loads scanner rules from a YAML file and fans a payload out to every
scanner, returning a merged, sorted list of findings.

Rule file shape (see ``config/rules.yaml``)::

    secrets:
      - id: aws-access-key
        description: AWS Access Key ID
        severity: critical
        pattern: 'AKIA[0-9A-Z]{16}'
    pii:
      - id: email
        description: Email address
        severity: medium
        pattern: '[\\w.+-]+@[\\w-]+\\.[\\w.-]+'
    files:
      - id: dotenv
        description: Environment file
        severity: critical
        patterns: ['.env', '.env.*']

The YAML is designed so we can later sync it from the Cloudanix
control plane without code changes.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import yaml

from cloudanix_guard.inspector.files import FilePathScanner, FileRule
from cloudanix_guard.inspector.gitleaks import GitleaksConfig, GitleaksScanner
from cloudanix_guard.inspector.pii import PIIRule, PIIScanner
from cloudanix_guard.inspector.presidio import PresidioConfig, PresidioScanner
from cloudanix_guard.inspector.secrets import SecretRule, SecretsScanner
from cloudanix_guard.inspector.types import Finding, Payload, Scanner


class Inspector:
    """Run every registered scanner against a payload and merge results."""

    def __init__(self, scanners: List[Scanner]):
        self._scanners = scanners

    # ---------------------------------------------------------------- factory

    @classmethod
    def from_yaml(cls, path: str | Path) -> "Inspector":
        raw = yaml.safe_load(Path(path).read_text()) or {}
        scanners: List[Scanner] = []

        if raw.get("secrets"):
            scanners.append(SecretsScanner([SecretRule.from_dict(r) for r in raw["secrets"]]))
        if raw.get("pii"):
            scanners.append(PIIScanner([PIIRule.from_dict(r) for r in raw["pii"]]))
        if raw.get("files"):
            scanners.append(FilePathScanner([FileRule.from_dict(r) for r in raw["files"]]))

        # Optional, dependency-heavy scanners. They self-skip if the
        # underlying library / binary isn't available, so registering
        # them when ``enabled: false`` is a no-op.
        presidio_cfg = PresidioConfig.from_dict(raw.get("presidio") or {})
        if presidio_cfg.enabled:
            scanners.append(PresidioScanner(presidio_cfg))
        gitleaks_cfg = GitleaksConfig.from_dict(raw.get("gitleaks") or {})
        if gitleaks_cfg.enabled:
            scanners.append(GitleaksScanner(gitleaks_cfg))

        return cls(scanners)

    @classmethod
    def default(cls) -> "Inspector":
        """Load the packaged default rule set."""
        default_path = Path(__file__).resolve().parent.parent / "config" / "rules.yaml"
        return cls.from_yaml(default_path)

    # ---------------------------------------------------------------- scan

    def inspect(self, payload: Payload) -> List[Finding]:
        findings: List[Finding] = []
        for s in self._scanners:
            findings.extend(s.scan(payload))
        # Stable ordering: by source then start offset — makes redaction
        # deterministic and the output easier to read.
        findings.sort(key=lambda f: (f.source, f.start if f.start is not None else -1, f.rule_id))
        return findings

    @property
    def scanner_names(self) -> List[str]:
        return [s.name for s in self._scanners]
