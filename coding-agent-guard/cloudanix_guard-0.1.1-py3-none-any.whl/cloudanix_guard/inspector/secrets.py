"""Secrets scanner.

Detects API keys, tokens and private keys with a curated set of regex
rules. The rule list is intentionally small for the POC — it covers the
highest-ROI patterns we see in practice (AWS, GCP, Slack, GitHub,
OpenAI, Anthropic, generic PEM blocks, generic high-entropy tokens).

Design notes:
- Rules are loaded from YAML so they can ship independently of code
  and eventually be synced from the Cloudanix control plane.
- Each match carries ``start`` / ``end`` offsets so the enforcement
  layer can redact in place.
- ``entropy_min`` on a rule lets us gate a regex on Shannon entropy,
  which cuts false positives on loose patterns (e.g. generic hex).
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Iterable, List, Optional

from cloudanix_guard.inspector.types import (
    Finding,
    FindingType,
    Payload,
    Severity,
)


def _shannon_entropy(s: str) -> float:
    """Return the Shannon entropy of a string in bits/char."""
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


@dataclass
class SecretRule:
    """A compiled secrets-detection rule."""

    id: str
    description: str
    severity: Severity
    regex: re.Pattern[str]
    entropy_min: Optional[float] = None
    # Which capture group in ``regex`` holds the actual secret. ``0`` means
    # the whole match; otherwise the index of a named/positional group.
    secret_group: int = 0

    @classmethod
    def from_dict(cls, raw: dict) -> "SecretRule":
        return cls(
            id=raw["id"],
            description=raw.get("description", raw["id"]),
            severity=Severity(raw.get("severity", "high")),
            regex=re.compile(raw["pattern"], re.MULTILINE),
            entropy_min=raw.get("entropy_min"),
            secret_group=raw.get("secret_group", 0),
        )


class SecretsScanner:
    """Run a list of :class:`SecretRule` against a payload."""

    name = "secrets"

    def __init__(self, rules: Iterable[SecretRule]):
        self._rules = list(rules)

    def scan(self, payload: Payload) -> List[Finding]:
        findings: List[Finding] = []
        findings.extend(self._scan_text(payload.prompt, source="prompt"))
        for f in payload.files:
            findings.extend(self._scan_text(f.get("content", ""), source=f.get("path", "file")))
        return findings

    # ------------------------------------------------------------------ internals

    def _scan_text(self, text: str, source: str) -> List[Finding]:
        if not text:
            return []
        out: List[Finding] = []
        for rule in self._rules:
            for m in rule.regex.finditer(text):
                secret = m.group(rule.secret_group) if rule.secret_group else m.group(0)
                if rule.entropy_min is not None and _shannon_entropy(secret) < rule.entropy_min:
                    continue
                span_start, span_end = m.span(rule.secret_group) if rule.secret_group else m.span()
                out.append(
                    Finding(
                        rule_id=rule.id,
                        type=FindingType.SECRET,
                        severity=rule.severity,
                        message=rule.description,
                        source=source,
                        start=span_start,
                        end=span_end,
                        match=secret,
                        metadata={"scanner": self.name},
                    )
                )
        return out
