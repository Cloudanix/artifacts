"""In-prompt bypass directive: ``cloudanix:allow``.

When the user is blocked by the hook on `UserPromptSubmit` they need
a way to say "yes, this one, I know what I'm doing" without leaving
the Claude Code / Kiro session. Slash commands don't reach the hook
(they're handled by the agent), and side-band CLIs require a second
terminal. The only channel available to the hook in-session is the
prompt text itself.

A directive line at the very top of the prompt::

    cloudanix:allow pii/email 5m "google drive path has my email"

is parsed here, validated against the policy's :data:`inline_bypass`
config, granted via :mod:`cloudanix_guard.exceptions`, and stripped
from the prompt before inspection runs. See ``_handle_prompt_submit``
in cli.py for the integration point.

Grammar (strict on purpose — anything non-matching is treated as a
normal first line of prompt text):

* ``cloudanix:allow`` — fixed literal
* ``<rule>`` — ``"<type>/<rule_id>"`` shape, e.g. ``pii/email``
* ``<duration>`` — integer + unit ``s|m|h|d`` (no spaces between)
* ``"<reason>"`` — double-quoted, non-empty, no embedded double-quote

Only the first non-empty line is considered. This keeps a model that
echoes user text back from being able to introduce a directive via
later tool output.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Tuple


_DURATION_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86_400}
_LITERAL = r"cloudanix:allow"

# Single-line regex. We match the WHOLE first non-empty line so a stray
# trailing token disqualifies the directive (and falls through as
# regular prompt text). The reason has no embedded double-quote — keeps
# the grammar trivially unambiguous.
_DIRECTIVE_RE = re.compile(
    rf"""
    ^{_LITERAL}                   # fixed literal
    \s+
    (?P<rule>[A-Za-z0-9_./-]+)    # type/rule_id
    \s+
    (?P<duration>\d+[smhd])       # integer + unit
    \s+
    "(?P<reason>[^"\n]+)"         # quoted, non-empty, no embedded "
    \s*$                          # nothing else on the line
    """,
    re.VERBOSE,
)


@dataclass
class Directive:
    """A parsed bypass directive.

    Two variants:

    - **Full form**: all three fields populated. User typed
      ``cloudanix:allow <rule> <ttl> "<reason>"``.
    - **Autofill form**: all three fields are ``None``. User typed
      bare ``cloudanix:allow`` (no args), trusting the hook to
      resolve from ``pending_block.json``. The cli.py caller
      detects ``rule is None`` and dispatches into the
      ``pending_block.consume_if_fresh`` path.

    Normalization for the full form:

    * ``rule`` is stripped lowercase
    * ``ttl_seconds`` is the duration in seconds (caller still has to
      enforce the policy max)
    * ``reason`` is the raw inner string (no surrounding quotes)
    """

    rule: Optional[str]
    ttl_seconds: Optional[int]
    reason: Optional[str]

    @property
    def is_autofill(self) -> bool:
        return self.rule is None


def parse(prompt_text: str) -> Tuple[Optional[Directive], Optional[str]]:
    """Try to extract a directive from the start of ``prompt_text``.

    Recognizes two shapes on the first non-empty line:

    - Full: ``cloudanix:allow <rule> <ttl> "<reason>"`` →
      :class:`Directive` with all fields populated.
    - Autofill: bare ``cloudanix:allow`` (optionally followed by
      whitespace and nothing else) → :class:`Directive` with all
      fields ``None``; caller resolves from ``pending_block.json``.

    Returns ``(directive, remainder)`` where ``remainder`` is the
    prompt with the directive line (plus its trailing blank line, if
    any) stripped off. If no directive is present, returns
    ``(None, None)`` and the caller passes the original text through.
    """
    if not prompt_text:
        return None, None

    # Find the first non-empty line; allow leading blank lines.
    lines = prompt_text.split("\n")
    first_idx = next((i for i, ln in enumerate(lines) if ln.strip()), None)
    if first_idx is None:
        return None, None

    first_line = lines[first_idx].rstrip()

    if _AUTOFILL_RE.match(first_line):
        directive: Directive = Directive(rule=None, ttl_seconds=None, reason=None)
        return directive, _strip_first_line(lines, first_idx)

    match = _DIRECTIVE_RE.match(first_line)
    if not match:
        return None, None

    duration_str = match.group("duration")
    unit = duration_str[-1]
    value = int(duration_str[:-1])
    ttl = value * _DURATION_UNITS[unit]
    directive = Directive(
        rule=match.group("rule").strip().lower(),
        ttl_seconds=ttl,
        reason=match.group("reason"),
    )
    return directive, _strip_first_line(lines, first_idx)


# Bare `cloudanix:allow` on its own — autofill form. Whitespace on
# either side is tolerated; trailing tokens disqualify (would conflict
# with the full-form parser, which already rejects malformed trailing
# tokens by virtue of `\s*$` anchoring).
_AUTOFILL_RE = re.compile(rf"^\s*{_LITERAL}\s*$")


def _strip_first_line(lines: list, first_idx: int) -> str:
    """Drop the directive line and one trailing blank line so the
    cleaned prompt doesn't start with an awkward leading newline."""
    drop_through = first_idx + 1
    if drop_through < len(lines) and not lines[drop_through].strip():
        drop_through += 1
    return "\n".join(lines[drop_through:])
