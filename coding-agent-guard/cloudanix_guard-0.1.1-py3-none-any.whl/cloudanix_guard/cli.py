"""Command-line entry-point.

Subcommands:

``scan``
    Human-readable scan of a text snippet or file. Used for interactive
    testing and demos.

``hook``
    Machine-readable hook mode. Reads a JSON payload from stdin; emits
    a decision via exit code and stderr so both Kiro and Claude Code can
    consume it without any per-platform glue.

    Auto-detects three event shapes:

    - ``userPromptSubmit`` / ``UserPromptSubmit``  → scans the prompt.
    - ``preToolUse`` / ``PreToolUse``              → scans the tool call
      (file path + shell command) for sensitive reads / writes.
    - anything else                                → passes through (exit 0).

    Exit codes:

    ``0``  allow (or non-blocking warn on Kiro userPromptSubmit).
    ``2``  block — stderr explains why. Both Kiro and Claude Code honour
           this as a blocking error for events that can be blocked.
    ``1``  unexpected error (malformed stdin, etc.).

``install``
    Writes the Kiro agent config and/or Claude Code settings.json hook
    block so you can try the firewall end-to-end without hand-editing.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Iterable, List, Optional

from cloudanix_guard.enforce import apply as apply_decision
from cloudanix_guard.hook_adapter import (
    augment_with_file_content,
    payload_from_tool_use,
    record_scan_in_cache,
    FileScanResult,
)
from cloudanix_guard.inspector import Finding, Inspector, Payload
from cloudanix_guard.install import (
    InstallPlan,
    apply as apply_install,
    plan_claude,
    plan_claude_uninstall,
    plan_codex,
    plan_codex_uninstall,
    plan_kiro,
    plan_kiro_uninstall,
    resolve_guard_command,
    with_profile_prefix,
)
from cloudanix_guard.policy import LoggingMode, Mode, PolicyEngine
from cloudanix_guard import state as guard_state
from cloudanix_guard import config_file as guard_config
from cloudanix_guard import telemetry as guard_telemetry
from cloudanix_guard import exceptions as guard_exceptions
from cloudanix_guard import sync as guard_sync
from cloudanix_guard import directive as guard_directive
from cloudanix_guard import pending_block as guard_pending_block
from cloudanix_guard.utils.context import init_trace_id, resolve_trace_id


# ---------------------------------------------------------------------- shared

def _load_inspector(rules: Optional[str]) -> Inspector:
    if rules:
        return Inspector.from_yaml(rules)
    return Inspector.default()


def _load_policy(policy: Optional[str]) -> PolicyEngine:
    if policy:
        return PolicyEngine.from_yaml(policy)
    return PolicyEngine.default()


def _format_findings(findings: Iterable[Finding]) -> str:
    lines: List[str] = []
    for f in findings:
        loc = f.source
        span = ""
        if f.start is not None:
            span = f" @ {f.start}-{f.end}"
        lines.append(
            f"  - [{f.severity.value}] {f.type.value}/{f.rule_id}{span} in {loc}: {f.message}"
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------- scan

def cmd_scan(args: argparse.Namespace) -> int:
    if args.text is None and args.file is None:
        print("error: provide --text or --file", file=sys.stderr)
        return 1

    prompt = args.text or Path(args.file).read_text()
    payload = Payload(prompt=prompt, files=[])

    inspector = _load_inspector(args.rules)
    policy = _load_policy(args.policy)

    findings = inspector.inspect(payload)
    decision = policy.decide(findings)
    result = apply_decision(payload, decision)

    if args.json:
        print(json.dumps(result, indent=2))
        return 0 if not decision.mode.is_blocking() else 2

    _pretty_print(result, decision.mode)
    return 0 if not decision.mode.is_blocking() else 2


# ---------------------------------------------------------------------- hook

# Exit code that both platforms treat as a blocking error.
_EXIT_BLOCK = 2


def cmd_hook(args: argparse.Namespace) -> int:
    # Generate a per-invocation trace_id before we touch stdin so even
    # malformed-payload errors are correlatable. `resolve_trace_id` runs
    # inside the dispatcher once the JSON is parsed and replaces this
    # UUID with the payload's `session_id` if present.
    init_trace_id()
    # The install command for Codex (and any future PascalCase-event
    # agent that needs distinguishing from Claude) wires --agent into
    # the hook invocation; stash it for _agent_from_event_name.
    global _EXPLICIT_AGENT
    _EXPLICIT_AGENT = getattr(args, "agent", None)
    try:
        return _cmd_hook_dispatch(args)
    finally:
        # Opportunistic background flush. Fork-and-forget — never
        # blocks the hook return, never raises out. Cron remains the
        # reliable backstop; this just keeps a fresh install (where the
        # user hasn't wired cron yet) from looking silent on the
        # console.
        _maybe_async_flush()


def _cmd_hook_dispatch(args: argparse.Namespace) -> int:
    # Pause check first — cheap path before we even read stdin's JSON
    # is tempting, but we still drain stdin so the parent agent's pipe
    # doesn't fill. Read first, then check.
    try:
        raw = sys.stdin.read()
        payload_dict = json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError as e:
        sys.stderr.write(f"cloudanix-guard: invalid JSON on stdin: {e}\n")
        return 1

    # Bridge the temp trace_id to the payload's stable session id (when
    # Claude Code / Kiro include one). Silent if the payload has none —
    # the temp UUID remains in effect.
    from cloudanix_guard.utils.logger import _current_trace_id
    resolve_trace_id(payload_dict, _current_trace_id.get())

    paused = guard_state.is_paused()
    if paused is not None:
        # Emit one short stderr line so the user sees the guard is off.
        # Both platforms surface stderr to the user / LLM, so this is
        # the right place to remind them they're operating bypassed.
        remaining = guard_state.format_remaining(paused)
        sys.stderr.write(
            f"cloudanix-guard: PAUSED ({paused.reason}; {remaining}). "
            f"Run `cloudanix-guard resume` to re-enable.\n"
        )
        return 0

    raw_event_name = str(payload_dict.get("hook_event_name") or "")
    event = raw_event_name.lower()
    inspector = _load_inspector(args.rules)
    policy = _load_policy(args.policy)

    if event == "userpromptsubmit":
        return _handle_prompt_submit(payload_dict, inspector, policy, raw_event_name)

    if event == "pretooluse":
        return _handle_pre_tool_use(payload_dict, inspector, policy, raw_event_name)

    # Fallback for direct invocations (legacy JSON shape: {"prompt", "files"}).
    # This lets `scan | cloudanix-guard hook` and the demo keep working.
    if "prompt" in payload_dict or "files" in payload_dict:
        payload = Payload(
            prompt=payload_dict.get("prompt") or "",
            files=list(payload_dict.get("files") or []),
        )
        # No hook_event_name → don't enqueue telemetry; this is a
        # synthetic invocation from the demo / scripts.
        return _handle_payload(payload, inspector, policy, as_json=True,
                               hook_event=None)

    # Unknown event — do not interfere.
    return 0


def _maybe_async_flush() -> None:
    """Fork a detached ``cloudanix-guard flush`` subprocess if conditions
    are right. Returns immediately; the hook does not wait on the
    flush's outcome.

    Throttle + spool-empty + backoff + telemetry-configured checks live
    in :func:`telemetry.should_attempt_hook_flush`. We stamp the
    throttle *before* forking so a slow child can't trigger a storm
    if the user is typing fast.
    """
    import subprocess
    try:
        if not guard_telemetry.should_attempt_hook_flush():
            return
        guard_telemetry.record_hook_flush_attempt()
        # detached: own session, no stdio, never inherits the hook's
        # stdin/stderr (which are wired to the parent agent).
        subprocess.Popen(
            [sys.executable, "-m", "cloudanix_guard.cli", "flush"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except Exception:  # noqa: BLE001 — auto-flush must never break the hook
        pass


# Set by cmd_hook before dispatch. Each hook invocation is its own
# Python process, so module-level state is safe — no cross-talk.
_EXPLICIT_AGENT: Optional[str] = None


def _agent_from_event_name(
    raw_event_name: str, explicit: Optional[str] = None
) -> Optional[str]:
    """Infer the coding-agent from the event-name casing, or honor an
    explicit override.

    Claude Code uses PascalCase (``UserPromptSubmit``, ``PreToolUse``);
    Kiro uses camelCase (``userPromptSubmit``, ``preToolUse``). Codex
    also uses PascalCase — so it's indistinguishable from Claude Code
    by casing alone. The Codex installer wires ``--agent codex`` into
    the hook command (read into :data:`_EXPLICIT_AGENT` by
    :func:`cmd_hook` at start-of-process); when set, it wins.
    Otherwise we fall back to casing inference, returning ``None`` for
    empty input (event is still recorded, just untagged).
    """
    chosen = explicit or _EXPLICIT_AGENT
    if chosen:
        return chosen
    if not raw_event_name:
        return None
    return "claude_code" if raw_event_name[0].isupper() else "kiro"


def _bypass_for_decision(decision) -> Optional[guard_exceptions.ExceptionEntry]:
    """If every contributing finding has an active self-exception,
    return one of them as the representative bypass. Otherwise ``None``.

    Applies to:

    - ``warn_self_justify`` — the mode designed for the bypass flow.
    - ``redact`` — in hook mode REDACT degrades to block (the protocol
      can't rewrite the prompt on the wire), so an active exception is
      the user's explicit "this is expected" signal and should let the
      prompt through. Without this, the inline directive grant in
      `_handle_prompt_submit` would be useless: it stores the exception
      but the next inspection still blocks on REDACT.

    Not bypassable via this path:

    - ``block`` is by design non-overridable.
    - ``warn_external_approve`` will use the (Phase D) approval store, not this one.
    - ``warn_continue`` / ``observe`` don't block — no bypass needed.
    """
    if decision.mode not in (Mode.WARN_SELF_JUSTIFY, Mode.REDACT):
        return None
    if not decision.findings:
        return None
    matches: list[guard_exceptions.ExceptionEntry] = []
    for f in decision.findings:
        exc = guard_exceptions.find_active_for_rule(f.qualified_rule_id)
        if exc is None:
            return None
        matches.append(exc)
    # All covered — pick the most-recent grant as representative.
    matches.sort(key=lambda e: e.granted_at)
    return matches[-1]


def _block_message(
    mode: Mode,
    *,
    contributing: Optional[Finding] = None,
    inline_bypass=None,
    source_label: str = "prompt",
) -> tuple[str, str]:
    """Return ``(header, footer)`` strings for the hook's stderr.

    Each mode gets its own framing so the message is actionable. When
    the policy allows in-prompt bypass for the contributing rule, the
    footer surfaces the `cloudanix:allow` directive — with copy that
    differs by ``source_label``:

    - ``"prompt"`` (UserPromptSubmit): tells the user to *prepend* the
      directive to their next prompt.
    - ``tool=…`` (PreToolUse): tells the user to send the directive as
      a *separate* user prompt before asking the agent to retry, because
      they can't prepend a directive to a tool input and have the tool
      still work.
    """
    directive_hint = _inline_directive_hint(contributing, inline_bypass, source_label)

    if mode is Mode.BLOCK:
        # Hard stops are non-bypassable on purpose. No directive hint
        # even if the rule happens to be in the inline allowlist —
        # block means block.
        return (
            "Cloudanix Guard: blocked by policy.",
            "  This rule has no override path. If you believe this is "
            "wrong, talk to your security team.",
        )
    if mode is Mode.REDACT:
        if directive_hint:
            return (
                "Cloudanix Guard: sensitive content detected (redaction requested).",
                "  The hook protocol can't rewrite the prompt on the wire, so this is "
                "blocked.\n" + directive_hint,
            )
        return (
            "Cloudanix Guard: sensitive content detected (redaction requested).",
            "  The hook protocol cannot rewrite prompts on the wire, so "
            "this is blocked. Edit the prompt to remove the flagged "
            "content and try again.",
        )
    if mode is Mode.WARN_SELF_JUSTIFY:
        if directive_hint:
            return (
                "Cloudanix Guard: blocked — self-justification required.",
                directive_hint
                + "  Or, from another terminal:\n"
                "    cloudanix-guard request-exception --rule <type/rule_id> --reason \"<reason>\"",
            )
        return (
            "Cloudanix Guard: blocked — self-justification required.",
            "  To grant a 10-minute exception, run:\n"
            "    cloudanix-guard request-exception --rule <type/rule_id> --reason \"<reason>\"\n"
            "  (Substitute <type/rule_id> with the value from the 'findings' line above —\n"
            "   e.g. `secret/github-pat`.)\n"
            "  Or just tell me what you're trying to do and I'll request it for you.",
        )
    if mode is Mode.WARN_EXTERNAL_APPROVE:
        return (
            "Cloudanix Guard: blocked — external approval required.",
            "  To request approval (async — you'll be notified when granted), run:\n"
            "    cloudanix-guard request-exception --rule <type/rule_id> --reason \"<reason>\" --external\n"
            "  (Phase A note: the approval flow is not yet wired; this currently blocks.)",
        )
    # Defensive default — should never hit this for non-blocking, non-redact modes.
    return ("Cloudanix Guard: action required.", "")


def _inline_directive_hint(
    contributing: Optional[Finding], inline_bypass, source_label: str = "prompt"
) -> Optional[str]:
    """Build the directive-suggestion footer, or ``None`` if the
    contributing rule isn't inline-bypassable.

    Copy varies by ``source_label``:

    - ``"prompt"``: classic "paste this at the top of your prompt" —
      the directive is parsed by ``_handle_prompt_submit``, stripped
      from stdin, and the cleaned prompt continues.
    - anything starting with ``"tool="`` (PreToolUse): can't prepend
      to a tool input, so the copy points the user at sending the
      directive as a *separate* user prompt. The grant is rule-scoped
      and lives in ``~/.cloudanix-guard/exceptions.jsonl``;
      ``_bypass_for_decision`` then covers the next tool call that
      fires the same rule.
    """
    if contributing is None or inline_bypass is None:
        return None
    if not inline_bypass.enabled:
        return None
    rule = contributing.qualified_rule_id
    if not inline_bypass.rule_is_allowed(rule):
        return None
    ttl_seconds = inline_bypass.default_ttl_seconds
    ttl_label = _format_ttl(ttl_seconds)
    directive_line = f'cloudanix:allow {rule} {ttl_label} "<your reason>"'

    if source_label.startswith("tool="):
        return (
            f"  If this is expected, send `cloudanix:allow` (just that one word) as\n"
            f"  your next prompt. The guard grants {rule} for {ttl_label} and asks\n"
            f"  you to follow up with your actual ask — then the agent's retry of\n"
            f"  the tool call will pass. For a longer window or custom reason:\n"
            f"    {directive_line}\n"
        )

    # Prompt-scope: best UX is the combined form — directive on the
    # first line, the user's actual ask below. Hook grants on the
    # directive, the agent sees and responds to the body normally.
    return (
        f"  If this is expected, resend your prompt with `cloudanix:allow`\n"
        f"  on the first line, followed by your actual ask. The guard grants\n"
        f"  {rule} for {ttl_label} and lets the agent process the body:\n"
        f"    cloudanix:allow\n"
        f"    <your ask>\n"
        f"  Or send just `cloudanix:allow` to grant the bypass, then send\n"
        f"  your ask as a separate prompt. For a longer window or custom\n"
        f"  reason, use the full form:\n"
        f"    {directive_line}\n"
    )


def _format_ttl(seconds: int) -> str:
    """Render a TTL as the shortest readable `<int><unit>` form. Used
    in the directive hint so the suggestion matches the policy's
    `default_ttl_seconds` exactly.

    Defensive: a misconfigured policy with ``default_ttl_seconds: 0``
    or negative would otherwise render as ``"0d"`` (since 0 % 86_400
    == 0) and the suggested directive line ``cloudanix:allow ... 0d
    "<reason>"`` would then fail validation. Floor at "0s" so the
    rejection later is on the *content* of the directive, not on
    nonsense the block message itself emitted.
    """
    if seconds <= 0:
        return "0s"
    if seconds % 86_400 == 0:
        return f"{seconds // 86_400}d"
    if seconds % 3600 == 0:
        return f"{seconds // 3600}h"
    if seconds % 60 == 0:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def _hash_path(path: str) -> str:
    """SHA-256 prefix of an absolute path. Cheap, irreversible, and
    stable across invocations on the same machine — gives dashboards
    a way to dedupe "same file scanned 12 times today" without
    shipping the customer's directory layout off-device. NF-PRIV-1."""
    import hashlib
    return hashlib.sha256(path.encode("utf-8", errors="replace")).hexdigest()[:16]


def _enqueue_read_scan_events(
    scan_results: List[FileScanResult],
    *,
    findings_by_source: dict,
    hook_event: Optional[str],
    raw_event_name: str,
) -> None:
    """Push one ``read_content_scanned`` telemetry event per file the
    content-scan augmenter examined. Best-effort: any failure here is
    swallowed so a misconfigured telemetry path can't break the hook.

    Fields emitted:
    - ``path_hash``     — sha256 prefix of the absolute path (privacy)
    - ``status``        — one of scanned / cached_clean / cached_dirty /
                          skipped_missing / skipped_too_large / skipped_binary
    - ``bytes_scanned`` — bytes actually read from disk (0 on cache hits + skips)
    - ``finding_count`` — number of findings attributed to this file
    - ``cache_hit``     — True iff status starts with ``cached_``
    """
    if not hook_event:
        return
    for r in scan_results:
        try:
            n_findings = len(findings_by_source.get(r.path, []))
            event = guard_telemetry.make_event(
                "read_content_scanned",
                agent=_agent_from_event_name(raw_event_name),
                hook_event=hook_event,
                path_hash=_hash_path(r.path),
                status=r.status,
                bytes_scanned=r.bytes_scanned,
                finding_count=n_findings,
                cache_hit=r.status.startswith("cached_"),
            )
            guard_telemetry.enqueue(event)
        except Exception:  # noqa: BLE001
            pass


def _enqueue_decision_event(
    *,
    hook_event: Optional[str],
    decision,
    source_label: str,
    raw_event_name: str,
    logging_mode: LoggingMode = LoggingMode.PRUDENT,
    bypass: Optional[guard_exceptions.ExceptionEntry] = None,
) -> None:
    """Push a ``decision`` telemetry event. Best-effort: any failure
    is swallowed so the hook still returns its decision.

    Honours the policy's logging mode:
    - ``verbose`` — every hook invocation gets a decision event.
    - ``prudent`` — skip clean events (mode in {OBSERVE} AND no
      findings). Audit-worthy events still go through.

    When ``bypass`` is set, the event also carries the bypassing
    exception's id + reason — the audit trail for what the user
    self-justified.
    """
    if not hook_event:
        return
    # Prudent: drop events that aren't audit-worthy.
    if logging_mode is LoggingMode.PRUDENT:
        if decision.mode is Mode.OBSERVE and not decision.findings and bypass is None:
            return
    try:
        findings_payload = [f.to_dict() for f in decision.findings]
        extras = {}
        if bypass is not None:
            extras = {
                "bypass_used": True,
                "bypass_exception_id": bypass.id,
                "bypass_rule": bypass.rule,
                "bypass_reason": bypass.reason,
                "bypass_granted_by": bypass.granted_by,
            }
        event = guard_telemetry.make_event(
            "decision",
            agent=_agent_from_event_name(raw_event_name),
            hook_event=hook_event,
            decision=decision.mode.value,
            source_label=source_label,
            findings=findings_payload,
            **extras,
        )
        guard_telemetry.enqueue(event)
    except Exception:  # noqa: BLE001
        pass


def _handle_prompt_submit(
    body: dict, inspector: Inspector, policy: PolicyEngine, raw_event_name: str
) -> int:
    prompt = body.get("prompt") or ""

    # Phase B+ in-session bypass: a user blocked on a prior hook
    # invocation can resend their prompt prefixed with a directive.
    # Two shapes are accepted:
    #
    # - Full:    `cloudanix:allow <rule> <ttl> "<reason>"`
    # - Autofill (T16): bare `cloudanix:allow` — resolves the most
    #   recent block from pending_block.json. Auto-generates rule,
    #   TTL, and reason from the stashed block context.
    #
    # In both cases we consume the directive line, grant the
    # exception, strip the line, and let inspection see the cleaned
    # prompt. The result is that the directive is never visible to
    # the agent.
    directive, cleaned = guard_directive.parse(prompt)
    if directive is not None:
        if directive.is_autofill:
            resolved = _resolve_autofill_directive(policy)
            if resolved is None:
                return _EXIT_BLOCK  # error already written to stderr
            rule, ttl_seconds, reason, granted_by, source_label = resolved
        else:
            rule = directive.rule
            ttl_seconds = directive.ttl_seconds
            reason = directive.reason
            granted_by = "self_inline"
            source_label = None

        rejection = policy.inline_bypass.validate(rule, ttl_seconds, reason)
        if rejection is not None:
            sys.stderr.write(
                f"Cloudanix Guard: inline bypass rejected — {rejection}.\n"
                f"  rule:   {rule}\n"
                f"  ttl:    {ttl_seconds}s\n"
            )
            return _EXIT_BLOCK

        capped_ttl = policy.inline_bypass.cap_ttl(ttl_seconds)
        try:
            entry = guard_exceptions.grant(
                rule,
                reason,
                duration_seconds=capped_ttl,
                granted_by=granted_by,
            )
        except ValueError as e:
            # Reason-scan rejection (a secret in the --reason text) lands
            # here. Surface it on the hook stderr so the user knows to
            # rephrase, and block the prompt rather than silently letting
            # it through ungated.
            sys.stderr.write(
                f"Cloudanix Guard: inline bypass rejected — {e}.\n"
            )
            return _EXIT_BLOCK
        # Grant succeeded — only NOW is it safe to clear the
        # pending-block stash (autofill path only; full-form never
        # touched it). Earlier we *peeked* the stash; if the grant
        # had failed past this point the user would have nothing to
        # retry against.
        if directive.is_autofill:
            guard_pending_block.clear()

        granted_msg = (
            f"Cloudanix Guard: inline bypass granted for {rule} "
            f"({capped_ttl}s, exception {entry.short_id}). "
            f"Reason: {reason!r}\n"
        )
        if source_label:
            granted_msg += f"  resolves last block: {source_label}\n"
        sys.stderr.write(granted_msg)
        _safely_enqueue(
            "exception_self_approved",
            exception_id=entry.id,
            rule=entry.rule,
            reason=entry.reason,
            expires_at=entry.expires_at,
            via="inline_directive_autofill" if directive.is_autofill else "inline_directive",
        )

        # If the user typed ONLY the directive (no body after it), we
        # have a protocol problem: Claude Code's UserPromptSubmit hook
        # can't rewrite the prompt text. Letting the hook exit 0
        # means Claude receives the bare `cloudanix:allow` string and
        # lectures the user about directive grammar (the model has no
        # idea T16's autofill is a thing).
        #
        # Fix: exit 2 with a clear "bypass granted; send your real ask"
        # message. The directive never reaches the agent; the user's
        # NEXT prompt is their actual ask and goes through with the
        # exception already active. Honest two-step UX.
        #
        # The combined form (`cloudanix:allow\n<body>`) is unaffected —
        # the body is what Claude sees and responds to; the directive
        # line at the top is harmless noise.
        cleaned_stripped = (cleaned or "").strip()
        if not cleaned_stripped:
            sys.stderr.write(
                f"  Bypass is active for the next {capped_ttl}s. Send your "
                f"actual ask as your next prompt — the agent will process "
                f"it under this exception.\n"
            )
            return _EXIT_BLOCK
        prompt = cleaned or ""

    payload = Payload(prompt=prompt)
    return _handle_payload(
        payload, inspector, policy,
        as_json=False, source_label="prompt",
        hook_event=raw_event_name,
    )


def _resolve_autofill_directive(policy: PolicyEngine):
    """Peek at the pending-block stash and synthesize directive args.

    Returns a 5-tuple ``(rule, ttl_seconds, reason, granted_by,
    source_label)`` on success, or ``None`` on rejection (a stderr
    line is already written in that case so the caller just returns
    EXIT_BLOCK).

    The auto-generated reason captures the rule + source label + the
    block timestamp so a security-team audit-log read still gives
    enough context to reconstruct what happened, even though the
    user didn't type a free-form rationale.

    Important: we *peek*, not consume. The caller clears the stash
    only after the grant actually lands (see ``_handle_prompt_submit``).
    Earlier versions consumed eagerly, which silently dropped the
    stash when validate / grant rejected — leaving the user with
    nothing to retry against.
    """
    max_age = policy.inline_bypass.pending_block_max_age_seconds
    pending = guard_pending_block.peek_if_fresh(max_age_seconds=max_age)
    if pending is None:
        # No fresh stash. Before saying "no recent block to resolve",
        # check whether a self_inline_autofill grant landed in the
        # last minute — that means the user typed `cloudanix:allow`,
        # got the bypass-granted EXIT_BLOCK from T16.1, and then
        # autopilot-resent the directive instead of their actual ask.
        # Telling them "no recent block" in that state is confusing
        # because the bypass *is* active.
        recent = _recent_autofill_grant(seconds=60)
        if recent is not None:
            remaining = _format_exception_remaining(recent.expires_at) or "active"
            sys.stderr.write(
                f"Cloudanix Guard: bypass already active for {recent.rule} "
                f"(exception {recent.short_id}, {remaining}).\n"
                f"  Send your actual ask as your next prompt — the agent will "
                f"process it under this exception.\n"
            )
            return None
        sys.stderr.write(
            "Cloudanix Guard: inline bypass rejected — no recent block to "
            f"resolve (none stashed, or older than {max_age}s).\n"
            "  Use the full form: cloudanix:allow <rule> <ttl> \"<reason>\".\n"
        )
        return None

    rule = pending.get("rule") or ""
    source_label = pending.get("source_label") or ""
    blocked_at = pending.get("blocked_at") or ""
    ttl_seconds = policy.inline_bypass.default_ttl_seconds
    reason = (
        f"approved after {pending.get('hook_event') or 'hook'} block on "
        f"{rule} at {blocked_at} (source={source_label or 'prompt'})"
    )
    return rule, ttl_seconds, reason, "self_inline_autofill", source_label


def _recent_autofill_grant(*, seconds: int):
    """Most-recent self_inline_autofill exception granted within the
    last ``seconds`` seconds, or ``None``. Used by the autofill
    resolver to detect autopilot re-sends of `cloudanix:allow` after
    a successful grant."""
    from datetime import datetime, timedelta, timezone
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=seconds)
    best = None
    for e in guard_exceptions.list_active():
        if e.granted_by != "self_inline_autofill":
            continue
        try:
            when = datetime.fromisoformat(e.granted_at)
        except (TypeError, ValueError):
            continue
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        if when < cutoff:
            continue
        if best is None or when > best[0]:
            best = (when, e)
    return best[1] if best else None


def _handle_pre_tool_use(
    body: dict, inspector: Inspector, policy: PolicyEngine, raw_event_name: str
) -> int:
    tool_name = body.get("tool_name") or ""
    tool_input = body.get("tool_input") or {}
    payload = payload_from_tool_use(tool_name, tool_input)
    # If the adapter couldn't find anything worth scanning, just allow.
    if not payload.prompt and not payload.files:
        return 0

    # Proactive content scan: if the policy enables it, read up to
    # `max_scan_bytes` of any file the agent is about to read (Read /
    # cat passwords.txt / ...) so the inspector sees actual content,
    # not just the path. Closes the "user asks agent to read
    # passwords.txt" DLP gap that path-only inspection misses.
    scan_results: List[FileScanResult] = []
    replayed_findings: List[Finding] = []
    rcs = policy.read_content_scan
    if rcs.enabled:
        scan_results = augment_with_file_content(
            payload,
            max_scan_bytes=rcs.max_scan_bytes,
            skip_binary=rcs.skip_binary,
            cache_enabled=rcs.cache_enabled,
            cache_ttl_seconds=rcs.cache_ttl_seconds,
            cache_max_entries=rcs.cache_max_entries,
            allow_roots=list(rcs.allow_roots) if rcs.allow_roots else None,
        )
        for r in scan_results:
            if r.status == "cached_dirty":
                replayed_findings.extend(r.cached_findings)

    return _handle_payload(
        payload,
        inspector,
        policy,
        as_json=False,
        source_label=f"tool={tool_name}",
        hook_event=raw_event_name,
        scan_results=scan_results,
        replayed_findings=replayed_findings,
    )


def _handle_payload(
    payload: Payload,
    inspector: Inspector,
    policy: PolicyEngine,
    *,
    as_json: bool,
    source_label: str = "payload",
    hook_event: Optional[str] = None,
    scan_results: Optional[List[FileScanResult]] = None,
    replayed_findings: Optional[List[Finding]] = None,
) -> int:
    findings = list(inspector.inspect(payload))
    if replayed_findings:
        findings.extend(replayed_findings)
    decision = policy.decide(findings)

    # Persist the freshly-scanned files' results to the cache so the
    # next read of the same unchanged file is a HIT. We do this
    # before any blocking-return path so a blocked-on-read still
    # primes the cache for the user's eventual retry.
    if scan_results:
        rcs = policy.read_content_scan
        findings_by_source: dict[str, list[Finding]] = {}
        for f in findings:
            findings_by_source.setdefault(f.source, []).append(f)
        try:
            record_scan_in_cache(
                scan_results,
                findings_by_source,
                cache_enabled=rcs.cache_enabled,
                cache_ttl_seconds=rcs.cache_ttl_seconds,
                cache_max_entries=rcs.cache_max_entries,
            )
        except Exception:  # noqa: BLE001 — cache writes must never break the hook
            pass
        # Emit one `read_content_scanned` telemetry event per file the
        # scanner actually examined or short-circuited. Path is hashed
        # so we never ship customer paths off-device.
        _enqueue_read_scan_events(
            scan_results,
            findings_by_source=findings_by_source,
            hook_event=hook_event,
            raw_event_name=hook_event or "",
        )

    # Phase B: if every contributing finding is covered by an active
    # self-exception, demote the decision to a pass-through. The
    # decision itself stays warn_self_justify in the audit trail; the
    # bypass is recorded alongside it.
    bypass = _bypass_for_decision(decision)

    # Telemetry: enqueue a decision event before returning to the
    # parent agent. enqueue() is a no-op if telemetry isn't configured,
    # and is wrapped so any failure here cannot break the hook.
    _enqueue_decision_event(
        hook_event=hook_event,
        decision=decision,
        source_label=source_label,
        raw_event_name=hook_event or "",
        logging_mode=policy.logging_mode,
        bypass=bypass,
    )

    if as_json:
        result = apply_decision(payload, decision)
        sys.stdout.write(json.dumps(result))
        sys.stdout.write("\n")
        sys.stdout.flush()
        return _EXIT_BLOCK if decision.mode.is_blocking() else 0

    # Hook output: stderr for blocking modes so both platforms show it
    # to the user or the LLM. Stdout for observe / warn_continue that
    # want to inject context (short summary on stdout is picked up by
    # Kiro as context; Claude Code ignores plain stdout on
    # UserPromptSubmit unless `continue` is false — harmless either way).

    # Phase B: if a bypass exists for this decision, short-circuit
    # the block path and emit a transparent stderr note so the user
    # (and the agent) sees the bypass is active. The audit / telemetry
    # already captured the bypass details above.
    if bypass is not None:
        remaining = ""
        if bypass.expires_at:
            from datetime import datetime, timezone
            try:
                exp = datetime.fromisoformat(bypass.expires_at)
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                secs = int((exp - datetime.now(timezone.utc)).total_seconds())
                if secs > 0:
                    m, s = divmod(secs, 60)
                    remaining = f", {m}m {s}s left"
            except ValueError:
                pass
        sys.stderr.write(
            f"cloudanix-guard: bypass active under exception {bypass.short_id} "
            f"(rule={bypass.rule}; reason={bypass.reason!r}{remaining}). "
            f"Findings recorded in the audit log.\n"
        )
        return 0

    # In hook mode, REDACT effectively blocks: the hook protocol can't
    # rewrite the prompt on the wire (only the legacy JSON-mode path
    # does that). So redact-on-hook = exit 2 with a "would have
    # redacted" stderr. The blocking modes do the same.
    if decision.mode.is_blocking() or decision.mode is Mode.REDACT:
        contributing = decision.findings[0] if decision.findings else None

        # Stash a pending-block descriptor so the next no-args
        # `cloudanix:allow` from the user can resolve this block
        # without retyping the rule / TTL / reason. Only stashed when
        # the rule is in the inline allowlist — otherwise no autofill
        # could ever produce a valid grant anyway, and we'd just
        # confuse the user with a "rejected" message instead of the
        # clearer "use the side-band CLI" path.
        if (
            contributing is not None
            and policy.inline_bypass.enabled
            and policy.inline_bypass.rule_is_allowed(contributing.qualified_rule_id)
        ):
            guard_pending_block.stash(
                rule=contributing.qualified_rule_id,
                source_label=source_label,
                tool_name=None if source_label == "prompt" else source_label.removeprefix("tool="),
                hook_event=hook_event,
                mode_value=decision.mode.value,
            )

        header, footer = _block_message(
            decision.mode,
            contributing=contributing,
            inline_bypass=policy.inline_bypass,
            source_label=source_label,
        )
        sys.stderr.write(f"{header}\n")
        sys.stderr.write(f"  scope: {source_label}\n")
        sys.stderr.write(f"  mode:  {decision.mode.value}\n")
        sys.stderr.write(f"  findings ({len(decision.findings)}):\n")
        sys.stderr.write(_format_findings(decision.findings) + "\n")
        sys.stderr.write(footer + "\n")
        return _EXIT_BLOCK

    # allow or warn
    if findings:
        # Print a one-liner to stdout for Kiro to pick up as context.
        summary = f"Cloudanix Guard: {len(findings)} low-severity finding(s) in {source_label} — allowed."
        sys.stdout.write(summary + "\n")
    return 0


# ---------------------------------------------------------------------- install

def _install_targets(target: str) -> tuple[bool, bool, bool]:
    """Expand a CLI target choice into (do_kiro, do_claude, do_codex).

    ``all`` covers every supported agent. ``both`` is a legacy alias
    for kiro+claude (kept so existing scripts and docs don't break);
    note it does NOT include codex — by design, since codex needs its
    own approval flow after install.
    """
    if target == "all":
        return (True, True, True)
    if target == "both":
        return (True, True, False)
    return (target == "kiro", target == "claude", target == "codex")


def cmd_install(args: argparse.Namespace) -> int:
    guard_cmd = args.guard_cmd or resolve_guard_command()
    # If --profile was passed, embed CLOUDANIX_GUARD_PROFILE=<name>
    # as a prefix on every wired hook command so the hook process
    # uses the right state dir. Plan functions don't need to know
    # about profiles — they just embed whatever guard_cmd they're
    # given. See `with_profile_prefix` docstring + the README's
    # "Multiple profiles" section for the workflow.
    guard_cmd = with_profile_prefix(guard_cmd, getattr(args, "profile", None))
    do_kiro, do_claude, do_codex = _install_targets(args.target)

    targets = []
    if do_kiro:
        targets.append((f"kiro ({args.scope})", plan_kiro(guard_cmd, scope=args.scope)))
    if do_claude:
        targets.append((f"claude ({args.scope})", plan_claude(guard_cmd, scope=args.scope)))
    if do_codex:
        targets.append((f"codex ({args.scope})", plan_codex(guard_cmd, scope=args.scope)))

    if not targets:
        print("error: pick at least one target: kiro | claude | codex | all", file=sys.stderr)
        return 1

    for label, plan in targets:
        print(f"── {label} ──")
        for path, _body in plan.files:
            print(f"  write:  {path}")
        for orig, backup in plan.backups:
            print(f"  backup: {orig}  →  {backup}")
        for note in plan.notes:
            print(f"  note:   {note}")
        for skipped in plan.skipped:
            print(f"  skip:   {skipped}")
        if not plan.files and not plan.backups:
            print("  (no changes required — already up-to-date)")
        print()

    if args.dry_run:
        print("(dry-run — no files written. Re-run without --dry-run to apply.)")
        return 0

    for _label, plan in targets:
        apply_install(plan)

    _safely_enqueue("install", targets=[args.target], scope=args.scope)

    print("Installed. Next steps:")
    if do_kiro:
        print(
            "  • Kiro: hooks are now on every agent in your "
            f"{args.scope}-scope agents directory. Start (or restart) any "
            "agent and it is protected."
        )
    if do_claude:
        print(
            "  • Claude Code: start a new session — hooks take effect immediately."
        )
    if do_codex:
        print(
            "  • Codex CLI: hook is written but NOT YET ACTIVE. Run `codex` "
            "once and approve the cloudanix-guard hook when Codex prompts you "
            "to trust it (Codex hashes every hook command and won't invoke an "
            "untrusted one — this is a security feature, not a bug)."
        )
    print(
        f"  • Test a blocking scenario:\n"
        f"      echo '{{\"hook_event_name\":\"PreToolUse\",\"tool_name\":\"Read\","
        f"\"tool_input\":{{\"file_path\":\"/tmp/.env\"}}}}' | {guard_cmd} hook; echo exit=$?"
    )
    return 0


# ---------------------------------------------------------------------- uninstall

def cmd_uninstall(args: argparse.Namespace) -> int:
    do_kiro, do_claude, do_codex = _install_targets(args.target)

    targets = []
    if do_kiro:
        targets.append((f"kiro ({args.scope})", plan_kiro_uninstall(scope=args.scope)))
    if do_claude:
        targets.append((f"claude ({args.scope})", plan_claude_uninstall(scope=args.scope)))
    if do_codex:
        targets.append((f"codex ({args.scope})", plan_codex_uninstall(scope=args.scope)))

    if not targets:
        print("error: pick at least one target: kiro | claude | codex | all", file=sys.stderr)
        return 1

    nothing_to_do = True
    for label, plan in targets:
        print(f"── {label} ──")
        for path, _body in plan.files:
            print(f"  rewrite:  {path}  (cloudanix entries removed)")
            nothing_to_do = False
        for orig, backup in plan.backups:
            print(f"  backup:   {orig}  →  {backup}")
        for note in plan.notes:
            print(f"  note:     {note}")
        for skipped in plan.skipped:
            print(f"  skip:     {skipped}")
        if not plan.files and not plan.backups:
            print("  (no cloudanix-guard entries found — nothing to remove)")
        print()

    if args.dry_run:
        print("(dry-run — no files written. Re-run without --dry-run to apply.)")
        return 0

    if nothing_to_do:
        print("Nothing to uninstall.")
        return 0

    for _label, plan in targets:
        apply_install(plan)

    _safely_enqueue("uninstall", targets=[args.target], scope=args.scope)

    print("Uninstalled. The cloudanix-guard hooks are no longer wired in.")
    print("You can leave the python package installed; re-run "
          "`cloudanix-guard install both` later to re-enable.")
    return 0


# ---------------------------------------------------------------------- pause / resume / status

def cmd_pause(args: argparse.Namespace) -> int:
    if args.indefinite:
        duration_seconds = None
    else:
        try:
            duration_seconds = guard_state.parse_duration(args.duration)
        except ValueError as e:
            print(f"error: {e}", file=sys.stderr)
            return 1

    state = guard_state.pause(reason=args.reason, duration_seconds=duration_seconds)

    _safely_enqueue(
        "pause",
        reason=state.reason,
        duration_seconds=duration_seconds,
        expires_at=state.expires_at,
    )

    print(f"Cloudanix Guard: PAUSED.")
    print(f"  reason:     {state.reason}")
    print(f"  paused at:  {state.paused_at}")
    if state.expires_at:
        print(f"  expires at: {state.expires_at}  ({guard_state.format_remaining(state)})")
        print(f"  Tip: run `cloudanix-guard resume` to re-enable early.")
    else:
        print(f"  expires:    never (indefinite). Run `cloudanix-guard resume` "
              f"when done — the firewall stays off until then.")
    print(f"  audit log:  {guard_state.audit_log_path()}")
    return 0


def cmd_resume(args: argparse.Namespace) -> int:
    prior = guard_state.resume()
    if prior is None:
        print("Cloudanix Guard: not currently paused. Nothing to do.")
        return 0

    _safely_enqueue(
        "resume",
        was_paused_at=prior.paused_at,
        reason=prior.reason,
    )

    print("Cloudanix Guard: RESUMED.")
    print(f"  was paused at: {prior.paused_at}")
    print(f"  reason:        {prior.reason}")
    print(f"  audit log:     {guard_state.audit_log_path()}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    state = guard_state.is_paused()
    if state is None:
        print("Cloudanix Guard: ACTIVE.")
        print(f"  state file: {guard_state.state_path()}")
        print(f"  audit log:  {guard_state.audit_log_path()}")
    else:
        print("Cloudanix Guard: PAUSED.")
        print(f"  reason:     {state.reason}")
        print(f"  paused at:  {state.paused_at}")
        if state.expires_at:
            print(f"  expires at: {state.expires_at}  ({guard_state.format_remaining(state)})")
        else:
            print("  expires:    never (indefinite)")
        print(f"  user:       {state.user}")
        print(f"  audit log:  {guard_state.audit_log_path()}")

    # Profile — surfaced explicitly when set, so a power-user with N
    # profiles can confirm which one this invocation is operating on
    # before chasing "why isn't my console seeing data". Suppressed in
    # the common case (no profile env var) to avoid noise.
    profile = os.environ.get("CLOUDANIX_GUARD_PROFILE", "").strip()
    if profile:
        print()
        print("Profile:")
        print(f"  active:     {profile}")
        print(f"  state dir:  {guard_config.config_dir()}")

    # Active exceptions — shown if any. Enriched with granted_via
    # (cli / inline_directive / etc) and a human-readable
    # time-remaining so the user can answer "is the bypass I just
    # granted still alive?" without reaching for a calculator.
    active = guard_exceptions.list_active()
    if active:
        print()
        print("Active self-exceptions:")
        for e in active:
            line = f"  {e.short_id}  rule={e.rule}"
            remaining = _format_exception_remaining(e.expires_at)
            if remaining:
                line += f"  {remaining}"
            line += f"  granted_by={e.granted_by}"
            line += f"  reason={e.reason!r}"
            print(line)
        print(f"  (Revoke with: cloudanix-guard revoke-exception <id>)")

    # Telemetry / config view — always shown after the active/paused block.
    cfg = guard_config.load()
    print()
    print("Telemetry:")
    if cfg.telemetry_enabled:
        print(f"  status:     CONFIGURED")
        print(f"  email:      {cfg.email or '(unset)'}")
        print(f"  console:    {cfg.console_url}")
        print(f"  endpoint:   {cfg.telemetry_endpoint()}")
        print(f"  token:      {cfg.redacted_token()}")
        spool = guard_telemetry.spool_path()
        spool_n = _count_lines(spool) if spool.exists() else 0
        print(f"  spool:      {spool}  ({spool_n} event(s) queued)")
        # Telemetry health — last hook auto-flush + backoff state +
        # accumulated overflow stats if any. These three together
        # answer "why isn't my data showing up on the console?".
        backoff = guard_telemetry._read_backoff_state()  # noqa: SLF001 — read-only diagnostic
        last_flush = backoff.get("last_hook_flush_at")
        if last_flush:
            print(f"  last flush: {last_flush}  (auto-flush at hook exit, throttled 60s)")
        fails = int(backoff.get("consecutive_failures") or 0)
        if fails:
            print(f"  backoff:    {fails} consecutive failure(s); next retry after {backoff.get('next_retry_at')}")
        overflow = guard_telemetry._read_overflow_state()  # noqa: SLF001 — read-only diagnostic
        if overflow.get("dropped_count"):
            print(
                f"  overflow:   {overflow.get('dropped_count')} event(s) dropped from spool "
                f"(awaiting next flush to ship a queue_overflow_dropped event)"
            )
    else:
        print(f"  status:     NOT CONFIGURED")
        print(f"  config:     {guard_config.config_path()}")
        print(f"  Run: cloudanix-guard configure --email ... --console-url ... --api-token ...")

    # Policy sync — surfaces last-sync state + which policy is being applied.
    sync_state = guard_sync._load_state()  # noqa: SLF001 — internal helper, read-only
    cached = guard_sync.cached_policy_path()
    print()
    print("Policy sync:")
    print(f"  source:           {'cached (synced)' if cached.exists() else 'packaged default'}")
    print(f"  last synced at:   {sync_state.get('last_synced_at') or '(never)'}")
    print(f"  policy version:   {sync_state.get('last_policy_version') if sync_state.get('last_policy_version') is not None else '(none)'}")
    print(f"  etag:             {sync_state.get('last_policy_etag') or '(none)'}")
    return 0


def _format_exception_remaining(expires_at: Optional[str]) -> str:
    """Render "12m 34s left" / "expired" / "" from an ISO expires_at.

    Returns empty string for indefinite exceptions (so the caller can
    `if remaining: line += ...` without a special case)."""
    if not expires_at:
        return ""
    from datetime import datetime, timezone
    try:
        when = datetime.fromisoformat(expires_at)
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return ""
    secs = int((when - datetime.now(timezone.utc)).total_seconds())
    if secs <= 0:
        return "expired"
    m, s = divmod(secs, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}h {m}m left"
    if m:
        return f"{m}m {s}s left"
    return f"{s}s left"


# ---------------------------------------------------------------------- configure / flush

def cmd_configure(args: argparse.Namespace) -> int:
    """Update the per-user config. Partial-merge — only fields you pass
    are changed; the rest are kept."""
    if args.show:
        cfg = guard_config.load()
        print(f"config file: {guard_config.config_path()}")
        print(f"  email:       {cfg.email or '(unset)'}")
        print(f"  console_url: {cfg.console_url or '(unset)'}")
        print(f"  api_token:   {cfg.redacted_token()}")
        return 0

    if not any([args.email, args.console_url, args.api_token]):
        print(
            "error: pass at least one of --email / --console-url / --api-token, "
            "or use --show to display current config.",
            file=sys.stderr,
        )
        return 1

    cfg = guard_config.load()
    if args.email is not None:
        cfg.email = args.email or None
    if args.console_url is not None:
        cfg.console_url = args.console_url or None
    if args.api_token is not None:
        cfg.api_token = args.api_token or None

    path = guard_config.save(cfg)
    print(f"Saved to {path} (mode 0600).")
    print(f"  email:       {cfg.email or '(unset)'}")
    print(f"  console_url: {cfg.console_url or '(unset)'}")
    print(f"  api_token:   {cfg.redacted_token()}")
    if cfg.telemetry_enabled:
        print(f"  endpoint:    {cfg.telemetry_endpoint()}")
    else:
        print("  Telemetry stays OFF until both --console-url and --api-token are set.")
    return 0


def cmd_flush(args: argparse.Namespace) -> int:
    """Manually drain the telemetry spool. Returns non-zero on retryable
    failure so a cron / wrapper can decide whether to alert.

    Output policy: silent by default on no-op outcomes (nothing-to-flush
    or in-backoff) so cron-redirected stdout doesn't bloat /tmp. Real
    sends and real failures always print. Use ``--verbose`` to see
    every outcome."""
    result = guard_telemetry.flush_once(timeout_seconds=args.timeout)

    # Quiet path: no output unless something genuinely happened.
    if not args.verbose:
        noop = (
            result.sent == 0
            and (result.reason or "").startswith(("nothing to flush", "in backoff"))
            and not result.status_code
        )
        if noop:
            return 0
        if result.sent == 0 and result.reason and "not configured" in result.reason:
            return 0

    if result.reason:
        print(f"flush: {result.reason}")
    print(f"  sent:            {result.sent}")
    print(f"  spool_remaining: {result.spool_remaining}")
    if result.status_code:
        print(f"  http_status:     {result.status_code}")
    if result.duplicate:
        print(f"  duplicate:       true (server already had this batch_uid)")
    return 1 if result.retryable else 0


# ---------------------------------------------------------------------- sync

def cmd_sync(args: argparse.Namespace) -> int:
    """Poll the console for an updated policy.

    Returns 0 for any non-error outcome (200, 304, or "not in window"
    skip). Non-zero only on transport/auth/server failure — so a
    cron wrapper can decide whether to alert.

    Output policy: silent by default on no-op outcomes (skipped /
    304) so cron tmp logs stay tiny. Real policy changes and real
    failures always print. ``--verbose`` to see everything.
    """
    result = guard_sync.sync_once(force=args.force, timeout_seconds=args.timeout)

    # Quiet path: skipped and 304 are the common steady-state outcomes
    # the user doesn't need to see in tmp logs every 5 minutes.
    if not args.verbose and result.status in ("skipped", "304"):
        return 0

    label = result.status.upper() if len(result.status) <= 4 else result.status
    print(f"Sync: {label}", end="")
    if result.policy_version is not None:
        print(f" — version {result.policy_version}", end="")
    if result.reason:
        print(f" ({result.reason})", end="")
    print()

    if result.status in ("200", "304", "skipped"):
        return 0
    return 1


# ---------------------------------------------------------------------- request-exception / revoke-exception

def cmd_request_exception(args: argparse.Namespace) -> int:
    """Grant a self-justification exception for a single rule.

    Designed for the false-positive escape hatch on
    ``warn_self_justify`` blocks. The block stderr quotes the exact
    rule id to paste here; the agent (Claude / Kiro) can also call
    this command directly via Bash when the user replies "yeah it's
    fine."
    """
    try:
        duration_seconds = guard_state.parse_duration(args.duration)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    try:
        entry = guard_exceptions.grant(
            rule=args.rule,
            reason=args.reason,
            duration_seconds=duration_seconds,
        )
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    _safely_enqueue(
        "exception_self_approved",
        exception_id=entry.id,
        rule=entry.rule,
        reason=entry.reason,
        expires_at=entry.expires_at,
        duration_seconds=duration_seconds,
    )

    print(f"Cloudanix Guard: exception GRANTED.")
    print(f"  id:         {entry.short_id}")
    print(f"  rule:       {entry.rule}")
    print(f"  reason:     {entry.reason}")
    print(f"  granted at: {entry.granted_at}")
    print(f"  expires at: {entry.expires_at}")
    print(f"  scope:      self-justification (this device only)")
    print()
    print("Re-run your original prompt; the firewall will let it through.")
    print(f"To end the bypass early: cloudanix-guard revoke-exception {entry.short_id}")
    return 0


def cmd_revoke_exception(args: argparse.Namespace) -> int:
    """Revoke an active exception by id (full or short prefix)."""
    target_id = args.exception_id.strip()
    # Always resolve via prefix-match against the active set — that
    # way a full id, a short 12-char id, or any unambiguous prefix
    # in between all work the same way.
    candidates = [e for e in guard_exceptions.list_active() if e.id.startswith(target_id)]
    if len(candidates) > 1:
        print(
            f"error: id {target_id!r} matches multiple active exceptions "
            f"({', '.join(c.short_id for c in candidates)}). Use a longer prefix.",
            file=sys.stderr,
        )
        return 1
    if candidates:
        target_id = candidates[0].id
    # If no candidates match, fall through to revoke() with the literal —
    # which will produce the friendly "no active exception" message.

    prior = guard_exceptions.revoke(target_id)
    if prior is None:
        print(
            f"Cloudanix Guard: no active exception with id {target_id!r}. "
            f"Nothing to do.",
        )
        return 0

    _safely_enqueue(
        "exception_revoked",
        exception_id=prior.id,
        rule=prior.rule,
        reason=prior.reason,
    )

    print(f"Cloudanix Guard: exception REVOKED.")
    print(f"  id:     {prior.short_id}")
    print(f"  rule:   {prior.rule}")
    print(f"  reason: {prior.reason}")
    return 0


# ---------------------------------------------------------------------- logs

def cmd_logs(args: argparse.Namespace) -> int:
    """Pretty-print recent firewall activity.

    Sources merged in this order:
    - **audit.log** — pause / resume / auto_resume_on_expiry events. Persistent.
    - **queue.jsonl** — decision / install / uninstall events queued for upstream flush.
      These drain on `cloudanix-guard flush`; the persistent record lives in the
      Cloudanix Console after that point.
    """
    entries: List[dict] = []
    entries.extend(_read_audit_entries())
    entries.extend(_read_spool_entries())
    entries.extend(_read_exception_entries())

    entries.sort(key=lambda e: e.get("_ts") or "")
    entries = entries[-args.limit:]

    if args.json:
        for e in entries:
            # Drop internal helper fields before printing.
            clean = {k: v for k, v in e.items() if not k.startswith("_")}
            print(json.dumps(clean))
        return 0

    if not entries:
        print("(no recent activity — try a few hook events first, then re-run)")
        return 0

    # Table format. Tight columns, no third-party deps.
    print(f"{'TIMESTAMP':<22}  {'SOURCE':<6}  {'EVENT':<22}  DETAILS")
    for e in entries:
        ts = e.get("_ts") or ""
        src = e.get("_source") or ""
        kind = e.get("_kind") or ""
        details = _format_entry_details(e)
        print(f"{ts:<22}  {src:<6}  {kind:<22}  {details}")

    spool_n = _count_lines(guard_telemetry.spool_path()) if guard_telemetry.spool_path().exists() else 0
    if spool_n > 0:
        print()
        print(f"[{spool_n} event(s) queued for upstream — run `cloudanix-guard flush` to send]")
    return 0


def _read_audit_entries() -> List[dict]:
    path = guard_state.audit_log_path()
    if not path.exists():
        return []
    out: List[dict] = []
    try:
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
            except json.JSONDecodeError:
                continue
            out.append({
                **raw,
                "_ts": raw.get("ts"),
                "_source": "audit",
                "_kind": raw.get("event") or "?",
            })
    except OSError:
        return []
    return out


def _read_exception_entries() -> List[dict]:
    """Surface granted self-exceptions in the logs view.

    Each exception produces one row tagged with its current status:
    ``active``, ``expired``, or ``revoked``. The timestamp shown is
    the grant time; revocations / expiries are derived from the
    other fields. Audit-log resume / pause events stay in
    ``_read_audit_entries`` — this reader is just for the
    exception store.
    """
    out: List[dict] = []
    now_iso = guard_exceptions._utcnow_iso()  # noqa: SLF001 — internal helper
    for entry in guard_exceptions.list_all():
        if entry.revoked_at:
            status = "revoked"
        elif entry.expires_at and entry.expires_at <= now_iso:
            status = "expired"
        else:
            status = "active"
        out.append({
            "id": entry.id,
            "short_id": entry.short_id,
            "rule": entry.rule,
            "reason": entry.reason,
            "granted_at": entry.granted_at,
            "expires_at": entry.expires_at,
            "revoked_at": entry.revoked_at,
            "granted_by": entry.granted_by,
            "_ts": entry.granted_at,
            "_source": "exception",
            "_kind": f"exception/{status}",
        })
    return out


def _read_spool_entries() -> List[dict]:
    path = guard_telemetry.spool_path()
    if not path.exists():
        return []
    out: List[dict] = []
    try:
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
            except json.JSONDecodeError:
                continue
            kind = raw.get("event_type") or "?"
            # Tag decision events with the action so the table is informative.
            if kind == "decision" and raw.get("decision"):
                kind = f"decision/{raw['decision']}"
            out.append({
                **raw,
                "_ts": raw.get("occurred_at"),
                "_source": "spool",
                "_kind": kind,
            })
    except OSError:
        return []
    return out


def _format_entry_details(entry: dict) -> str:
    src = entry.get("_source")
    if src == "audit":
        bits = []
        if entry.get("reason"):
            bits.append(f"reason: {entry['reason']}")
        if entry.get("duration_seconds") is not None:
            bits.append(f"duration: {entry['duration_seconds']}s")
        if entry.get("expires_at"):
            bits.append(f"expires_at: {entry['expires_at']}")
        return " | ".join(bits)

    if src == "exception":
        bits = [f"id={entry.get('short_id', '?')}"]
        bits.append(f"rule={entry.get('rule', '?')}")
        if entry.get("expires_at"):
            bits.append(f"expires_at={entry['expires_at']}")
        if entry.get("revoked_at"):
            bits.append(f"revoked_at={entry['revoked_at']}")
        if entry.get("reason"):
            bits.append(f"reason: {entry['reason']}")
        return " | ".join(bits)

    # spool
    bits = []
    if entry.get("agent"):
        bits.append(f"agent={entry['agent']}")
    if entry.get("source_label"):
        bits.append(entry["source_label"])
    findings = entry.get("findings") or []
    if findings:
        rule_ids = sorted({str(f.get("rule_id")) for f in findings if isinstance(f, dict)})
        bits.append(f"{len(findings)} finding(s) [{', '.join(rule_ids)}]")
    if entry.get("reason"):
        bits.append(f"reason: {entry['reason']}")
    if entry.get("bypass_used"):
        bits.append(f"bypass={entry.get('bypass_exception_id', '?')[:12]}")
    if entry.get("targets"):
        bits.append(f"targets={entry['targets']}")
    return " | ".join(bits)


# ---------------------------------------------------------------------- helpers

def _safely_enqueue(event_type: str, **fields) -> None:
    """Wrap telemetry.enqueue so a misconfigured telemetry path never
    breaks a successful install / pause / resume / etc. CLI flow."""
    try:
        guard_telemetry.enqueue(guard_telemetry.make_event(event_type, **fields))
    except Exception:  # noqa: BLE001
        pass


def _count_lines(path: Path) -> int:
    try:
        with path.open("r", encoding="utf-8") as f:
            return sum(1 for _ in f)
    except OSError:
        return 0


# ---------------------------------------------------------------------- output

_COLORS = {
    "observe":               "\033[32m",
    "warn_continue":         "\033[33m",
    "redact":                "\033[33m",
    "warn_self_justify":     "\033[31m",
    "warn_external_approve": "\033[31m",
    "block":                 "\033[31m",
    "reset":                 "\033[0m",
}


def _pretty_print(result: dict, mode: Mode) -> None:
    color = _COLORS.get(mode.value, "")
    reset = _COLORS["reset"]

    print(f"{color}mode: {mode.value.upper()}{reset}")
    findings: List[dict] = result.get("findings") or []
    if findings:
        print(f"findings: {len(findings)}")
        for f in findings:
            loc = f.get("source", "")
            span = ""
            if f.get("start") is not None:
                span = f" @ {f['start']}-{f['end']}"
            print(
                f"  - [{f['severity']}] {f['type']}/{f['rule_id']}{span} "
                f"in {loc}: {f['message']}"
            )
    if result.get("reasons"):
        print("reasons:")
        for r in result["reasons"]:
            print(f"  - {r}")

    if mode is Mode.REDACT:
        print("\n--- prompt (after redaction) ---")
        print(result["prompt"])
    elif mode.is_blocking():
        print("\n(prompt blocked — no content emitted)")


# ---------------------------------------------------------------------- parser

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cloudanix-guard",
        description="Coding Agent Firewall — inspect prompts / tool calls before they reach an LLM.",
    )
    p.add_argument("--rules", help="Path to scanner rules YAML (default: packaged).")
    p.add_argument("--policy", help="Path to policy YAML (default: packaged).")

    sub = p.add_subparsers(dest="command", required=True)

    # scan
    scan = sub.add_parser("scan", help="Scan a text snippet or file (human-readable output).")
    scan.add_argument("--text", help="Text to scan.")
    scan.add_argument("--file", help="Path to a file to scan.")
    scan.add_argument("--json", action="store_true", help="Emit JSON instead of pretty output.")
    scan.set_defaults(func=cmd_scan)

    # hook
    hook = sub.add_parser(
        "hook",
        help="Run in hook mode. Reads JSON from stdin; exits 2 + writes stderr on block.",
    )
    hook.add_argument(
        "--agent",
        choices=["kiro", "claude_code", "codex"],
        default=None,
        help="Explicit agent attribution for telemetry. Wired in by "
             "`install codex` because Codex's event-name casing matches "
             "Claude Code and the two can't otherwise be distinguished. "
             "Default: inferred from event-name casing.",
    )
    hook.set_defaults(func=cmd_hook)

    # install
    install = sub.add_parser(
        "install",
        help="Install hooks into Kiro, Claude Code, and/or Codex CLI.",
    )
    install.add_argument(
        "target",
        choices=["kiro", "claude", "codex", "all", "both"],
        help="Which coding agent to wire up. `all` does every supported "
             "agent; `both` is the legacy alias for kiro+claude (kept for "
             "backwards compatibility).",
    )
    install.add_argument(
        "--scope",
        choices=["user", "project"],
        default="user",
        help="user → ~/.kiro/agents/, ~/.claude/settings.json, ~/.codex/hooks.json; "
             "project → ./.kiro/agents/, ./.claude/settings.json, ./.codex/hooks.json. "
             "Default: user.",
    )
    install.add_argument(
        "--guard-cmd",
        help="Override the cloudanix-guard command embedded in the hook "
             "(default: auto-detected absolute path).",
    )
    install.add_argument(
        "--profile",
        help="Bind the wired hook to a non-default profile. The hook "
             "command gets a `CLOUDANIX_GUARD_PROFILE=<name>` prefix "
             "so the running hook reads state from "
             "~/.cloudanix-guard/profiles/<name>/ instead of the "
             "default ~/.cloudanix-guard/. Power-user feature — see "
             "the 'Multiple profiles' section in README.md.",
    )
    install.add_argument(
        "--dry-run",
        action="store_true",
        help="Print what would be written without touching the filesystem.",
    )
    install.set_defaults(func=cmd_install)

    # uninstall
    uninstall = sub.add_parser(
        "uninstall",
        help="Remove the cloudanix-guard hooks from Kiro, Claude Code, and/or Codex CLI.",
    )
    uninstall.add_argument(
        "target",
        choices=["kiro", "claude", "codex", "all", "both"],
        help="Which coding agent to clean up. `all` and `both` mirror `install`.",
    )
    uninstall.add_argument(
        "--scope",
        choices=["user", "project"],
        default="user",
        help="user → ~/.kiro/agents/, ~/.claude/settings.json, ~/.codex/hooks.json; "
             "project → ./.kiro/agents/, ./.claude/settings.json, ./.codex/hooks.json. "
             "Default: user.",
    )
    uninstall.add_argument(
        "--dry-run",
        action="store_true",
        help="Print what would be changed without touching the filesystem.",
    )
    uninstall.set_defaults(func=cmd_uninstall)

    # pause
    pause = sub.add_parser(
        "pause",
        help="Temporarily disable the firewall (with a reason). Auto-expires.",
    )
    pause.add_argument(
        "--reason",
        required=True,
        help="Why you're pausing. Recorded in the audit log. Required.",
    )
    pause.add_argument(
        "--duration",
        default="30m",
        help="How long to stay paused. Examples: 30m, 1h, 1h30m, 90s. "
             "Use --indefinite to disable auto-expiry. Default: 30m.",
    )
    pause.add_argument(
        "--indefinite",
        action="store_true",
        help="Pause with no auto-expiry. You must run `cloudanix-guard resume` "
             "to re-enable. Use sparingly.",
    )
    pause.set_defaults(func=cmd_pause)

    # resume
    resume = sub.add_parser(
        "resume",
        help="Re-enable the firewall after a pause.",
    )
    resume.set_defaults(func=cmd_resume)

    # status
    status = sub.add_parser(
        "status",
        help="Show current firewall state (active / paused / time-to-resume) + telemetry config.",
    )
    status.set_defaults(func=cmd_status)

    # configure
    configure = sub.add_parser(
        "configure",
        help="Set or update the per-user config (email, console URL, API token).",
        description=(
            "Update ~/.cloudanix-guard/config.yaml (mode 0600). Partial-merge: "
            "only the flags you pass are changed; the rest are kept. The token is "
            "stored at rest in plaintext — same threat model as ~/.aws/credentials. "
            "Telemetry stays OFF until both --console-url and --api-token are set."
        ),
    )
    configure.add_argument("--email", help="Developer email used as an identifier in audit / telemetry.")
    configure.add_argument(
        "--console-url",
        dest="console_url",
        help="Base URL of the Cloudanix Console (e.g. https://console.cloudanix.com or http://localhost:3000).",
    )
    configure.add_argument(
        "--api-token",
        dest="api_token",
        help="JWT minted from console.cloudanix.com → Settings → API Tokens.",
    )
    configure.add_argument(
        "--show",
        action="store_true",
        help="Display current config (token is redacted) and exit.",
    )
    configure.set_defaults(func=cmd_configure)

    # flush
    flush = sub.add_parser(
        "flush",
        help="Drain the telemetry spool by POSTing one batch to the console.",
        description=(
            "Sends up to 200 queued events to the console as one batch. "
            "Returns 0 on success or non-retryable rejection; 1 on retryable "
            "failure (network / 5xx / 401) so a cron wrapper can decide what to do."
        ),
    )
    flush.add_argument(
        "--timeout",
        type=float,
        default=guard_telemetry.DEFAULT_FLUSH_TIMEOUT_SECONDS,
        help="HTTP timeout in seconds (default: 10).",
    )
    flush.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Print every outcome (default: silent on no-op outcomes so cron logs stay tiny).",
    )
    flush.set_defaults(func=cmd_flush)

    # sync
    sync = sub.add_parser(
        "sync",
        help="Pull the latest policy from the Cloudanix Console. Run by cron in a per-device jittered window.",
        description=(
            "Polls GET {console_url}/v2/coding_agent_guard/policy. On 200, writes "
            "~/.cloudanix-guard/policy.yaml; on 304, just bumps the last-sync timestamp. "
            "By default no-ops outside the device's daily polling window — pass --force "
            "to override that check."
        ),
    )
    sync.add_argument(
        "--force",
        action="store_true",
        help="Bypass the polling-window check. Useful for testing or 'right now' pulls.",
    )
    sync.add_argument(
        "--timeout",
        type=float,
        default=guard_sync.DEFAULT_SYNC_TIMEOUT_SECONDS,
        help="HTTP timeout in seconds (default: 10).",
    )
    sync.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Print every outcome (default: silent on `skipped` / `304` so cron logs stay tiny).",
    )
    sync.set_defaults(func=cmd_sync)

    # request-exception
    req_exc = sub.add_parser(
        "request-exception",
        help="Grant a self-justification exception for one rule (default 10 minutes).",
        description=(
            "Writes a time-boxed, rule-scoped self-exception that the hook "
            "honours on its next invocation. Use when a `warn_self_justify` "
            "block fires on something you genuinely need to send (a dev token, "
            "an example string in a doc, etc.). The block stderr quotes the "
            "exact `--rule` value to paste here."
        ),
    )
    req_exc.add_argument(
        "--rule", required=True,
        help="Rule identifier in the form `<type>/<rule_id>` (e.g. `secret/github-pat`). "
             "The hook's block message quotes this exact value.",
    )
    req_exc.add_argument(
        "--reason", required=True,
        help="Why you're granting this exception. Free text. Recorded in the "
             "audit log and pushed to the console (no raw content; the reason "
             "you type is what's stored).",
    )
    req_exc.add_argument(
        "--duration", default="10m",
        help="How long the exception stays active. Examples: 10m (default), 30m, 1h, 90s. "
             "Tight on purpose — exceptions are per-task. Use `cloudanix-guard pause` "
             "for session-wide bypasses.",
    )
    req_exc.set_defaults(func=cmd_request_exception)

    # revoke-exception
    rev_exc = sub.add_parser(
        "revoke-exception",
        help="End a granted exception early.",
        description=(
            "Looks up the exception by full id or short prefix (the 12-char form "
            "shown by `status` / `logs` works). No-op if the exception is already "
            "expired or revoked."
        ),
    )
    rev_exc.add_argument("exception_id", help="Full or prefix id of the exception to revoke.")
    rev_exc.set_defaults(func=cmd_revoke_exception)

    # logs
    logs = sub.add_parser(
        "logs",
        help="Show the last N firewall events (pause/resume from audit + pending telemetry from the spool).",
        description=(
            "Merges entries from ~/.cloudanix-guard/audit.log (pause/resume/expiry) "
            "and ~/.cloudanix-guard/queue.jsonl (decisions / installs queued for upstream "
            "flush). After a flush, decision events live on the Cloudanix Console — this "
            "view shows only what's still on this device."
        ),
    )
    logs.add_argument(
        "--limit", type=int, default=20,
        help="How many entries to show. Default: 20.",
    )
    logs.add_argument(
        "--json", action="store_true",
        help="Emit raw NDJSON (one event per line) instead of the table.",
    )
    logs.set_defaults(func=cmd_logs)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
