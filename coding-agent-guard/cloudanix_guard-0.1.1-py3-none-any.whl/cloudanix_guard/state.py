"""Runtime state for the firewall: pause / resume + audit log.

A developer hitting a false positive needs a way to keep working
without uninstalling the firewall. The pause / resume pair gives
them an explicit, **time-boxed, reason-recorded** bypass that:

- Forces a ``--reason`` so the bypass is intentional and reviewable.
- Auto-expires (default 30 minutes) so it can't be silently left on
  forever — the most common cause of safety mechanisms decaying.
- Writes every pause / resume / expiry event to an NDJSON audit
  log so a security team (or the user themselves, later) can see
  exactly when the guard was off and why.

State lives at ``~/.cloudanix-guard/state.json``; the audit log at
``~/.cloudanix-guard/audit.log``. Both are per-user; nothing here
touches anything outside the user's home directory.

The hook calls :func:`is_paused` on every event. It is designed to
be near-zero-cost in the common (not-paused) case — a single
``os.path.exists`` check.
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Tuple

from cloudanix_guard._safe_io import safe_atomic_write, safe_open_for_append


# ─── Locations ─────────────────────────────────────────────────────

def _state_dir() -> Path:
    """Where state + audit log live. Overridable via env for tests."""
    override = os.environ.get("CLOUDANIX_GUARD_STATE_DIR")
    if override:
        return Path(override)
    return Path.home() / ".cloudanix-guard"


def state_path() -> Path:
    return _state_dir() / "state.json"


def audit_log_path() -> Path:
    return _state_dir() / "audit.log"


# ─── Duration parsing ──────────────────────────────────────────────

_DURATION_RE = re.compile(r"^\s*(?:(\d+)\s*h)?\s*(?:(\d+)\s*m)?\s*(?:(\d+)\s*s)?\s*$")


def parse_duration(text: str) -> int:
    """Parse a human duration like ``30m`` / ``1h`` / ``1h30m`` to seconds.

    Raises :class:`ValueError` on anything unparseable. We deliberately
    don't accept bare integers (ambiguous: seconds? minutes?) — callers
    must spell out the unit.
    """
    if not text:
        raise ValueError("duration cannot be empty")
    m = _DURATION_RE.match(text)
    if not m or text.strip() == "":
        raise ValueError(
            f"unrecognised duration {text!r}; expected forms like '30m', '1h', '1h30m', '90s'"
        )
    h, mn, s = (int(g) if g else 0 for g in m.groups())
    total = h * 3600 + mn * 60 + s
    if total <= 0:
        raise ValueError(f"duration must be positive: {text!r}")
    return total


# ─── State dataclass ───────────────────────────────────────────────

@dataclass
class PauseState:
    paused: bool
    paused_at: Optional[str] = None   # ISO 8601 UTC
    expires_at: Optional[str] = None  # ISO 8601 UTC, or None for indefinite
    reason: Optional[str] = None
    user: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "paused": self.paused,
            "paused_at": self.paused_at,
            "expires_at": self.expires_at,
            "reason": self.reason,
            "user": self.user,
        }


# ─── Read / write ──────────────────────────────────────────────────

def _utcnow_iso() -> str:
    """ISO 8601 to seconds in UTC, no timezone suffix overhead."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _user() -> str:
    return os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"


def read_state() -> Optional[PauseState]:
    """Return the current pause state, or ``None`` if not paused.

    A state file with ``paused: false`` (left after a resume) is
    treated as not paused. An expired pause is also treated as not
    paused — and the expiry is recorded to the audit log the first
    time we notice.
    """
    path = state_path()
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text() or "{}")
    except (json.JSONDecodeError, OSError):
        return None
    if not raw.get("paused"):
        return None

    state = PauseState(
        paused=True,
        paused_at=raw.get("paused_at"),
        expires_at=raw.get("expires_at"),
        reason=raw.get("reason"),
        user=raw.get("user"),
    )

    if state.expires_at and _is_past(state.expires_at):
        # Auto-resume on expiry: clear state and emit audit entry.
        _clear_state()
        _audit({
            "ts": _utcnow_iso(),
            "event": "auto_resume_on_expiry",
            "expired_at": state.expires_at,
            "reason": state.reason,
            "user": state.user,
        })
        # Also push to telemetry, if configured. Late import keeps
        # state.py from depending on telemetry at module-load time.
        try:
            from cloudanix_guard import telemetry
            telemetry.enqueue(telemetry.make_event(
                "auto_resume_on_expiry",
                expired_at=state.expires_at,
                reason=state.reason,
            ))
        except Exception:  # noqa: BLE001 — telemetry must never break state
            pass
        return None

    return state


def _is_past(iso_ts: str) -> bool:
    try:
        when = datetime.fromisoformat(iso_ts)
    except ValueError:
        return True
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    return when <= datetime.now(timezone.utc)


def pause(reason: str, duration_seconds: Optional[int]) -> PauseState:
    """Pause the firewall. ``duration_seconds=None`` means indefinite."""
    if not reason or not reason.strip():
        raise ValueError("reason is required")

    now = datetime.now(timezone.utc).replace(microsecond=0)
    expires_at = (
        (now + timedelta(seconds=duration_seconds)).isoformat()
        if duration_seconds is not None
        else None
    )
    state = PauseState(
        paused=True,
        paused_at=now.isoformat(),
        expires_at=expires_at,
        reason=reason.strip(),
        user=_user(),
    )
    _write_state(state)
    _audit({
        "ts": now.isoformat(),
        "event": "pause",
        "reason": state.reason,
        "duration_seconds": duration_seconds,
        "expires_at": expires_at,
        "user": state.user,
    })
    return state


def resume() -> Optional[PauseState]:
    """End the pause, if any. Returns the prior state (for reporting), or None."""
    prior = read_state()
    if prior is None:
        return None
    _clear_state()
    _audit({
        "ts": _utcnow_iso(),
        "event": "resume",
        "was_paused_at": prior.paused_at,
        "reason": prior.reason,
        "user": _user(),
    })
    return prior


def is_paused() -> Optional[PauseState]:
    """Cheap check used by the hook. Returns the active state or None."""
    return read_state()


# ─── Internals ─────────────────────────────────────────────────────

def _write_state(state: PauseState) -> None:
    safe_atomic_write(state_path(), json.dumps(state.to_dict(), indent=2) + "\n")


def _clear_state() -> None:
    path = state_path()
    if path.exists():
        safe_atomic_write(path, json.dumps({"paused": False}) + "\n")


_AUDIT_ROTATE_BYTES = 5 * 1024 * 1024  # 5 MB before we rotate to .1


def _audit(entry: dict) -> None:
    """Append one NDJSON line to the audit log. Best-effort — never raises.

    Rotates at ``_AUDIT_ROTATE_BYTES`` so the file can't grow forever
    on a long-running install. Keep exactly one rotation file
    (``audit.log.1``) — max footprint ~10 MB combined. We don't hit
    this in practice (audit events are pause / resume / expiry only,
    not per-decision), but the cap exists to be respectful of the
    user's disk.
    """
    try:
        path = audit_log_path()
        # Rotate if the current file is over the size cap.
        if path.exists() and path.stat().st_size > _AUDIT_ROTATE_BYTES:
            rotated = path.with_suffix(path.suffix + ".1")
            try:
                if rotated.exists():
                    rotated.unlink()
                path.rename(rotated)
            except OSError:
                pass  # if rotation fails, fall through and keep appending
        with safe_open_for_append(path) as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        # Logging must not break the hook. Swallow.
        pass


# ─── Pretty helpers used by the status / pause / resume CLI ────────

def format_remaining(state: PauseState) -> str:
    """Human-friendly remaining time, e.g. '27m 18s left'."""
    if state.expires_at is None:
        return "no auto-expiry (use `cloudanix-guard resume` to re-enable)"
    try:
        when = datetime.fromisoformat(state.expires_at)
    except ValueError:
        return "(unknown — invalid expires_at)"
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    delta = (when - datetime.now(timezone.utc)).total_seconds()
    if delta <= 0:
        return "expired (will auto-resume on next hook call)"
    h, rem = divmod(int(delta), 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h {m}m {s}s left"
    if m:
        return f"{m}m {s}s left"
    return f"{s}s left"
