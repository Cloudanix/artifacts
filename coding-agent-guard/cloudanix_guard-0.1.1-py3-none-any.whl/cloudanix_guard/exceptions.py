"""Self-justification exception store — Phase B.

The hook consults this store before exiting 2 on a
``warn_self_justify`` finding. An unexpired, non-revoked entry whose
``rule`` matches the firing rule lets the prompt through, with a
``decision_bypass_used`` telemetry event recording the bypass.

Storage
-------

``~/.cloudanix-guard/exceptions.jsonl`` (path overridable via
``CLOUDANIX_GUARD_STATE_DIR`` for tests). Newline-delimited JSON,
one entry per granted exception. Re-written atomically on grant /
revoke under ``fcntl.flock`` — same locking pattern as the
telemetry spool.

Schema (per line)::

    {
      "id":         "exc_01HXYZ...",     # sortable-ish; first 12 chars are display-safe
      "rule":       "secret/github-pat", # "<type>/<rule_id>" — matches Finding identity
      "reason":     "...",                # user-supplied free text, required
      "granted_at": "2026-05-15T...Z",    # ISO UTC
      "expires_at": "2026-05-15T...Z",    # ISO UTC; null = indefinite
      "user":       "alice",
      "revoked_at": null,                 # ISO UTC if revoked
      "granted_by": "self"                # "self" or external approver email (Phase D)
    }

Vocabulary
----------

User-facing CLI uses "exception" (``cloudanix-guard request-exception``).
Internal class is :class:`ExceptionEntry` to avoid shadowing the
builtin ``Exception``. "Bypass" appears in a few audit / log strings
when we're describing the *effect* of an active exception.

Privacy
-------

The ``reason`` is whatever the user types — it lives in the audit
log and gets pushed via telemetry. There's no field for raw matched
content; if a user types a secret into the reason, that's on them
(and we should add a hint in the prompt). NF-PRIV-1 isn't broken
by the data model.
"""

from __future__ import annotations

import fcntl
import json
import os
import secrets
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional

from cloudanix_guard.config_file import config_dir


# Default duration if the caller doesn't specify. Tight on purpose —
# self-justifications should be per-task, not session-wide. Use
# `cloudanix-guard pause` if you need a longer window.
DEFAULT_DURATION_SECONDS = 600  # 10 minutes


@dataclass
class ExceptionEntry:
    """One self-justification grant. Matches the on-disk JSON shape 1:1."""

    id: str
    rule: str
    reason: str
    granted_at: str
    expires_at: Optional[str]
    user: str
    revoked_at: Optional[str] = None
    granted_by: str = "self"

    @property
    def short_id(self) -> str:
        """First 12 chars of the id — enough to disambiguate in a UI list."""
        return self.id[:12]

    def is_active(self, now_iso: Optional[str] = None) -> bool:
        """True if the entry hasn't been revoked and hasn't expired."""
        now_iso = now_iso or _utcnow_iso()
        if self.revoked_at:
            return False
        if self.expires_at and self.expires_at <= now_iso:
            return False
        return True


# ─── Paths ─────────────────────────────────────────────────────────

def exceptions_path() -> Path:
    return config_dir() / "exceptions.jsonl"


# ─── Reason scanner ────────────────────────────────────────────────

def _reason_has_secret(reason: str):
    """Return the first HIGH/CRITICAL finding the inspector pulls out
    of ``reason``, or ``None`` if it's clean enough to persist.

    Late import so the test suite can run module-load-time-cheap tests
    on this file without dragging in scanner imports."""
    from cloudanix_guard.inspector import Inspector
    from cloudanix_guard.inspector.types import Payload, Severity

    try:
        findings = Inspector.default().inspect(Payload(prompt=reason))
    except Exception:  # noqa: BLE001 — defensive; never break grants on a scanner bug
        return None
    for f in findings:
        if f.severity in (Severity.HIGH, Severity.CRITICAL):
            return f
    return None


# ─── Public API ────────────────────────────────────────────────────

def grant(
    rule: str,
    reason: str,
    duration_seconds: Optional[int] = DEFAULT_DURATION_SECONDS,
    *,
    granted_by: str = "self",
    scan_reason: bool = True,
) -> ExceptionEntry:
    """Grant a new exception. ``duration_seconds=None`` = indefinite.

    Both ``rule`` and ``reason`` are required. Returns the newly
    created entry; on-disk state is also updated.

    NF-PRIV-1 defense: the ``reason`` string is persisted to disk
    (`exceptions.jsonl` + `audit.log`) and pushed to telemetry as a
    plain-text field. If a hurried user types a real secret into
    ``--reason`` we'd land it in three places we don't want it. We
    run the inspector on the reason before persistence; any HIGH /
    CRITICAL finding refuses the grant with a clear error so the
    user can rephrase. MEDIUM/LOW findings (e.g. an email) are
    allowed through — many legitimate reasons mention low-stakes
    identifiers, and rejecting on those would be a usability tax
    with little privacy upside.

    Tests can pass ``scan_reason=False`` to bypass the inspector
    (avoids loading scanner state for cases that don't care).
    """
    if not rule or not rule.strip():
        raise ValueError("rule is required")
    if not reason or not reason.strip():
        raise ValueError("reason is required")

    if scan_reason:
        finding = _reason_has_secret(reason)
        if finding is not None:
            raise ValueError(
                f"reason looks like it contains a {finding.severity.value}-severity "
                f"{finding.type.value}/{finding.rule_id} — rephrase without the "
                f"sensitive value (reasons are persisted to audit.log and the "
                f"telemetry stream)"
            )

    now = datetime.now(timezone.utc).replace(microsecond=0)
    expires_at = (
        (now + timedelta(seconds=duration_seconds)).isoformat()
        if duration_seconds is not None
        else None
    )

    entry = ExceptionEntry(
        id=_new_exception_id(),
        rule=rule.strip(),
        reason=reason.strip(),
        granted_at=now.isoformat(),
        expires_at=expires_at,
        user=_user(),
        granted_by=granted_by,
    )

    # Append to the JSONL spool. Locked. safe_open_for_append applies
    # 0600 on first creation (and 0700 to the parent dir).
    from cloudanix_guard._safe_io import safe_open_for_append
    with safe_open_for_append(exceptions_path()) as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            f.write(json.dumps(asdict(entry)) + "\n")
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

    return entry


def revoke(exception_id: str) -> Optional[ExceptionEntry]:
    """Mark an exception as revoked. Returns the *prior* entry, or
    ``None`` if no matching active exception was found."""
    if not exception_id:
        return None

    path = exceptions_path()
    if not path.exists():
        return None

    all_entries = _read_all()
    target_idx: Optional[int] = None
    target: Optional[ExceptionEntry] = None
    # Find the latest matching active entry.
    for idx, e in enumerate(all_entries):
        if e.id == exception_id and e.revoked_at is None:
            target_idx = idx
            target = e
    if target is None or target_idx is None:
        return None

    target.revoked_at = _utcnow_iso()
    all_entries[target_idx] = target

    # Rewrite the file under lock.
    with path.open("r+", encoding="utf-8") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            f.seek(0)
            f.truncate()
            for e in all_entries:
                f.write(json.dumps(asdict(e)) + "\n")
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)

    return target


def list_all() -> List[ExceptionEntry]:
    """All entries on disk, including revoked + expired. Useful for audit."""
    return _read_all()


def list_active(now_iso: Optional[str] = None) -> List[ExceptionEntry]:
    """Currently-active entries (not revoked, not expired)."""
    now_iso = now_iso or _utcnow_iso()
    return [e for e in _read_all() if e.is_active(now_iso)]


def find_active_for_rule(rule: str) -> Optional[ExceptionEntry]:
    """Most-recent active exception matching ``rule``, or ``None``.

    ``rule`` is the ``"<type>/<rule_id>"`` form — same as the
    rule_overrides key in ``policy.yaml`` and what
    ``request-exception --rule`` accepts.
    """
    rule = (rule or "").strip()
    if not rule:
        return None
    matches = [e for e in list_active() if e.rule == rule]
    if not matches:
        return None
    # Most-recently-granted wins (file order is grant order; later wins).
    matches.sort(key=lambda e: e.granted_at)
    return matches[-1]


# ─── Internals ─────────────────────────────────────────────────────

def _read_all() -> List[ExceptionEntry]:
    path = exceptions_path()
    if not path.exists():
        return []
    out: List[ExceptionEntry] = []
    try:
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
            except json.JSONDecodeError:
                continue
            try:
                out.append(ExceptionEntry(**raw))
            except TypeError:
                # Schema drift — skip the bad row, keep going.
                continue
    except OSError:
        return []
    return out


def _new_exception_id() -> str:
    """Sortable-ish ID: ``exc_<13-hex-ms>_<random>``. 24-ish chars."""
    return f"exc_{int(time.time() * 1000):013x}_{secrets.token_urlsafe(6)}"


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _user() -> str:
    return os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"
