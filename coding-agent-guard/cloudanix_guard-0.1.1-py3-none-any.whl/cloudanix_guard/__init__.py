"""Cloudanix Guard — coding agent firewall (POC).

Inspects prompts and file payloads before they leave the developer's
machine for an LLM-backed coding agent (Claude, Kiro, Cursor, etc.).

Components:
- :mod:`cloudanix_guard.inspector` — scanners (secrets, PII, files).
- :mod:`cloudanix_guard.policy`    — YAML-driven action decisions.
- :mod:`cloudanix_guard.enforce`   — redaction / blocking transforms.
- :mod:`cloudanix_guard.cli`       — CLI entry-point (``scan`` / ``hook``).
"""

__version__ = "0.1.1"
