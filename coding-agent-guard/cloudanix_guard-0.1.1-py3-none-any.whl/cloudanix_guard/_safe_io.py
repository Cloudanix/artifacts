"""Filesystem write helpers with conservative permissions.

The state directory at ``~/.cloudanix-guard/`` contains audit-grade
local data (decision history, exception grants, the read-content-scan
cache with absolute paths). On a shared dev machine or any host with
non-trivial multi-user policy, default 0644 leaves these world-readable
— a meaningful local-leak surface even though we work hard to make sure
none of it goes off-device unscrubbed.

This module provides one chokepoint for every disk write the package
does. New persisters should call ``safe_write_text`` / ``safe_write_bytes``
/ ``safe_atomic_write`` rather than rolling their own ``Path.write_text``.

Permissions:
- Files: 0600 (owner read/write only). The dev's account already owns
  the data; nobody else should read it.
- Directories: 0700 on first create. Same model.

Atomicity:
- ``safe_atomic_write`` writes to ``<path>.tmp`` and then ``os.replace``s
  — same pattern ``pending_block.py`` and ``file_content_cache.py``
  already use; centralised here so callers stop re-implementing it.

Best-effort throughout: any ``OSError`` on ``chmod`` is swallowed (non-POSIX
filesystems exist; mode is advisory not load-bearing). Writes that
genuinely fail still raise to the caller.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Union


_FILE_MODE = 0o600
_DIR_MODE = 0o700


def ensure_dir(path: Union[str, Path]) -> Path:
    """Create ``path`` (and parents) with restrictive perms. Returns
    the path. Idempotent — existing directories keep their current mode."""
    p = Path(path)
    existed = p.exists()
    p.mkdir(parents=True, exist_ok=True)
    if not existed:
        _safe_chmod(p, _DIR_MODE)
    return p


def safe_write_text(path: Union[str, Path], data: str, *, atomic: bool = False) -> Path:
    """Write text to ``path`` at mode 0600. Creates parent dirs at 0700.

    Set ``atomic=True`` to write via ``<path>.tmp`` + ``os.replace`` so
    a concurrent reader either sees the previous content or the new
    content but never a torn write.
    """
    return _write(path, data.encode("utf-8"), atomic=atomic)


def safe_write_bytes(path: Union[str, Path], data: bytes, *, atomic: bool = False) -> Path:
    """Binary variant of :func:`safe_write_text`."""
    return _write(path, data, atomic=atomic)


def safe_atomic_write(path: Union[str, Path], data: str) -> Path:
    """Shorthand for ``safe_write_text(path, data, atomic=True)``.

    The common pattern in this codebase is "build the full file body
    in memory, then atomically replace the on-disk version" — most
    state files are small (kB at most) so the in-memory build is fine.
    """
    return safe_write_text(path, data, atomic=True)


def safe_open_for_append(path: Union[str, Path]) -> "open":
    """Open ``path`` for appending, creating it at 0600 if absent.

    Use this for files that grow line-at-a-time (``audit.log``,
    ``queue.jsonl``, ``exceptions.jsonl``) where buffering up the
    whole body just to atomic-replace would defeat the point.

    Permissions are applied on first creation; existing files keep
    their current mode (so a one-time chmod tighten on existing
    deployments would be a separate migration).
    """
    p = Path(path)
    ensure_dir(p.parent)
    is_new = not p.exists()
    fh = open(p, "a", encoding="utf-8")
    if is_new:
        _safe_chmod(p, _FILE_MODE)
    return fh


def chmod_existing(path: Union[str, Path]) -> None:
    """Best-effort tighten of permissions on an existing file/dir.

    Used by the one-time-fixup paths that want to re-mode files that
    pre-date this module. Caller decides whether to apply file or
    directory mode based on what ``path`` is.
    """
    p = Path(path)
    if not p.exists():
        return
    mode = _DIR_MODE if p.is_dir() else _FILE_MODE
    _safe_chmod(p, mode)


# ─── internals ────────────────────────────────────────────────────

def _write(path: Union[str, Path], data: bytes, *, atomic: bool) -> Path:
    p = Path(path)
    ensure_dir(p.parent)
    if atomic:
        tmp = p.with_suffix(p.suffix + ".tmp")
        try:
            with open(tmp, "wb") as fh:
                fh.write(data)
            _safe_chmod(tmp, _FILE_MODE)
            os.replace(tmp, p)
        finally:
            # If replace succeeded, tmp is gone. If we raised before
            # replace, leave-behind tmp would accumulate on retry — clean.
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
    else:
        with open(p, "wb") as fh:
            fh.write(data)
        _safe_chmod(p, _FILE_MODE)
    return p


def _safe_chmod(p: Path, mode: int) -> None:
    try:
        os.chmod(p, mode)
    except OSError:
        # Non-POSIX FS, mounted FAT, etc. Mode is advisory.
        pass
