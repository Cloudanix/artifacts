"""Policy sync — Phase C, guard side.

Polls ``GET {console_url}/v2/coding_agent_guard/policy`` once per hour
in a per-device, per-day deterministic window (no top-of-hour
thundering herd on the console). Writes the response body to
``~/.cloudanix-guard/policy.yaml``; ``PolicyEngine`` then prefers
that cached file over the packaged default on the next hook event.

Wire shape lives in
``15-console-integration/04-policy-sync-and-heartbeat.md`` —
notably:

- Header ``X-Cloudanix-Guard-Host`` is **load-bearing** on the
  server side (device rows key on
  ``(account, user, entity, hostname)``). We always send it.
- ETag comes back as ``W/"<version>-<8hex>"``. Echo verbatim in
  ``If-None-Match`` — never reconstruct it.
- 304 still updates ``last_seen_at`` on the server, so the steady
  state is: one 304 per hour per device, dashboard stays green.

State for this module lives at ``~/.cloudanix-guard/sync_state.json``
(separate from ``state.json`` which holds pause-state — different
lifecycles, easier to reason about).
"""

from __future__ import annotations

import hashlib
import json
import socket
import sys
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, Optional, Tuple

import yaml

from cloudanix_guard.config_file import GuardConfig, config_dir, load as load_config
from cloudanix_guard.policy import PolicyEngine


# Policy fields we extract from the server response and write to
# the local cache. Anything else (version, etag, scope, applied_at)
# is metadata that goes into sync_state.json, not policy.yaml.
_POLICY_BODY_KEYS = ("logging", "default_mode", "modes", "rule_overrides")

# Default HTTP timeout. Conservative — the endpoint is fast (304 in
# the common case) but we tolerate cold-start jitter.
DEFAULT_SYNC_TIMEOUT_SECONDS = 10.0

# Backoff: same shape as telemetry.flush's. Caps at 1 hour.
_BACKOFF_MAX_SECONDS = 3600
_BACKOFF_BASE_SECONDS = 60


# ─── Public types ──────────────────────────────────────────────────

HttpTransport = Callable[[str, dict, float], Tuple[int, dict, bytes]]
# Signature: (url, headers, timeout) -> (status_code, response_headers, body_bytes).
# Tests pass a FakeTransport; production uses _urllib_transport below.


@dataclass
class SyncResult:
    status: str                          # "200" | "304" | "401" | "5xx" | "network" | "skipped" | "rejected"
    policy_version: Optional[int] = None
    etag: Optional[str] = None
    reason: Optional[str] = None         # one-line human summary for the CLI


# ─── Paths ─────────────────────────────────────────────────────────

def sync_state_path() -> Path:
    return config_dir() / "sync_state.json"


def cached_policy_path() -> Path:
    return config_dir() / "policy.yaml"


# ─── Sync state I/O ────────────────────────────────────────────────

def _load_state() -> dict:
    path = sync_state_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text() or "{}")
    except (json.JSONDecodeError, OSError):
        return {}


def _save_state(state: dict) -> None:
    from cloudanix_guard._safe_io import safe_atomic_write
    safe_atomic_write(sync_state_path(), json.dumps(state, indent=2) + "\n")


def _in_backoff() -> Optional[str]:
    """Return next_retry_at if we're currently in backoff after recent
    failures, else None. Cheap; called at the top of sync_once."""
    state = _load_state()
    next_retry = state.get("next_retry_at")
    if not next_retry:
        return None
    try:
        when = datetime.fromisoformat(next_retry)
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None
    return next_retry if datetime.now(timezone.utc) < when else None


def _record_sync_failure() -> None:
    state = _load_state()
    fails = int(state.get("consecutive_failures") or 0) + 1
    backoff_secs = min(_BACKOFF_BASE_SECONDS * (2 ** (fails - 1)), _BACKOFF_MAX_SECONDS)
    state["consecutive_failures"] = fails
    state["next_retry_at"] = (
        datetime.now(timezone.utc) + timedelta(seconds=backoff_secs)
    ).replace(microsecond=0).isoformat()
    _save_state(state)


def _record_sync_success() -> None:
    state = _load_state()
    state.pop("consecutive_failures", None)
    state.pop("next_retry_at", None)
    _save_state(state)


def device_id() -> str:
    """Stable per-install UUID. Drives the polling-window jitter.

    Not sent to the console (auth handles identity); only used as a
    seed for ``assigned_minute_of_hour``."""
    state = _load_state()
    if "device_id" in state and state["device_id"]:
        return state["device_id"]
    new_id = str(uuid.uuid4())
    state["device_id"] = new_id
    _save_state(state)
    return new_id


# ─── Polling window ────────────────────────────────────────────────

def assigned_minute_of_hour(dev_id: str, day: date) -> int:
    """Deterministic minute-of-hour [0, 59] this device polls during.

    Spread across the hour via SHA-256 of ``(device_id, day)``; same
    every time within a day; rotates daily.
    """
    h = hashlib.sha256(f"{dev_id}|{day.isoformat()}".encode("utf-8")).digest()
    return int.from_bytes(h[:2], "big") % 60


def should_poll_now(now: Optional[datetime] = None) -> bool:
    """True when the current minute is in this device's daily 5-minute
    polling window AND no successful sync has fired in the last few
    minutes. The 5-minute window matches the cron tick rate; the
    cooldown prevents two polls in the same window."""
    now = now or datetime.now(timezone.utc)
    target = assigned_minute_of_hour(device_id(), now.date())
    in_window = target <= now.minute < target + 5
    if not in_window:
        return False

    last = _load_state().get("last_synced_at")
    if last:
        try:
            last_dt = datetime.fromisoformat(last)
            if last_dt.tzinfo is None:
                last_dt = last_dt.replace(tzinfo=timezone.utc)
            if (now - last_dt).total_seconds() < 4 * 60:
                return False
        except ValueError:
            pass
    return True


# ─── Sync ──────────────────────────────────────────────────────────

def sync_once(
    *,
    config: Optional[GuardConfig] = None,
    timeout_seconds: float = DEFAULT_SYNC_TIMEOUT_SECONDS,
    transport: Optional[HttpTransport] = None,
    force: bool = False,
) -> SyncResult:
    """One HTTP poll. Returns a :class:`SyncResult` for the caller to
    pretty-print or surface in telemetry. Never raises."""
    cfg = config if config is not None else load_config()
    if not cfg.telemetry_enabled:
        return SyncResult(status="skipped", reason="not configured (run `cloudanix-guard configure` first)")

    if not force and not should_poll_now():
        next_min = assigned_minute_of_hour(device_id(), datetime.now(timezone.utc).date())
        return SyncResult(status="skipped", reason=f"not in today's window (next at HH:{next_min:02d})")

    # Skip if we're backing off after recent failures. --force bypasses
    # this — the user typing `sync --force` is signalling intent to
    # retry now regardless of recent failures.
    if not force:
        next_retry = _in_backoff()
        if next_retry:
            return SyncResult(
                status="skipped",
                reason=f"in backoff after recent failures (next attempt at {next_retry})",
            )

    transport = transport or _urllib_transport
    url = _policy_endpoint(cfg)
    state = _load_state()
    headers = {
        "Authorization": f"Bearer {cfg.api_token}",
        "Accept": "application/json",
        "User-Agent": f"cloudanix-guard/{_guard_version()}",
        "X-Cloudanix-Guard-Version": _guard_version(),
        "X-Cloudanix-Guard-Host": _hostname(),
        "X-Cloudanix-Guard-OS": _os_string(),
    }
    if state.get("last_policy_etag"):
        headers["If-None-Match"] = state["last_policy_etag"]

    try:
        status, resp_headers, body_bytes = transport(url, headers, timeout_seconds)
    except Exception as e:  # noqa: BLE001 — telemetry must never break the firewall
        _record_sync_failure()
        return SyncResult(status="network", reason=f"transport error: {e}")

    now_iso = _utcnow_iso()

    if status == 304:
        state["last_synced_at"] = now_iso
        _save_state(state)
        _record_sync_success()
        return SyncResult(
            status="304",
            policy_version=state.get("last_policy_version"),
            etag=state.get("last_policy_etag"),
            reason="policy unchanged",
        )

    if status == 401:
        _record_sync_failure()
        return SyncResult(status="401", reason="token invalid — run `cloudanix-guard configure --api-token <new>`")

    if 500 <= status < 600:
        _record_sync_failure()
        return SyncResult(status="5xx", reason=f"server error {status}; will retry next window")

    if not (200 <= status < 300):
        # Any other non-2xx — drop, surface error. Not retryable, so
        # we don't extend the backoff window.
        return SyncResult(status=str(status), reason=f"unexpected status {status}")

    # 200: validate, write to disk, update state, emit telemetry.
    try:
        body = json.loads(body_bytes)
    except json.JSONDecodeError as e:
        return SyncResult(status="rejected", reason=f"server returned malformed JSON: {e}")

    policy_body = {k: body[k] for k in _POLICY_BODY_KEYS if k in body}
    if "default_mode" not in policy_body or "modes" not in policy_body:
        return SyncResult(status="rejected", reason="server response missing required policy fields")

    new_version = body.get("policy_version")
    new_etag = resp_headers.get("etag") or resp_headers.get("ETag") or body.get("etag")

    try:
        _write_policy_atomic(policy_body)
    except Exception as e:  # noqa: BLE001
        return SyncResult(status="rejected", reason=f"policy failed local validation: {e}")

    state["last_synced_at"] = now_iso
    state["last_policy_version"] = new_version
    state["last_policy_etag"] = new_etag
    _save_state(state)
    _record_sync_success()

    _safely_emit_telemetry(new_version, new_etag)
    return SyncResult(
        status="200",
        policy_version=new_version,
        etag=new_etag,
        reason="new policy applied",
    )


# ─── Internals ─────────────────────────────────────────────────────

def _policy_endpoint(cfg: GuardConfig) -> str:
    """Derived from the configured base URL. We keep one
    ``console_url`` in config; specific endpoint paths are protocol
    constants."""
    if not cfg.console_url:
        raise ValueError("console_url is not configured")
    from cloudanix_guard.config_file import _normalize_url  # local import to avoid a public-API surface
    base = _normalize_url(cfg.console_url).rstrip("/")
    return f"{base}/v2/coding_agent_guard/policy"


def _write_policy_atomic(policy_body: dict) -> None:
    """Write the validated policy to the cache. Writes to a temp
    file, parses it through :class:`PolicyEngine` for shape
    validation, then renames into place. If validation fails, the
    rename never happens and the existing cached policy stays
    untouched. The temp file is cleaned up on every exit path."""
    from cloudanix_guard._safe_io import ensure_dir, _safe_chmod, _FILE_MODE
    path = cached_policy_path()
    ensure_dir(path.parent)
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(yaml.safe_dump(policy_body, default_flow_style=False, sort_keys=False))
        _safe_chmod(tmp, _FILE_MODE)
        # Round-trip through the loader. Raises on bad mode names / shape.
        PolicyEngine.from_yaml(tmp)
        tmp.replace(path)
    finally:
        # On a parse failure (or any other early raise) we don't want
        # a stale .tmp accumulating across repeated sync retries.
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def _urllib_transport(url: str, headers: dict, timeout: float) -> Tuple[int, dict, bytes]:
    """Default transport. stdlib only — no `requests` dependency.

    Explicit ``ssl.create_default_context()`` for HTTPS so verify
    behaviour is locked in. HTTP (localhost dev) passes ``context=None``.
    """
    import ssl as _ssl
    req = urllib.request.Request(url, headers=headers, method="GET")
    ctx = _ssl.create_default_context() if url.lower().startswith("https") else None
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:  # noqa: S310
            return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as e:
        # 4xx / 5xx land here.
        try:
            body = e.read()
        except Exception:  # noqa: BLE001
            body = b""
        return e.code, dict(e.headers or {}), body


def _safely_emit_telemetry(version: Optional[int], etag: Optional[str]) -> None:
    """Push a `policy_synced` event. Best-effort — telemetry failures
    must not break sync."""
    try:
        from cloudanix_guard import telemetry  # late import to avoid a cycle at module load
        telemetry.enqueue(telemetry.make_event(
            "policy_synced",
            policy_version=version,
            etag=etag,
        ))
    except Exception:  # noqa: BLE001
        pass


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _hostname() -> str:
    """The server keys device rows on this. Cache it to state on
    first read so it stays stable even if ``socket.gethostname``
    starts returning something different."""
    state = _load_state()
    cached = state.get("hostname")
    if cached:
        return cached
    try:
        h = socket.gethostname() or "unknown"
    except Exception:  # noqa: BLE001
        h = "unknown"
    state["hostname"] = h
    _save_state(state)
    return h


def _os_string() -> str:
    try:
        import platform
        return f"{platform.system().lower()}-{platform.release()}"
    except Exception:  # noqa: BLE001
        return "unknown"


def _guard_version() -> str:
    try:
        from cloudanix_guard import __version__
        return __version__
    except (ImportError, AttributeError):
        return "0.0.1"
