"""One-way telemetry push to the Cloudanix Console.

Phase 0: every hook decision, ``pause``, ``resume``, ``install``, and
``uninstall`` is enqueued to a local NDJSON spool. A separate
``flush`` step (CLI subcommand or cron) drains the spool by POSTing
batches to::

    {console_url}/v2/coding_agent_guard/batches

Two clean halves
----------------

- :func:`enqueue` — append one event to ``~/.cloudanix-guard/queue.jsonl``.
  Called on the hook hot path. Microseconds, no network, never raises
  out. A no-op if telemetry isn't configured.

- :func:`flush_once` — read up to 200 events from the spool, POST as
  a single batch, on success drop them from the spool. No backoff
  loop here — callers (cron, or a future background runner) handle
  retry cadence.

Both halves are crash-safe via ``fcntl.flock`` on the spool file.

Privacy contract
----------------

Events handed to :func:`enqueue` must already be redacted via
``Finding.to_dict()`` (the guard's existing path strips raw matches).
We do a *defensive* strip again in :func:`make_event` so a bug in a
caller can't leak a raw match upstream.

Wire format
-----------

Per ``15-console-integration/01-protocol-and-tokens.md`` — see that
spec for the full envelope.
"""

from __future__ import annotations

import fcntl
import json
import platform
import socket
import sys
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, List, Optional, Tuple

from cloudanix_guard.config_file import GuardConfig, config_dir, load as load_config


# Server enforces ≤ 200 events / batch (per spec §3).
MAX_BATCH_EVENTS = 200

# Server enforces ≤ 1 MB body. Client-side cap is the same; we halve
# the outbound batch until the serialized body fits, displacing the
# trailing events back into the spool. Avoids wasted round-trips on
# 413s. Headroom below is for batch metadata + a little JSON overhead.
MAX_BATCH_BYTES = 1024 * 1024
_BATCH_BODY_HEADROOM_BYTES = 4 * 1024

# Spool cap. Beyond this we drop the oldest half. Long disconnects
# shouldn't grow the file unbounded.
MAX_SPOOL_BYTES = 50 * 1024 * 1024  # 50 MB

# Default HTTP timeout. The hot path doesn't use this — only flush_once.
DEFAULT_FLUSH_TIMEOUT_SECONDS = 10.0

# Backoff schedule: 60s, 2m, 4m, 8m, 16m, 32m, 1h, 1h, ...
# Caps at 1 hour so a long outage doesn't push the next attempt
# arbitrarily far into the future.
_BACKOFF_MAX_SECONDS = 3600
_BACKOFF_BASE_SECONDS = 60

# Hook-driven opportunistic flush: don't fire on every invocation —
# at 5–10 prompts/min that would be a flush-storm. The cron path is
# the reliable backstop; the hook flush just keeps a fresh laptop's
# events visible without waiting for the next 2-minute cron tick.
DEFAULT_HOOK_FLUSH_INTERVAL_SECONDS = 60


# ─── Public surface ───────────────────────────────────────────────

def spool_path() -> Path:
    return config_dir() / "queue.jsonl"


def _backoff_state_path() -> Path:
    """Tracks consecutive-failures + next_retry_at for the flush path.

    Keeps the firewall from hammering an unreachable console on
    every cron tick. Reset on success.
    """
    return config_dir() / "telemetry_state.json"


def _overflow_state_path() -> Path:
    """Accumulates spool-trim stats across one-or-more trims.

    Drained at the next successful flush into a single
    ``queue_overflow_dropped`` event. Survives trims (which is the
    point — putting the event in the spool itself would risk it
    being trimmed away on the next overflow).
    """
    return config_dir() / "overflow_state.json"


def _read_overflow_state() -> dict:
    path = _overflow_state_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text() or "{}")
    except (json.JSONDecodeError, OSError):
        return {}


def _write_overflow_state(state: dict) -> None:
    try:
        from cloudanix_guard._safe_io import safe_write_text
        safe_write_text(_overflow_state_path(), json.dumps(state) + "\n")
    except OSError:
        pass


def _clear_overflow_state() -> None:
    try:
        _overflow_state_path().unlink(missing_ok=True)
    except OSError:
        pass


def _occurred_at_of(line: str) -> Optional[str]:
    """Best-effort extraction of ``occurred_at`` from one spool line.

    Returns ``None`` on parse failure — the line is still counted as
    dropped, the timestamp just doesn't contribute to the range.
    """
    try:
        event = json.loads(line)
    except (json.JSONDecodeError, ValueError):
        return None
    ts = event.get("occurred_at") if isinstance(event, dict) else None
    return ts if isinstance(ts, str) else None


def _read_backoff_state() -> dict:
    path = _backoff_state_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text() or "{}")
    except (json.JSONDecodeError, OSError):
        return {}


def _write_backoff_state(state: dict) -> None:
    try:
        from cloudanix_guard._safe_io import safe_write_text
        safe_write_text(_backoff_state_path(), json.dumps(state) + "\n")
    except OSError:
        pass  # never break flush on a state-file error


def _in_backoff() -> Optional[str]:
    """Return the next_retry_at timestamp string if we're currently
    backing off; else None. Cheap; called at top of flush_once."""
    state = _read_backoff_state()
    next_retry = state.get("next_retry_at")
    if not next_retry:
        return None
    try:
        when = datetime.fromisoformat(next_retry)
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None
    return next_retry if datetime.now(timezone.utc) < when else None


def _record_flush_failure() -> None:
    state = _read_backoff_state()
    fails = int(state.get("consecutive_failures") or 0) + 1
    backoff_secs = min(_BACKOFF_BASE_SECONDS * (2 ** (fails - 1)), _BACKOFF_MAX_SECONDS)
    next_retry = (
        datetime.now(timezone.utc) + timedelta(seconds=backoff_secs)
    ).replace(microsecond=0).isoformat()
    new_state = {
        "consecutive_failures": fails,
        "next_retry_at": next_retry,
    }
    # Preserve the hook-flush throttle stamp across backoff updates —
    # the throttle is independent of the backoff state machine and we
    # don't want a single failed flush to immediately re-arm
    # auto-flush on the next hook event.
    if state.get("last_hook_flush_at"):
        new_state["last_hook_flush_at"] = state["last_hook_flush_at"]
    _write_backoff_state(new_state)


def _record_flush_success() -> None:
    # Preserve last_hook_flush_at if present — that throttle is
    # independent of backoff state. Without this, every successful
    # flush would re-arm the hook-flush trigger on the next event.
    existing = _read_backoff_state()
    preserved = {}
    if existing.get("last_hook_flush_at"):
        preserved["last_hook_flush_at"] = existing["last_hook_flush_at"]
    _write_backoff_state(preserved)


def should_attempt_hook_flush(
    *,
    min_interval_seconds: int = DEFAULT_HOOK_FLUSH_INTERVAL_SECONDS,
    config: Optional[GuardConfig] = None,
) -> bool:
    """True if cmd_hook should opportunistically fire a background flush.

    Cheap to call — runs on every hook event, so this stays in the
    microseconds range. Bails out early on the most common "no" paths
    so the hot path is essentially a stat() + a json.loads of a tiny
    file. Conditions for True:

    - telemetry is configured (otherwise nothing to flush),
    - spool exists and is non-empty,
    - we're not currently in backoff (cron will resume when the window
      opens; pre-empting it from the hook would just burn requests),
    - the last hook-driven flush attempt was > ``min_interval_seconds``
      ago (avoids flush-storms on busy sessions).
    """
    cfg = config if config is not None else load_config()
    if not cfg.telemetry_enabled:
        return False

    path = spool_path()
    try:
        if not path.exists() or path.stat().st_size == 0:
            return False
    except OSError:
        return False

    if _in_backoff():
        return False

    state = _read_backoff_state()
    last = state.get("last_hook_flush_at")
    if last:
        try:
            when = datetime.fromisoformat(last)
            if when.tzinfo is None:
                when = when.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            return True  # malformed stamp — treat as no prior attempt
        elapsed = (datetime.now(timezone.utc) - when).total_seconds()
        if elapsed < min_interval_seconds:
            return False
    return True


def record_hook_flush_attempt() -> None:
    """Stamp ``last_hook_flush_at`` so :func:`should_attempt_hook_flush`
    throttles correctly. Must be called *before* the background flush
    forks so a slow subprocess can't cause a re-attempt storm."""
    state = _read_backoff_state()
    state["last_hook_flush_at"] = _iso_now()
    _write_backoff_state(state)


@dataclass
class FlushResult:
    """Outcome of a single :func:`flush_once` call."""

    sent: int = 0                       # events actually pushed
    spool_remaining: int = 0            # events still queued after this call
    status_code: Optional[int] = None   # HTTP status if we got one
    duplicate: bool = False             # server said duplicate batch_uid
    retryable: bool = False             # caller should try again later
    reason: Optional[str] = None        # human-readable summary


# An injectable HTTP transport so tests don't need a real socket.
# Signature: (url, headers, body_bytes, timeout) -> (status_int, body_bytes).
HttpTransport = Callable[[str, dict, bytes, float], Tuple[int, bytes]]


def make_event(event_type: str, **fields: Any) -> dict:
    """Build a normalised event dict matching the wire format.

    Always sets ``occurred_at`` and ``event_type``. Filters out
    ``None`` values so the payload stays compact. Defensive: strips
    ``match`` from any ``findings`` entry — see "Privacy contract"
    in the module docstring.
    """
    out: dict = {"occurred_at": _iso_now(), "event_type": event_type}
    for k, v in fields.items():
        if v is None:
            continue
        if k == "findings" and isinstance(v, list):
            out[k] = [_strip_match(f) for f in v if isinstance(f, dict)]
        else:
            out[k] = v
    return out


def enqueue(event: dict, *, config: Optional[GuardConfig] = None) -> None:
    """Append one event to the spool.

    Hot path: must return in microseconds and never raise. If telemetry
    isn't configured, this is a silent no-op so the firewall keeps
    working locally.
    """
    cfg = config if config is not None else load_config()
    if not cfg.telemetry_enabled:
        return

    from cloudanix_guard._safe_io import safe_open_for_append
    path = spool_path()
    try:
        line = json.dumps(event, separators=(",", ":")) + "\n"

        # If the spool is approaching the cap, trim before appending.
        try:
            size = path.stat().st_size if path.exists() else 0
            if size + len(line) > MAX_SPOOL_BYTES:
                _trim_spool(path)
        except OSError:
            pass

        with safe_open_for_append(path) as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            try:
                f.write(line)
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except Exception as e:  # noqa: BLE001 — telemetry must never break the firewall
        sys.stderr.write(f"cloudanix-guard: telemetry enqueue failed: {e}\n")


def flush_once(
    *,
    config: Optional[GuardConfig] = None,
    timeout_seconds: float = DEFAULT_FLUSH_TIMEOUT_SECONDS,
    transport: Optional[HttpTransport] = None,
) -> FlushResult:
    """Send up to :data:`MAX_BATCH_EVENTS` from the spool.

    One HTTP POST per call. Returns the outcome — callers decide
    whether to call again. Designed to be called from cron or from
    an opportunistic flush at hook exit.

    Failure handling:

    - **Network / 5xx / 401**: events stay in spool, ``retryable=True``.
    - **Other 4xx**: events dropped (the contract is broken; retrying
      would just keep failing). Loud stderr note.
    - **2xx**: events removed from spool.
    """
    cfg = config if config is not None else load_config()
    if not cfg.telemetry_enabled:
        return FlushResult(reason="telemetry not configured")

    path = spool_path()
    if not path.exists() or path.stat().st_size == 0:
        return FlushResult(reason="nothing to flush")

    # Skip if we're in backoff after recent failures. Prevents
    # hammering an unreachable console every 2 min from cron.
    next_retry = _in_backoff()
    if next_retry:
        return FlushResult(
            retryable=True,
            reason=f"in backoff after recent failures (next attempt allowed at {next_retry})",
        )

    transport = transport or _urllib_transport

    overflow_state = _read_overflow_state()
    have_overflow = bool(overflow_state.get("dropped_count"))
    # Reserve one slot in the outbound batch for the overflow event so
    # we never exceed MAX_BATCH_EVENTS on the wire.
    spool_cap = MAX_BATCH_EVENTS - 1 if have_overflow else MAX_BATCH_EVENTS

    with path.open("r+", encoding="utf-8") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            lines = f.readlines()
            batch_lines = lines[:spool_cap]
            overflow_event = _make_overflow_event(overflow_state) if have_overflow else None
            events = _events_for_batch(batch_lines, overflow_event)

            # Shrink the outbound batch until the serialized body fits.
            # Two ways to shrink:
            #   - halve batch_lines while we have more than one event;
            #   - drop the head with a loud stderr note when a single
            #     spool event itself exceeds the budget (otherwise the
            #     queue would deadlock on it forever).
            # The Rails ingest rejects > 1 MB with a non-retryable 4xx,
            # so doing this here saves a wasted round-trip.
            #
            # Defensive cap: 256 iterations is way more than any halving
            # of 200 events can possibly need (max ~9 halves). The cap
            # prevents a hypothetical non-monotonic _events_byte_size
            # bug from spinning forever.
            budget = MAX_BATCH_BYTES - _BATCH_BODY_HEADROOM_BYTES
            oversized_dropped = False
            for _ in range(256):
                if not batch_lines or _events_byte_size(events) <= budget:
                    break
                if len(batch_lines) == 1:
                    sys.stderr.write(
                        f"cloudanix-guard: dropping oversized spool event "
                        f"({len(lines[0])} bytes exceeds {budget} byte budget)\n"
                    )
                    lines = lines[1:]
                    oversized_dropped = True
                    batch_lines = lines[:spool_cap]
                else:
                    batch_lines = batch_lines[:len(batch_lines) // 2]
                events = _events_for_batch(batch_lines, overflow_event)

            remaining_lines = lines[len(batch_lines):]

            if not events:
                _rewrite(f, remaining_lines)
                return FlushResult(
                    spool_remaining=len(remaining_lines),
                    reason="spool had only malformed lines; cleared",
                )

            result = _send(cfg, events, timeout_seconds, transport)

            if result.retryable:
                # Keep events in spool for next attempt. Open or extend
                # the backoff window so the next cron tick doesn't
                # immediately retry. Overflow state is preserved too —
                # the next flush will re-prepend the same event.
                _record_flush_failure()
                # If we dropped an oversized event above, persist that
                # decision — retrying it would just fail the same way.
                if oversized_dropped:
                    _rewrite(f, lines)
                result.spool_remaining = len(lines)
                return result

            # Success or non-retryable failure — drop the events. In
            # either case the channel itself is healthy (we got a
            # response from the server), so clear any backoff state.
            # Same for overflow state: whether accepted or rejected,
            # this batch carried it and re-sending would double-count.
            _record_flush_success()
            if have_overflow:
                _clear_overflow_state()
            _rewrite(f, remaining_lines)
            result.sent = len(events)
            result.spool_remaining = len(remaining_lines)
            return result
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def _events_for_batch(batch_lines: List[str], overflow_event: Optional[dict]) -> List[dict]:
    """Build the outbound events list from a slice of spool lines, with
    an optional overflow event prepended."""
    events: List[dict] = []
    if overflow_event is not None:
        events.append(overflow_event)
    for ln in batch_lines:
        try:
            events.append(json.loads(ln))
        except json.JSONDecodeError:
            continue
    return events


def _events_byte_size(events: List[dict]) -> int:
    """Serialized size of just the events list. Used to predict the
    final POST body size (batch metadata adds a small fixed overhead;
    callers budget for it via :data:`_BATCH_BODY_HEADROOM_BYTES`)."""
    return len(json.dumps(events, separators=(",", ":")).encode("utf-8"))


def _make_overflow_event(state: dict) -> dict:
    """Synthesize the ``queue_overflow_dropped`` event from accumulated
    trim stats. ``occurred_at`` is the timestamp of the first dropped
    event so the event lands at the right spot on the dashboard
    timeline; falls back to "now" if no dropped lines had parseable
    timestamps.
    """
    occurred_at = state.get("first_dropped_at") or _iso_now()
    event: dict = {
        "occurred_at": occurred_at,
        "event_type": "queue_overflow_dropped",
        "dropped_count": int(state.get("dropped_count") or 0),
    }
    if state.get("first_dropped_at"):
        event["first_dropped_at"] = state["first_dropped_at"]
    if state.get("last_dropped_at"):
        event["last_dropped_at"] = state["last_dropped_at"]
    return event


# ─── Internals ────────────────────────────────────────────────────

def _send(
    cfg: GuardConfig,
    events: List[dict],
    timeout: float,
    transport: HttpTransport,
) -> FlushResult:
    # Defensive strip of findings[].match in case a caller bypassed
    # make_event(). NF-PRIV-1 belt-and-braces — the wire NEVER carries
    # raw matched content, regardless of how the event got into the spool.
    for event in events:
        f_list = event.get("findings")
        if isinstance(f_list, list):
            event["findings"] = [_strip_match(f) for f in f_list if isinstance(f, dict)]

    body = json.dumps(
        {
            "batch": {
                "batch_uid": _new_batch_uid(),
                "guard_version": _guard_version(),
                "host": _hostname(),
                "os": _os_string(),
                "sent_at": _iso_now(),
            },
            "events": events,
        }
    ).encode("utf-8")

    headers = {
        "Authorization": f"Bearer {cfg.api_token}",
        "Content-Type": "application/json",
        "User-Agent": f"cloudanix-guard/{_guard_version()}",
        "X-Cloudanix-Guard-Version": _guard_version(),
    }

    try:
        status, resp_bytes = transport(cfg.telemetry_endpoint(), headers, body, timeout)
    except Exception as e:  # noqa: BLE001
        return FlushResult(retryable=True, reason=f"transport error: {e}")

    if 200 <= status < 300:
        duplicate = False
        try:
            duplicate = bool(json.loads(resp_bytes).get("duplicate", False))
        except (json.JSONDecodeError, ValueError, AttributeError):
            pass
        return FlushResult(status_code=status, duplicate=duplicate,
                           reason=f"accepted ({len(events)} events)")

    if status == 401:
        # Token revoked / invalid. Don't drop the events — the user
        # might re-configure with a new token shortly.
        return FlushResult(status_code=status, retryable=True,
                           reason="401 unauthorized — token invalid; "
                                  "run `cloudanix-guard configure --api-token <new>`")
    if 500 <= status < 600:
        return FlushResult(status_code=status, retryable=True,
                           reason=f"server {status} — will retry")
    # Other 4xx: contract bug. Drop the events.
    return FlushResult(status_code=status, retryable=False,
                       reason=f"client {status} — events dropped from spool")


def _urllib_transport(url: str, headers: dict, body: bytes, timeout: float
                      ) -> Tuple[int, bytes]:
    """Default transport. Uses stdlib only — no `requests` dependency.

    Constructs an explicit ``ssl.create_default_context()`` so the
    TLS verify posture is locked in regardless of future Python
    defaults or corporate-proxy environment variables. HTTP (no TLS)
    requests pass ``context=None`` — used only by the localhost dev
    flow (``http://localhost:3000``).
    """
    import ssl as _ssl
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    ctx = _ssl.create_default_context() if url.lower().startswith("https") else None
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:  # noqa: S310
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        # 4xx and 5xx land here.
        return e.code, e.read() if hasattr(e, "read") else b""


def _rewrite(f, lines: List[str]) -> None:
    """Atomically (well, under flock) replace the file's content."""
    f.seek(0)
    f.truncate()
    f.writelines(lines)


def _trim_spool(path: Path) -> None:
    """Drop the oldest half of the spool to stay under the cap.

    Spec (``15-console-integration/01-protocol-and-tokens.md`` §2):
    the dropped events must be reported upstream as a single
    ``queue_overflow_dropped`` event. We accumulate the stats into
    ``overflow_state.json`` here; ``flush_once`` synthesizes the
    event when it next drains the spool.

    Single ``flock`` window across read+truncate+write — a previous
    version released the lock between the read and the rewrite, which
    let a concurrent ``enqueue`` append events in the gap that the
    rewrite then silently overwrote. Same pattern as ``flush_once``
    uses with its ``r+`` open.
    """
    try:
        with path.open("r+", encoding="utf-8") as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            try:
                lines = f.readlines()
                cut = len(lines) // 2
                dropped = lines[:cut]
                keep = lines[cut:]

                if dropped:
                    dropped_timestamps = [t for t in (_occurred_at_of(ln) for ln in dropped) if t]
                    state = _read_overflow_state()
                    state["dropped_count"] = int(state.get("dropped_count") or 0) + len(dropped)
                    if dropped_timestamps:
                        first = dropped_timestamps[0]
                        last = dropped_timestamps[-1]
                        state["first_dropped_at"] = state.get("first_dropped_at") or first
                        state["last_dropped_at"] = last
                    _write_overflow_state(state)

                f.seek(0)
                f.truncate()
                f.writelines(keep)
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except OSError:
        pass


def _strip_match(finding: dict) -> dict:
    """Remove the raw match. Defensive only — Finding.to_dict() does
    this too, but if a caller bypassed it we still don't let the
    secret leak upstream."""
    if "match" in finding:
        finding = {k: v for k, v in finding.items() if k != "match"}
    return finding


def _new_batch_uid() -> str:
    """Unique batch identifier matching the server regex
    ``/\\A[A-Za-z0-9_-]{1,64}\\z/``.

    Format: ``cg-<uuid4-hex>`` (35 chars). UUIDv4 gives 122 bits of
    randomness — collisions are vanishingly rare even across millions
    of devices, which matters because the Rails-side uniqueness index
    is per ``(account, entity, user, date_id, batch_uid)``. The ``cg-``
    prefix is for human readability in dashboards.
    """
    return f"cg-{uuid.uuid4().hex}"


def _iso_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _hostname() -> str:
    try:
        return socket.gethostname()
    except Exception:  # noqa: BLE001
        return "unknown"


def _os_string() -> str:
    try:
        return f"{platform.system().lower()}-{platform.release()}"
    except Exception:  # noqa: BLE001
        return "unknown"


def _guard_version() -> str:
    try:
        from cloudanix_guard import __version__
        return __version__
    except (ImportError, AttributeError):
        return "0.0.1"
