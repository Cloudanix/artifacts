"""Install helpers for wiring ``cloudanix-guard`` into Kiro and Claude Code.

Design choices
--------------

Claude Code has a single global hook file (``~/.claude/settings.json``)
or a project-scoped one (``./.claude/settings.json``). We merge our
hook entries into whichever file is in scope.

Kiro has no global hook file — hooks live **inside each agent JSON**.
To keep the user from having to remember to switch to a "secure" agent,
we treat every agent config in the chosen scope as a fleet and inject
our hooks into each one. The installer:

1. Discovers ``*.json`` files in ``~/.kiro/agents/`` (user scope) or
   ``./.kiro/agents/`` (project scope).
2. Merges our ``userPromptSubmit`` + ``preToolUse`` hooks into each,
   preserving every other field and every pre-existing hook the user
   had configured.
3. Identifies its own hook entries by checking for ``cloudanix-guard``
   **and** ``hook`` in the command string (a behavioural marker, not a
   magic comment — safer than assuming Kiro invokes hooks through a
   shell that honours ``#`` comments).
4. Takes a timestamped backup of every file before editing.
5. If zero agent files exist in the chosen scope, drops a starter
   ``secure-default.json`` so the install is still useful.

Limitation we make visible to the user
--------------------------------------

Kiro's **built-in** agents (``kiro_default``, ``kiro_planner``, etc.)
ship inside the Kiro binary and have no config file on disk. We can
only protect user-created agents. Built-ins have to be protected by
the user explicitly running them through a wrapped agent — or by
Kiro adopting a global hook mechanism.
"""

from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple


# Both substrings must appear in a hook command for us to treat it as
# one of ours. Prevents accidental collisions with user-authored hooks.
_CLOUDANIX_SIGNATURE = ("cloudanix-guard", "hook")

# Marker appended to Claude Code hook commands (shell comment — Claude
# Code explicitly runs hooks through a shell, so this is safe there).
CLAUDE_MARKER = "# cloudanix-guard managed hook"

# Fallback agent name created only if the user has no other agents.
FALLBACK_AGENT_NAME = "secure-default"


@dataclass
class InstallPlan:
    """Describes the filesystem changes an install would make."""

    files: List[Tuple[str, str]] = field(default_factory=list)  # (path, new_body)
    backups: List[Tuple[str, str]] = field(default_factory=list)  # (original, backup)
    notes: List[str] = field(default_factory=list)
    # Purely informational — the bodies already contain the merge.
    skipped: List[str] = field(default_factory=list)
    # Files to remove (after their backup is taken). Used by
    # uninstall to clean up cloudanix-planted starter agents.
    deletes: List[str] = field(default_factory=list)


# ═════════════════════════════════════════════════════════════════════ kiro

def _cloudanix_kiro_hooks(guard_cmd: str) -> Dict[str, List[dict]]:
    """The hook block we want present on every Kiro agent.

    Returned as a ``{event_name: [handler, ...]}`` dict so it can be
    merged into an agent config's ``hooks`` field.
    """
    command = f"{guard_cmd} hook"
    return {
        # Warn-only on Kiro per Kiro docs (exit-2 shows as stderr
        # warning but does not block the prompt). Still valuable as
        # a visible signal to the user.
        "userPromptSubmit": [
            {"command": command}
        ],
        # Block-capable on Kiro. This is where the real enforcement
        # happens — any fs_read/fs_write/execute_bash targeting a
        # sensitive path is rejected with exit 2.
        "preToolUse": [
            {
                "matcher": "fs_read|fs_write|execute_bash",
                "command": command,
            }
        ],
    }


def _is_cloudanix_kiro_handler(handler: dict) -> bool:
    """True if this handler was planted by us (or clearly resembles ours)."""
    if not isinstance(handler, dict):
        return False
    cmd = str(handler.get("command", ""))
    return all(sig in cmd for sig in _CLOUDANIX_SIGNATURE)


def _merge_kiro_hooks(agent_config: dict, guard_cmd: str) -> dict:
    """Return a copy of ``agent_config`` with our hooks merged in.

    Preserves every other field. Strips any prior cloudanix-managed
    entries so re-install does not duplicate. Non-cloudanix hooks
    the user has added are kept untouched.
    """
    out = dict(agent_config)
    existing_hooks: Dict[str, List[dict]] = dict(out.get("hooks") or {})
    new_hooks = _cloudanix_kiro_hooks(guard_cmd)

    for event_name, new_handlers in new_hooks.items():
        current = list(existing_hooks.get(event_name) or [])
        # Strip prior cloudanix entries for this event.
        kept = [h for h in current if not _is_cloudanix_kiro_handler(h)]
        existing_hooks[event_name] = kept + list(new_handlers)

    out["hooks"] = existing_hooks
    return out


def _starter_agent_config(guard_cmd: str) -> dict:
    """Minimum-viable agent used only when the user has no agents at all."""
    cfg = {
        "name": FALLBACK_AGENT_NAME,
        "description": (
            "Starter secure agent created by cloudanix-guard install. "
            "Cloudanix Guard hooks are wired into every Kiro agent on "
            "disk; this file exists so install is useful even when "
            "you have not yet created your own agent."
        ),
        "tools": [
            "fs_read",
            "fs_write",
            "execute_bash",
            "grep",
            "glob",
        ],
        "welcomeMessage": (
            "Cloudanix Guard is active. Sensitive file reads, writes, "
            "and shell commands are scanned before they reach the LLM."
        ),
    }
    return _merge_kiro_hooks(cfg, guard_cmd)


def _kiro_scope_dir(scope: str, home: Path, cwd: Path) -> Path:
    if scope == "user":
        return home / ".kiro" / "agents"
    if scope == "project":
        return cwd / ".kiro" / "agents"
    raise ValueError(f"Unknown scope: {scope!r}")


def plan_kiro(
    guard_cmd: str,
    scope: str = "user",
    home: Optional[Path] = None,
    cwd: Optional[Path] = None,
) -> InstallPlan:
    """Plan a fleet-wide install into every Kiro agent in the chosen scope.

    Args:
        guard_cmd: Absolute path to the ``cloudanix-guard`` executable.
        scope: ``"user"`` → ``~/.kiro/agents``,
               ``"project"`` → ``./.kiro/agents``.
    """
    home = home or Path.home()
    cwd = cwd or Path.cwd()
    target_dir = _kiro_scope_dir(scope, home, cwd)

    plan = InstallPlan()
    plan.notes.append(
        f"Kiro ({scope} scope): looking for agents in {target_dir}"
    )

    if not target_dir.exists():
        plan.notes.append(f"Directory does not exist yet — will be created.")

    agent_files = sorted(target_dir.glob("*.json")) if target_dir.exists() else []

    if not agent_files:
        # No agents on disk — install the starter so the user has
        # something to switch to.
        starter_path = target_dir / f"{FALLBACK_AGENT_NAME}.json"
        plan.files.append(
            (str(starter_path), json.dumps(_starter_agent_config(guard_cmd), indent=2) + "\n")
        )
        plan.notes.append(
            f"No existing Kiro agents found — creating starter agent "
            f"'{FALLBACK_AGENT_NAME}'."
        )
        plan.notes.append(
            f"Select it inside Kiro with:  /agent {FALLBACK_AGENT_NAME}"
        )
        return plan

    plan.notes.append(f"Found {len(agent_files)} agent file(s).")
    updated_names: List[str] = []
    for agent_path in agent_files:
        try:
            original = json.loads(agent_path.read_text() or "{}")
        except json.JSONDecodeError as e:
            plan.skipped.append(f"{agent_path}: invalid JSON ({e}); left untouched.")
            continue
        if not isinstance(original, dict):
            plan.skipped.append(f"{agent_path}: not a JSON object; left untouched.")
            continue

        merged = _merge_kiro_hooks(original, guard_cmd)
        new_body = json.dumps(merged, indent=2) + "\n"
        # Skip writing if merge is a no-op (idempotent re-run on unchanged file).
        if new_body == (agent_path.read_text() if agent_path.exists() else ""):
            plan.notes.append(f"{agent_path.name}: already up-to-date; no write needed.")
            continue

        plan.backups.append((str(agent_path), _backup_path(agent_path)))
        plan.files.append((str(agent_path), new_body))
        updated_names.append(merged.get("name", agent_path.stem))

    if updated_names:
        plan.notes.append(
            "Hooks injected into: " + ", ".join(updated_names)
        )
    plan.notes.append(
        "Limitation: Kiro's built-in agents (kiro_default, kiro_planner, "
        "kiro_guide) cannot be modified from outside Kiro. Only user-"
        "created agents are protected."
    )
    return plan


# ═════════════════════════════════════════════════════════════════════ claude code

def _claude_hook_block(guard_cmd: str) -> dict:
    """Hook block for Claude Code settings.json, tagged with our marker."""
    command = f"{guard_cmd} hook  {CLAUDE_MARKER}"
    return {
        "UserPromptSubmit": [
            {
                "matcher": "",
                "hooks": [{"type": "command", "command": command}],
            }
        ],
        "PreToolUse": [
            {
                "matcher": "Read|Edit|Write|Bash",
                "hooks": [{"type": "command", "command": command}],
            }
        ],
    }


def plan_claude(
    guard_cmd: str,
    scope: str = "user",
    home: Optional[Path] = None,
    cwd: Optional[Path] = None,
) -> InstallPlan:
    home = home or Path.home()
    cwd = cwd or Path.cwd()

    if scope == "user":
        target = home / ".claude" / "settings.json"
    elif scope == "project":
        target = cwd / ".claude" / "settings.json"
    else:
        raise ValueError(f"Unknown scope: {scope!r}")

    existing: dict = {}
    if target.exists():
        try:
            existing = json.loads(target.read_text() or "{}")
        except json.JSONDecodeError:
            existing = {}

    merged = _merge_claude_hooks(existing, _claude_hook_block(guard_cmd))
    body = json.dumps(merged, indent=2) + "\n"

    plan = InstallPlan()
    if target.exists():
        plan.backups.append((str(target), _backup_path(target)))
    plan.files.append((str(target), body))
    plan.notes.append(
        f"Claude Code ({scope} scope): merged hooks into {target}."
    )
    plan.notes.append(
        "Cloudanix entries are tagged with a marker; re-install is idempotent."
    )
    return plan


def _merge_claude_hooks(existing: dict, new_hooks: dict) -> dict:
    """Merge our hook entries into an existing settings.json, replacing any
    previous cloudanix-guard entries (identified by the marker) and leaving
    every other hook intact."""
    merged = dict(existing)
    existing_hooks: dict = dict(merged.get("hooks") or {})

    for event_name, new_groups in new_hooks.items():
        groups: List[dict] = [
            _strip_marked_handlers(g) for g in (existing_hooks.get(event_name) or [])
        ]
        groups = [g for g in groups if g.get("hooks")]
        groups.extend(new_groups)
        existing_hooks[event_name] = groups

    merged["hooks"] = existing_hooks
    return merged


def _strip_marked_handlers(group: dict) -> dict:
    """Return a copy of a hook group with cloudanix-managed handlers removed."""
    if not isinstance(group, dict):
        return group
    kept = [
        h
        for h in (group.get("hooks") or [])
        if not (isinstance(h, dict) and CLAUDE_MARKER in str(h.get("command", "")))
    ]
    return {**group, "hooks": kept}


# ═════════════════════════════════════════════════════════════════════ uninstall

def _strip_cloudanix_kiro_hooks(agent_config: dict) -> dict:
    """Return a copy of ``agent_config`` with our hooks removed.

    Non-cloudanix hooks the user added stay untouched. If we end up
    with an empty list under an event, drop the event key entirely so
    re-reading the file shows a clean dict.
    """
    out = dict(agent_config)
    existing: Dict[str, List[dict]] = dict(out.get("hooks") or {})
    cleaned: Dict[str, List[dict]] = {}
    for event_name, handlers in existing.items():
        kept = [h for h in handlers if not _is_cloudanix_kiro_handler(h)]
        if kept:
            cleaned[event_name] = kept
    if cleaned:
        out["hooks"] = cleaned
    else:
        out.pop("hooks", None)
    return out


def plan_kiro_uninstall(
    scope: str = "user",
    home: Optional[Path] = None,
    cwd: Optional[Path] = None,
) -> InstallPlan:
    """Plan removal of every cloudanix-tagged hook from Kiro agents in scope."""
    home = home or Path.home()
    cwd = cwd or Path.cwd()
    target_dir = _kiro_scope_dir(scope, home, cwd)

    plan = InstallPlan()
    plan.notes.append(
        f"Kiro ({scope} scope): scanning {target_dir} for cloudanix-guard hooks."
    )
    if not target_dir.exists():
        plan.notes.append("Directory does not exist — nothing to do.")
        return plan

    agent_files = sorted(target_dir.glob("*.json"))
    if not agent_files:
        plan.notes.append("No agent files found — nothing to do.")
        return plan

    cleared_names: List[str] = []
    deleted_starters: List[str] = []
    for agent_path in agent_files:
        try:
            original = json.loads(agent_path.read_text() or "{}")
        except (json.JSONDecodeError, OSError) as e:
            plan.skipped.append(f"{agent_path}: unreadable ({e}); left untouched.")
            continue
        if not isinstance(original, dict):
            plan.skipped.append(f"{agent_path}: not a JSON object; left untouched.")
            continue

        # If we planted this starter agent ourselves on install (no
        # user-created agents existed at the time), tear it down on
        # uninstall — the user never wanted it; it was an
        # install-time fallback. Recognise it by the exact
        # description string we set in `_starter_agent_config`.
        if _is_planted_starter_agent(original, agent_path):
            plan.backups.append((str(agent_path), _backup_path(agent_path)))
            plan.deletes.append(str(agent_path))
            deleted_starters.append(original.get("name") or agent_path.stem)
            continue

        cleaned = _strip_cloudanix_kiro_hooks(original)
        if cleaned == original:
            continue
        new_body = json.dumps(cleaned, indent=2) + "\n"
        plan.backups.append((str(agent_path), _backup_path(agent_path)))
        plan.files.append((str(agent_path), new_body))
        cleared_names.append(cleaned.get("name", agent_path.stem))

    if cleared_names:
        plan.notes.append("Cleared cloudanix hooks from: " + ", ".join(cleared_names))
    if deleted_starters:
        plan.notes.append(
            "Deleted cloudanix-planted starter agent(s): " + ", ".join(deleted_starters)
        )
    if not cleared_names and not deleted_starters:
        plan.notes.append("No cloudanix hooks found in any agent — nothing to do.")
    return plan


def _is_planted_starter_agent(agent: dict, agent_path: Path) -> bool:
    """Identify the starter agent we may have planted ourselves at
    install time so we can clean it up on uninstall. Two signals
    must match — the filename AND the unique substring in the
    description — to defend against a user-authored agent that
    happens to share one or the other.
    """
    if agent_path.stem != FALLBACK_AGENT_NAME:
        return False
    desc = str(agent.get("description") or "")
    return "Starter secure agent created by cloudanix-guard install" in desc


def plan_claude_uninstall(
    scope: str = "user",
    home: Optional[Path] = None,
    cwd: Optional[Path] = None,
) -> InstallPlan:
    """Plan removal of cloudanix-tagged hooks from Claude Code settings."""
    home = home or Path.home()
    cwd = cwd or Path.cwd()

    if scope == "user":
        target = home / ".claude" / "settings.json"
    elif scope == "project":
        target = cwd / ".claude" / "settings.json"
    else:
        raise ValueError(f"Unknown scope: {scope!r}")

    plan = InstallPlan()
    if not target.exists():
        plan.notes.append(f"{target} does not exist — nothing to do.")
        return plan

    try:
        existing = json.loads(target.read_text() or "{}")
    except (json.JSONDecodeError, OSError) as e:
        plan.skipped.append(f"{target}: unreadable ({e}); left untouched.")
        return plan

    cleaned = _strip_claude_cloudanix(existing)
    if cleaned == existing:
        plan.notes.append(
            f"No cloudanix-tagged hooks in {target} — nothing to do."
        )
        return plan

    body = json.dumps(cleaned, indent=2) + "\n"
    plan.backups.append((str(target), _backup_path(target)))
    plan.files.append((str(target), body))
    plan.notes.append(
        f"Claude Code ({scope} scope): cloudanix hook entries removed from {target}."
    )
    return plan


def _strip_claude_cloudanix(existing: dict) -> dict:
    """Return a copy of Claude settings with our marker'd hook entries removed."""
    out = dict(existing)
    hooks: dict = dict(out.get("hooks") or {})
    cleaned_hooks: dict = {}
    for event_name, groups in hooks.items():
        if not isinstance(groups, list):
            cleaned_hooks[event_name] = groups
            continue
        new_groups = []
        for g in groups:
            stripped = _strip_marked_handlers(g) if isinstance(g, dict) else g
            if isinstance(stripped, dict) and not stripped.get("hooks"):
                # Whole group was ours — drop it.
                continue
            new_groups.append(stripped)
        if new_groups:
            cleaned_hooks[event_name] = new_groups
    if cleaned_hooks:
        out["hooks"] = cleaned_hooks
    else:
        out.pop("hooks", None)
    return out


# ═════════════════════════════════════════════════════════════════════ codex

# OpenAI Codex CLI ships a lifecycle-hooks system intentionally
# designed as a near-clone of Claude Code's. We reuse the Claude
# merge + marker plumbing; the differences live in (a) which file we
# write, (b) the matcher regex for Codex tool names, and (c) the
# `--agent codex` flag the wired command passes so cmd_hook can
# attribute telemetry correctly (event-name casing alone can't
# distinguish Claude from Codex — both PascalCase). See
# the project's Codex integration design doc for the rationale +
# trust-hash gotcha that means dropping the file isn't enough until
# the user approves it inside Codex.


def _codex_hook_block(guard_cmd: str) -> dict:
    """Hook block for Codex's ~/.codex/hooks.json. Same shape as the
    Claude Code block — only the matcher regex and the wired command
    differ."""
    command = f"{guard_cmd} hook --agent codex  {CLAUDE_MARKER}"
    return {
        "UserPromptSubmit": [
            {
                "matcher": "",
                "hooks": [{"type": "command", "command": command}],
            }
        ],
        "PreToolUse": [
            {
                # apply_patch is Codex's canonical edit primitive;
                # Bash/Read/Write/Edit cover both legacy and overlap
                # cases. Matchers are regex over tool names.
                "matcher": "apply_patch|Bash|Read|Write|Edit",
                "hooks": [{"type": "command", "command": command}],
            }
        ],
    }


def plan_codex(
    guard_cmd: str,
    scope: str = "user",
    home: Optional[Path] = None,
    cwd: Optional[Path] = None,
) -> InstallPlan:
    home = home or Path.home()
    cwd = cwd or Path.cwd()

    if scope == "user":
        target = home / ".codex" / "hooks.json"
    elif scope == "project":
        target = cwd / ".codex" / "hooks.json"
    else:
        raise ValueError(f"Unknown scope: {scope!r}")

    existing: dict = {}
    if target.exists():
        try:
            existing = json.loads(target.read_text() or "{}")
        except json.JSONDecodeError:
            existing = {}

    # Same merge algorithm as Claude: per-event, strip prior cloudanix
    # entries (identified by the shared marker), splice ours in, leave
    # everything else untouched.
    merged = _merge_claude_hooks(existing, _codex_hook_block(guard_cmd))
    body = json.dumps(merged, indent=2) + "\n"

    plan = InstallPlan()
    if target.exists():
        plan.backups.append((str(target), _backup_path(target)))
    plan.files.append((str(target), body))
    plan.notes.append(
        f"Codex ({scope} scope): merged hooks into {target}."
    )
    plan.notes.append(
        "Cloudanix entries are tagged with the same marker as Claude; re-install is idempotent."
    )
    plan.notes.append(
        "TRUST-HASH GATE: Codex hashes every hook command and will not run "
        "an untrusted handler. After this install, run `codex` once and "
        "approve the cloudanix-guard hook when prompted — Codex will not "
        "invoke our hook until you do."
    )
    if scope == "project":
        plan.notes.append(
            "Project-scope hooks are silently disabled until you add this "
            "project root to the user-level trust list in ~/.codex/config.toml."
        )
    return plan


def plan_codex_uninstall(
    scope: str = "user",
    home: Optional[Path] = None,
    cwd: Optional[Path] = None,
) -> InstallPlan:
    home = home or Path.home()
    cwd = cwd or Path.cwd()

    if scope == "user":
        target = home / ".codex" / "hooks.json"
    elif scope == "project":
        target = cwd / ".codex" / "hooks.json"
    else:
        raise ValueError(f"Unknown scope: {scope!r}")

    plan = InstallPlan()
    if not target.exists():
        plan.notes.append(f"{target} does not exist — nothing to do.")
        return plan

    try:
        existing = json.loads(target.read_text() or "{}")
    except (json.JSONDecodeError, OSError) as e:
        plan.skipped.append(f"{target}: unreadable ({e}); left untouched.")
        return plan

    # Reuses the Claude strip logic — same marker, same shape.
    cleaned = _strip_claude_cloudanix(existing)
    if cleaned == existing:
        plan.notes.append(
            f"No cloudanix-tagged hooks in {target} — nothing to do."
        )
        return plan

    body = json.dumps(cleaned, indent=2) + "\n"
    plan.backups.append((str(target), _backup_path(target)))
    plan.files.append((str(target), body))
    plan.notes.append(
        f"Codex ({scope} scope): cloudanix hook entries removed from {target}."
    )
    return plan


# ═════════════════════════════════════════════════════════════════════ apply

def _backup_path(p: Path) -> str:
    ts = time.strftime("%Y%m%d-%H%M%S")
    return str(p) + f".bak-{ts}"


def apply(plan: InstallPlan) -> None:
    """Execute an :class:`InstallPlan`."""
    # Take backups first so a failure mid-write still leaves a recoverable
    # state on disk.
    for original, backup in plan.backups:
        Path(backup).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, backup)

    for path_str, body in plan.files:
        path = Path(path_str)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body)

    # Deletions run last so a write-then-delete on the same path
    # (unlikely, but possible if a future plan does so) lands in the
    # right final state.
    for path_str in plan.deletes:
        try:
            Path(path_str).unlink(missing_ok=True)
        except OSError:
            pass


def resolve_guard_command() -> str:
    """Return an absolute path to the ``cloudanix-guard`` executable."""
    which = shutil.which("cloudanix-guard")
    if which:
        return which
    return "python3 -m cloudanix_guard.cli"


def with_profile_prefix(guard_cmd: str, profile: Optional[str]) -> str:
    """Prepend a ``CLOUDANIX_GUARD_PROFILE=<name>`` env-var assignment
    to the wired hook command so the hook process sees the right
    state dir when an agent (Claude / Kiro / Codex) shells out.

    Returns the unchanged command when ``profile`` is None or empty.
    The agents all invoke hooks through a shell (``/bin/sh -c`` or
    equivalent), so a leading ``VAR=value`` assignment is the
    portable way to scope the env var to just this command — no
    quoting, no exec wrapping.
    """
    if not profile or not profile.strip():
        return guard_cmd
    return f"CLOUDANIX_GUARD_PROFILE={profile.strip()} {guard_cmd}"
