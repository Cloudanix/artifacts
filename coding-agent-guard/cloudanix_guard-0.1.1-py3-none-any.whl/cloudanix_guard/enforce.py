"""Enforcement layer — applies a :class:`Decision` to a payload.

Phase A: handle all six modes. For ``redact``, rewrite the prompt and
every attached file in place using the finding offsets, replacing the
sensitive span with a deterministic placeholder
(``<REDACTED:SECRET:aws-access-key:7f3a>``). For ``observe`` /
``warn_continue`` / the two ``warn_*`` modes / ``block``, the payload
is returned untouched — the caller decides whether to surface
warnings, gate on exit code, etc.

Design choices preserved from before:

- We redact from right to left so earlier offsets stay valid.
- Each placeholder embeds a short hash of the original value so the
  same secret is replaced with the same token everywhere in the same
  payload (useful when the model needs to *refer* to a value multiple
  times without ever seeing it).
- The hash is short (first 4 hex chars of SHA-256). It is not meant
  to be reversible — we deliberately avoid persisting the mapping.

Phase B will extend this module (or `cmd_hook`) to consult the
``exceptions.jsonl`` store before exiting 2 on the two warn-and-
approve modes. For Phase A those modes block.
"""

from __future__ import annotations

import hashlib
from typing import Dict, List, Tuple

from cloudanix_guard.inspector.types import Finding, Payload
from cloudanix_guard.policy import Decision, Mode


def _token_for(finding: Finding) -> str:
    """Deterministic placeholder for a finding."""
    digest = ""
    if finding.match:
        digest = hashlib.sha256(finding.match.encode("utf-8")).hexdigest()[:4]
    parts = [finding.type.value.upper(), finding.rule_id]
    if digest:
        parts.append(digest)
    return f"<REDACTED:{':'.join(parts)}>"


def _redact_text(text: str, findings: List[Finding]) -> str:
    """Apply every finding with a span to ``text`` and return the result."""
    spans: List[Tuple[int, int, str]] = []
    for f in findings:
        if f.start is None or f.end is None:
            continue
        spans.append((f.start, f.end, _token_for(f)))
    # Apply right-to-left so earlier offsets remain valid.
    spans.sort(key=lambda s: s[0], reverse=True)
    out = text
    for start, end, token in spans:
        out = out[:start] + token + out[end:]
    return out


_BLOCKED_SENTINEL = "<blocked>"


def apply(payload: Payload, decision: Decision) -> Dict:
    """Apply the decision to ``payload`` and return a result dict.

    The returned dict is the exact shape the hook CLI emits on stdout::

        {
          "mode": "observe" | "warn_continue" | "redact" |
                  "warn_self_justify" | "warn_external_approve" | "block",
          "prompt": "<possibly rewritten prompt or '<blocked>'>",
          "files":  [{"path": ..., "content": "<possibly rewritten or '<blocked>'>"}],
          "reasons": [...],
          "findings": [...],
        }

    NF-PRIV-1: on blocking outcomes the original ``prompt`` and file
    contents never appear in the returned dict — both are replaced
    with the ``<blocked>`` sentinel. A future caller that logs or
    uploads this dict therefore cannot leak the offending input.
    """
    result: Dict = {
        "mode": decision.mode.value,
        "reasons": decision.reasons,
        "findings": [f.to_dict() for f in decision.findings],
        "prompt": payload.prompt,
        "files": [dict(f) for f in payload.files],
    }

    if decision.mode.is_blocking():
        result["prompt"] = _BLOCKED_SENTINEL
        result["files"] = [
            {**entry, "content": _BLOCKED_SENTINEL} for entry in result["files"]
        ]
        return result

    # Redact: partition findings by source and rewrite each in place.
    if decision.mode is Mode.REDACT:
        by_source: Dict[str, List[Finding]] = {}
        for f in decision.findings:
            by_source.setdefault(f.source, []).append(f)

        if "prompt" in by_source:
            result["prompt"] = _redact_text(payload.prompt, by_source["prompt"])

        new_files = []
        for entry in payload.files:
            path = entry.get("path", "")
            content = entry.get("content", "")
            if path in by_source:
                content = _redact_text(content, by_source[path])
            new_files.append({"path": path, "content": content})
        result["files"] = new_files

    # observe / warn_continue — no mutation of payload, just pass through.
    return result
