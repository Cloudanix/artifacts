"""User-level config for the firewall — single profile.

The whole config is three fields in YAML at ``~/.cloudanix-guard/config.yaml``::

    email:        you@your-org.example
    console_url:  https://console.cloudanix.com    # or http://localhost:3000
    api_token:    eyJhbGciOiJIUzI1NiJ9....

- ``email`` identifies the developer in audit / telemetry.
- ``console_url`` is the **base URL** of the Cloudanix Console. The
  ingest path (``/v2/coding_agent_guard/batches``) is appended by the
  telemetry module — keeping the config to a base URL means future
  endpoints (policy pull, upgrade-check) don't need a config change.
  Bare hostnames are normalised to ``https://`` (or ``http://`` for
  ``localhost``).
- ``api_token`` is a JWT minted from
  ``console.cloudanix.com → Settings → API Tokens``. Stored at rest
  with mode ``0600`` — same threat model as ``~/.aws/credentials``.

The firewall keeps working locally if no config is present; telemetry
simply doesn't run. There is exactly one profile per machine — no
``[default]`` / ``[work]`` split. If you need that later, we add it
without breaking this shape.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import yaml


# ─── Paths ─────────────────────────────────────────────────────────

def config_dir() -> Path:
    """Where the per-user firewall state lives.

    Resolution order (first match wins):

    1. ``CLOUDANIX_GUARD_STATE_DIR`` — absolute override. Used by tests
       to point at a tmp dir; also a manual escape hatch.
    2. ``CLOUDANIX_GUARD_PROFILE=<name>`` — switches to
       ``~/.cloudanix-guard/profiles/<name>/`` so a single laptop can
       carry more than one set of (console_url, api_token, exceptions,
       spool, …). NOT a customer-facing feature — kept for Cloudanix
       internal devs who need to be both product-dev and real-user on
       the same machine, and for the occasional MSP / consultant case.
       See the "Multiple profiles" section in the README for the
       intended workflow.
    3. Default: ``~/.cloudanix-guard/``.
    """
    override = os.environ.get("CLOUDANIX_GUARD_STATE_DIR")
    if override:
        return Path(override)
    profile = os.environ.get("CLOUDANIX_GUARD_PROFILE", "").strip()
    if profile:
        return Path.home() / ".cloudanix-guard" / "profiles" / profile
    return Path.home() / ".cloudanix-guard"


def config_path() -> Path:
    return config_dir() / "config.yaml"


# ─── Data ──────────────────────────────────────────────────────────

@dataclass
class GuardConfig:
    """Parsed config. Missing fields are ``None``."""

    email: Optional[str] = None
    console_url: Optional[str] = None
    api_token: Optional[str] = None

    @property
    def telemetry_enabled(self) -> bool:
        """True when we have enough to push events upstream."""
        return bool(self.console_url and self.api_token)

    def telemetry_endpoint(self) -> str:
        """Full URL of the ingest endpoint.

        Raises ``ValueError`` if ``console_url`` is missing — callers
        should gate on :attr:`telemetry_enabled` first.
        """
        if not self.console_url:
            raise ValueError("console_url is not configured")
        base = _normalize_url(self.console_url).rstrip("/")
        return f"{base}/v2/coding_agent_guard/batches"

    def redacted_token(self) -> str:
        """Display-safe form of the token for status output."""
        if not self.api_token:
            return "<unset>"
        t = self.api_token
        if len(t) <= 12:
            return "***"
        return f"{t[:6]}…{t[-4:]}"


def _normalize_url(url: str) -> str:
    """Ensure a scheme. Defaults to https, except for localhost."""
    if "://" in url:
        return url
    host = url.split("/", 1)[0].split(":", 1)[0]
    if host in ("localhost", "127.0.0.1", "::1"):
        return f"http://{url}"
    return f"https://{url}"


# ─── I/O ───────────────────────────────────────────────────────────

def load() -> GuardConfig:
    """Read config from disk. Returns an empty :class:`GuardConfig`
    if the file is missing or malformed — the firewall must continue
    to work locally in either case."""
    path = config_path()
    if not path.exists():
        return GuardConfig()
    try:
        raw = yaml.safe_load(path.read_text()) or {}
    except (yaml.YAMLError, OSError):
        return GuardConfig()
    if not isinstance(raw, dict):
        return GuardConfig()
    return GuardConfig(
        email=_str_or_none(raw.get("email")),
        console_url=_str_or_none(raw.get("console_url")),
        api_token=_str_or_none(raw.get("api_token")),
    )


def save(config: GuardConfig) -> Path:
    """Write config to disk at mode ``0600`` (parent dir at ``0700``).

    Returns the path written. Token is stored in plaintext — see module
    docstring for the rationale. Permissions are applied via the
    centralised ``_safe_io`` helpers so all state files in
    ``~/.cloudanix-guard/`` carry the same conservative mode.
    """
    from cloudanix_guard._safe_io import safe_write_text
    body = yaml.safe_dump(
        {
            "email": config.email,
            "console_url": config.console_url,
            "api_token": config.api_token,
        },
        default_flow_style=False,
        sort_keys=False,
    )
    return safe_write_text(config_path(), body)


def _str_or_none(value) -> Optional[str]:
    if value is None:
        return None
    s = str(value).strip()
    return s or None
