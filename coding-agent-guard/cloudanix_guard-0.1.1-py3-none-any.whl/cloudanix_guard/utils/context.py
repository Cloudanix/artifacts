"""Trace-id helpers for cross-component correlation.

Mirrors the ``init_trace_id`` / ``resolve_trace_id`` pattern from
``aws-compliance-analyst-python/utils/context.py``. The hook flow is:

1. ``init_trace_id()`` is called at the very start of the hook process,
   *before* stdin is parsed. It generates a UUID and sets it on the
   logger's contextvar so even malformed-payload errors are traceable.

2. ``resolve_trace_id(payload)`` is called once the payload is parsed.
   If the payload carries a stable id (Claude Code injects
   ``session_id`` into every hook event), that id replaces the temp
   UUID — a single line is logged to bridge the two values so an
   audit search can walk from the final id back to the early logs.

3. The logger reads the contextvar on every log call, so existing log
   sites don't need to thread the id manually. Telemetry events pick
   it up the same way.

Why not just thread an id through every call?
---------------------------------------------

A ContextVar costs nothing on the hot path, survives across the
existing module-singletons (logger, telemetry queue, inspector), and
means we can add new log sites without plumbing. The reference
project's listener motivated this with concurrent request safety; for
the guard the motivation is just terseness — we don't want every
helper signature to grow a ``trace_id`` parameter.

The reference project lives in ``utils/context.py`` next to a big
``AppContext`` dataclass. This project intentionally does NOT
introduce ``AppContext``: existing modules (``policy``, ``inspector``,
``state``, ``telemetry``, ``config_file``) already encapsulate the
config they need. Bundling them in one god-object would be a forced
fit. The trace-id helpers stand alone.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, Optional

from cloudanix_guard.utils.logger import _current_trace_id, get_logger


def init_trace_id() -> str:
    """Generate a fresh UUID, publish it to the logger contextvar, and
    return it.

    Call this at the start of every entry point (CLI subcommand, hook
    dispatcher). Subsequent ``logger.info(...)`` calls in the same
    process will auto-include the id in their ``context``.
    """
    temp_id = str(uuid.uuid4())
    _current_trace_id.set(temp_id)
    return temp_id


# Source keys, in resolution-priority order. Single source of truth so
# extract_trace_id and the "source" field reported in the bridge log
# can never disagree (an earlier version had them re-listed separately
# and they drifted on the non-string-value edge case).
_TRACE_ID_KEYS = ("session_id", "sessionId", "tool_use_id", "toolUseId")


def _extract_with_source(payload: Optional[Dict[str, Any]]) -> "tuple[Optional[str], Optional[str]]":
    """Return ``(value, source_key)`` for the first usable id in ``payload``,
    or ``(None, None)``."""
    if not isinstance(payload, dict):
        return None, None
    for key in _TRACE_ID_KEYS:
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip(), key
    return None, None


def extract_trace_id(payload: Optional[Dict[str, Any]]) -> Optional[str]:
    """Pull a stable trace identifier out of a hook payload, or ``None``.

    Resolution order (first usable string wins): ``session_id`` →
    ``sessionId`` → ``tool_use_id`` → ``toolUseId``. Claude Code
    injects ``session_id`` on every hook event; the others exist for
    Kiro / camelCase variants and for tool-call-scoped ids.

    Returns ``None`` if no key carries a non-empty string — the caller
    keeps the UUID from :func:`init_trace_id`.
    """
    value, _source = _extract_with_source(payload)
    return value


def resolve_trace_id(payload: Optional[Dict[str, Any]], temp_trace_id: str) -> str:
    """Replace ``temp_trace_id`` with the payload's stable id if it has one.

    Logs a single ``trace_id resolved`` line bridging the two values so
    an audit search by the final id can find the early logs that were
    written under the temp UUID. Returns the trace_id in effect after
    the call (either the resolved one or ``temp_trace_id`` unchanged).
    """
    resolved, source = _extract_with_source(payload)
    if resolved and resolved != temp_trace_id:
        get_logger().info(
            "trace_id resolved",
            context={
                "trace_id_before": temp_trace_id,
                "trace_id": resolved,
                "source": source,
            },
        )
        _current_trace_id.set(resolved)
        return resolved
    return temp_trace_id
