"""Shared constants.

Mirrors the role of ``utils/constants.py`` in
``aws-compliance-analyst-python``. Environment-variable names use the
``CLOUDANIX_GUARD_`` prefix already established by the rest of the
project (e.g. ``CLOUDANIX_GUARD_STATE_DIR``, ``CLOUDANIX_GUARD_PROFILE``)
rather than the reference project's ``CDX_`` prefix.
"""

# App environment toggle, read by Logger to pick between dev and prod
# formatters. Equivalent to ``CDX_APP_ENV`` in the reference project.
APP_ENV_NAME = "CLOUDANIX_GUARD_APP_ENV"
APP_ENV_PRODUCTION = "PRODUCTION"

# Default log level used by ``get_logger`` when callers don't pass one.
#
# WARNING (not INFO) on purpose. The guard runs as a CLI hook whose
# stderr is the protocol surface to Claude Code / Kiro — every line
# we write is shown to the user (and the LLM). At WARNING the logger
# stays silent on the happy path; debug runs opt in via
# ``CLOUDANIX_GUARD_LOG_LEVEL=DEBUG`` or an explicit ``set_level`` call.
#
# Diverges from the reference project, which defaults to INFO because
# its Lambda stderr lands in CloudWatch — not a user-visible surface.
DEFAULT_LOG_LEVEL = "WARNING"

# Env var that overrides ``DEFAULT_LOG_LEVEL`` at logger creation time.
# Accepts standard names: DEBUG / INFO / WARNING / ERROR / CRITICAL.
LOG_LEVEL_ENV = "CLOUDANIX_GUARD_LOG_LEVEL"
