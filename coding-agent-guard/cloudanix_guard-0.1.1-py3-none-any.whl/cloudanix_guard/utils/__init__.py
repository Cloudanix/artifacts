"""Cross-cutting utilities — modelled on aws-compliance-analyst-python/utils.

Members:

- :mod:`cloudanix_guard.utils.logger`    — structured logger with
  context-dict standard, redaction, and trace_id auto-injection.
- :mod:`cloudanix_guard.utils.errors`    — typed error hierarchy.
- :mod:`cloudanix_guard.utils.context`   — trace_id helpers
  (``init_trace_id`` / ``resolve_trace_id``).
- :mod:`cloudanix_guard.utils.constants` — environment variable names
  and other shared constants.
"""
