"""Structured logger — context-dict standard, redaction, trace_id auto-injection.

Mirrors ``utils/logger.py`` in ``aws-compliance-analyst-python`` so the
same team can move between projects without re-learning the rules.

Standard
--------

1. **Mandatory context dict.** Every log call MUST pass ``context`` as
   a dictionary. Variables go *in* the dict, not formatted into the
   message string::

       logger.info("scan finished", context={"findings": len(findings), "mode": mode.value})

   NOT::

       logger.info(f"scan finished with {len(findings)} findings")    # ❌

2. **Method intent.**
   - ``logger.error``   — inside ``except`` blocks (auto-captures stack).
   - ``logger.warning`` — error conditions without an active exception.
   - ``logger.info``    — operational events.
   - ``logger.debug``   — detailed diagnostics.

3. **Redaction.** Keys whose names contain ``token``, ``password``,
   ``secret``, ``api_key``, ``credential``, ``session``, ``cookie``,
   ``bearer`` and a handful of explicit names are auto-redacted before
   the line is emitted. Nested dicts and lists are walked.

4. **Trace ID.** A per-invocation correlation id, set via
   :func:`cloudanix_guard.utils.context.init_trace_id`, is auto-injected
   into every log line via a :class:`contextvars.ContextVar` — call
   sites do not need to thread it through manually.

Why a singleton
---------------

``get_logger()`` returns a process-wide singleton, matching the
reference implementation. The guard runs as a short-lived CLI, so
multi-request concurrency concerns from the reference's Flask
listener don't apply here — but using a ``contextvars.ContextVar``
for ``trace_id`` keeps us future-proof if the guard ever runs in a
daemon mode.

CLI protocol vs diagnostics
---------------------------

The guard's hook mode communicates with Claude Code / Kiro through
stdout (a JSON decision blob) and stderr (a human-readable block
message). Those remain plain ``print()`` / ``sys.stderr.write`` calls
— they are protocol, not logging. This logger is for *internal*
diagnostics (scanner debug, telemetry queue state, install progress,
error paths), where structured context is valuable.
"""

from __future__ import annotations

import contextvars
import datetime
import logging
import os
import sys
import time
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional, Tuple, Union

from cloudanix_guard.utils.constants import APP_ENV_NAME, APP_ENV_PRODUCTION


# Per-invocation trace_id. Lives in a ContextVar so a future daemon
# variant (or threaded test harness) cannot leak ids between requests.
# See ``cloudanix_guard.utils.context.init_trace_id`` /
# ``resolve_trace_id`` for the producers.
_current_trace_id: contextvars.ContextVar[str] = contextvars.ContextVar("_current_trace_id", default="")


class Logger:
    def __init__(self, log_level: Union[int, str]):
        self.logger = logging.getLogger("cloudanix_guard")
        self.set_level(log_level)

        self.logger.handlers = []  # clear any inherited handlers
        self.logger.propagate = False

        handler = logging.StreamHandler(sys.stderr)
        handler.setLevel(self.logger.level)

        # Timing + redaction settings — kept symmetric with the reference.
        self._timings: Dict[str, Dict[str, Union[float, int]]] = {}
        self.timing_enabled = False
        self._redaction_token = "***REDACTED***"
        self._sensitive_key_parts = (
            "token",
            "password",
            "secret",
            "apikey",
            "api_key",
            "access_key",
            "private_key",
            "credential",
            "session",
            "cookie",
            "bearer",
        )
        self._sensitive_keys = {
            "authorization",
            "auth_token",
            "client_secret",
            "refresh_token",
            "id_token",
            "accesskeyid",
            "secretaccesskey",
            "sessiontoken",
            "password",
            "api_key",
            "apikey",
            "usertoken",
        }

        # Production formatter omits the call-site for terser logs;
        # dev formatter keeps {funcName:lineno} for fast debugging.
        if os.environ.get(APP_ENV_NAME) == APP_ENV_PRODUCTION:
            formatter = logging.Formatter(
                "[%(asctime)s.%(msecs)03d] %(levelname)-s - %(message)s - %(context)s",
                "%Y-%m-%d %H:%M:%S",
            )
        else:
            formatter = logging.Formatter(
                "[%(asctime)s.%(msecs)03d] %(levelname)-s - {%(funcName)s:%(lineno)d} - %(message)s - %(context)s",
                "%Y-%m-%d %H:%M:%S",
            )

        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

    # ─── Level / config ────────────────────────────────────────────

    def set_level(self, log_level: Union[int, str]) -> None:
        """Accept either an int (``logging.INFO``) or a string (``"INFO"``).

        Falls back to ``WARNING`` on an unrecognised string rather than
        raising — a typo in ``CLOUDANIX_GUARD_LOG_LEVEL`` must not put
        a Python stack trace in front of the LLM on every hook call.
        """
        if isinstance(log_level, str):
            resolved = logging.getLevelName(log_level.upper())
            if not isinstance(resolved, int):
                # logging.getLevelName returns a string like "Level FOO"
                # for unknown names. Don't pass that to setLevel — it
                # would raise. Warn once and fall back to WARNING.
                print(
                    f"cloudanix-guard: unknown log level {log_level!r}; using WARNING",
                    file=sys.stderr,
                )
                resolved = logging.WARNING
            log_level = resolved
        self.logger.setLevel(log_level)

    def set_timing_enabled(self, enabled: bool) -> None:
        self.timing_enabled = enabled

    # ─── Context validation + redaction ────────────────────────────

    @staticmethod
    def validate_context(context: Any) -> Dict[str, Any]:
        """Normalise context to a dict. Missing / non-dict → empty dict.

        Never include secrets, tokens, credentials, or raw PII in
        context. Use entity ids, operation names, request ids — the
        redactor is the second line of defence, not the first.
        """
        if context is None or not isinstance(context, dict):
            return {}
        return context

    def _is_sensitive_key(self, key: str) -> bool:
        lowered = key.lower()
        if lowered in self._sensitive_keys:
            return True
        return any(part in lowered for part in self._sensitive_key_parts)

    def _redact_value(self, value: Any) -> Any:
        if isinstance(value, dict):
            return {
                key: (
                    self._redact_sensitive_value(val) if self._is_sensitive_key(str(key)) else self._redact_value(val)
                )
                for key, val in value.items()
            }
        if isinstance(value, list):
            return [self._redact_value(item) for item in value]
        if isinstance(value, tuple):
            return tuple(self._redact_value(item) for item in value)
        return value

    def _redact_sensitive_value(self, value: Any) -> str:
        text = str(value)
        if not text:
            return text
        reveal_count = min(3, len(text))
        if len(text) <= 2 * reveal_count:
            reveal_count = max(1, len(text) // 2)
        start = text[:reveal_count]
        end = text[-reveal_count:] if reveal_count else ""
        return f"{start}{self._redaction_token}{end}"

    def _prepare_context(self, context: Any) -> Dict[str, Any]:
        context = dict(self.validate_context(context))

        # Auto-inject trace_id from the contextvar. setdefault so a
        # caller can still override with an explicit value if needed.
        trace_id = _current_trace_id.get()
        if trace_id:
            context.setdefault("trace_id", trace_id)

        return self._redact_value(context)

    # ─── Log emission ──────────────────────────────────────────────

    def _log(self, level: str, msg: str, context: Dict[str, Any], *args: Any, **kwargs: Any) -> None:
        # In production we bypass the logging module's formatter and
        # write directly to stderr — matches the reference and keeps
        # the line format identical to other Cloudanix services.
        if os.environ.get(APP_ENV_NAME) == APP_ENV_PRODUCTION:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            msecs = int(time.time() * 1000) % 1000
            if context:
                print(f"[{timestamp}.{msecs:03d}] {level} - {msg} - {context}", file=sys.stderr)
            else:
                print(f"[{timestamp}.{msecs:03d}] {level} - {msg}", file=sys.stderr)
        else:
            log_context = {"context": context}
            getattr(self.logger, level.lower())(msg, *args, extra=log_context, **kwargs)

    def _should_use_exception(self, kwargs: Dict[str, Any]) -> bool:
        if kwargs.get("exc_info"):
            return True
        exc_type, _, _ = sys.exc_info()
        return exc_type is not None

    def debug(self, msg: str, *args: Any, context: Any = None, **kwargs: Any) -> None:
        ctx = self._prepare_context(context)
        self._log("DEBUG", msg, ctx, *args, **kwargs)

    def info(self, msg: str, *args: Any, context: Any = None, **kwargs: Any) -> None:
        ctx = self._prepare_context(context)
        self._log("INFO", msg, ctx, *args, **kwargs)

    def warning(self, msg: str, *args: Any, context: Any = None, **kwargs: Any) -> None:
        ctx = self._prepare_context(context)
        self._log("WARNING", msg, ctx, *args, **kwargs)

    def error(self, msg: str, *args: Any, context: Any = None, **kwargs: Any) -> None:
        ctx = self._prepare_context(context)
        if self._should_use_exception(kwargs):
            kwargs.setdefault("exc_info", True)
            self.exception(msg, context=ctx, *args, **kwargs)
            return
        self._log("ERROR", msg, ctx, *args, **kwargs)

    def exception(self, msg: str, *args: Any, context: Any = None, **kwargs: Any) -> None:
        ctx = self._prepare_context(context)
        if os.environ.get(APP_ENV_NAME) == APP_ENV_PRODUCTION:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            msecs = int(time.time() * 1000) % 1000
            if ctx:
                print(f"[{timestamp}.{msecs:03d}] EXCEPTION - {msg} - {ctx}", file=sys.stderr)
            else:
                print(f"[{timestamp}.{msecs:03d}] EXCEPTION - {msg}", file=sys.stderr)
        else:
            kwargs.setdefault("exc_info", True)
            log_context = {"context": ctx}
            self.logger.exception(msg, *args, extra=log_context, **kwargs)

    def critical(self, msg: str, *args: Any, context: Any = None, **kwargs: Any) -> None:
        ctx = self._prepare_context(context)
        self._log("CRITICAL", msg, ctx, *args, **kwargs)

    # ─── Timing helpers (opt-in) ───────────────────────────────────

    def _record_timing(self, name: str, elapsed_ms: float) -> Tuple[float, int]:
        if name not in self._timings:
            self._timings[name] = {"total_ms": 0.0, "count": 0}
        self._timings[name]["total_ms"] += elapsed_ms
        self._timings[name]["count"] += 1
        return float(self._timings[name]["total_ms"]), int(self._timings[name]["count"])

    @contextmanager
    def time_call(
        self,
        name: str,
        level: str = "debug",
        context: Optional[Dict[str, Any]] = None,
    ) -> Iterator[None]:
        if not self.timing_enabled:
            yield
            return
        start = time.perf_counter()
        try:
            yield
        finally:
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            total_ms, count = self._record_timing(name, elapsed_ms)
            log_context: Dict[str, Any] = {
                "method": name,
                "elapsed_ms": round(elapsed_ms, 2),
                "total_ms": round(total_ms, 2),
                "count": count,
            }
            if context:
                log_context.update(context)
            log_level = level
            if level == "debug" and not self.logger.isEnabledFor(logging.DEBUG):
                log_level = "info"
            log_fn = getattr(self, log_level.lower(), self.debug)
            log_fn("method timing", context=log_context)

    def log_timing_summary(self, level: str = "debug") -> None:
        if not self.timing_enabled or not self._timings:
            return
        log_level = level
        if level == "debug" and not self.logger.isEnabledFor(logging.DEBUG):
            log_level = "info"
        for name, data in sorted(self._timings.items(), key=lambda item: item[1]["total_ms"], reverse=True):
            log_context = {
                "method": name,
                "total_ms": round(data["total_ms"], 2),
                "count": int(data["count"]),
            }
            log_fn = getattr(self, log_level.lower(), self.debug)
            log_fn("method timing summary", context=log_context)


# Process-wide singleton — same shape as the reference's get_logger().
_log_client: Optional[Logger] = None


def get_logger(log_level: Union[int, str, None] = None) -> Logger:
    """Return the process-wide singleton logger, creating it on first call.

    Resolution for the initial level (only applied on first creation):

    1. Explicit ``log_level`` argument, if non-None.
    2. ``CLOUDANIX_GUARD_LOG_LEVEL`` env var, if set.
    3. ``DEFAULT_LOG_LEVEL`` (WARNING).

    Subsequent calls return the same instance and ignore ``log_level``
    — to change the level after init, call ``logger.set_level(...)``.
    """
    global _log_client
    if _log_client is None:
        from cloudanix_guard.utils.constants import (
            DEFAULT_LOG_LEVEL,
            LOG_LEVEL_ENV,
        )

        if log_level is None:
            log_level = os.environ.get(LOG_LEVEL_ENV) or DEFAULT_LOG_LEVEL
        _log_client = Logger(log_level)
    return _log_client


def reset_logger_for_tests() -> None:
    """Drop the singleton — only used by the test suite.

    Production code should never call this. Tests use it to isolate
    handler / formatter state across cases that toggle ``APP_ENV_NAME``.
    """
    global _log_client
    _log_client = None
