"""Typed error hierarchy for the guard.

Mirrors ``utils/errors.py`` in ``aws-compliance-analyst-python``. The
root class is :class:`GuardError` (named to avoid colliding with the
project's existing :mod:`cloudanix_guard.exceptions` module, which
holds the user-facing "self-justification exception" store — a
domain noun, not an error type).

Adopting these gradually
------------------------

The existing code uses bare ``Exception`` and several
``except Exception:  # noqa: BLE001`` catches. Both still work — this
module is additive. As call sites are touched, prefer raising the
typed subclass that fits the failure category, and catch by category
rather than the bare base.

Why not ``Exception`` directly?
-------------------------------

Two reasons, both lifted from the reference:

1. **Optional context dict.** Every error can carry a structured
   ``context`` payload that downstream handlers (logger, telemetry,
   future Sentry tagger) can attach without parsing the message.
2. **Category catches.** Code that needs to react to "anything in the
   policy load path went wrong" can write
   ``except PolicyError`` instead of a broad ``except Exception``
   that would also swallow ``KeyboardInterrupt``-adjacent bugs.
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class GuardError(Exception):
    """Base class for every error raised by the guard.

    Attributes:
        context: Optional structured context attached at raise time.
                 Loggers and telemetry are expected to read this and
                 merge it into their own ``context`` field.
    """

    def __init__(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        *args: object,
    ) -> None:
        super().__init__(message, *args)
        self.context: Dict[str, Any] = context or {}


# ─── Config / policy / scanner / state errors ──────────────────────


class ConfigError(GuardError):
    """User-level config (``~/.cloudanix-guard/config.yaml``) is missing,
    malformed, or carries values the runtime cannot use."""


class PolicyError(GuardError):
    """The YAML policy or rules file could not be loaded or is invalid."""


class ScannerError(GuardError):
    """A scanner (secrets / pii / files / presidio / gitleaks) failed.

    Scanners are individually fail-soft on the hot path — a
    :class:`ScannerError` from one scanner must NOT crash the hook;
    callers should log it and continue with the remaining scanners'
    findings."""


class TelemetryError(GuardError):
    """A telemetry enqueue / flush / batching operation failed.

    The hot path swallows these — see
    :mod:`cloudanix_guard.telemetry` — but the type exists so the
    flush CLI can surface meaningful errors back to the user."""


class StateError(GuardError):
    """Pause / resume / audit-log state could not be read or written."""


class InstallError(GuardError):
    """Hook install / uninstall for Claude Code / Kiro / Codex failed."""


class ExceptionStoreError(GuardError):
    """The self-justification exception store
    (``~/.cloudanix-guard/exceptions.jsonl``) could not be read or
    updated."""
