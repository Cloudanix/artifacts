"""Adapter that normalises a ``preToolUse`` / ``PreToolUse`` event into a
:class:`Payload` the inspector can scan.

Different agents name their tools differently and nest file paths in
different places. Rather than teaching every scanner about every agent,
we collapse tool calls into the shared :class:`Payload` shape:

- Any file path touched by the call becomes a ``files`` entry
  (``path`` set, ``content`` empty — path-based rules still fire).
- For shell / bash tools, the command string becomes the ``prompt``
  so that the secrets + PII scanners still get a chance.

Recognised tools (case-insensitive):

============================  ==================================================
Tool name(s)                  Where the path(s) live
============================  ==================================================
``Read``, ``fs_read``,        ``tool_input.file_path``
``fsRead``, ``read``          or ``tool_input.operations[].path`` (Kiro batch)
----------------------------  --------------------------------------------------
``Edit``, ``Write``,          ``tool_input.file_path``
``fs_write``, ``fsWrite``
----------------------------  --------------------------------------------------
``Bash``, ``shell``,          ``tool_input.command`` — treated as free text so
``execute_bash``,             the prompt scanners scan it for secrets / PII.
``execute_cmd``                We also extract any token that looks like a path
                              (starts with ``/``, ``./``, ``~`` or contains a
                              ``.env``-style basename) and add it as a file
                              entry so file-path rules fire on ``cat .env``.
============================  ==================================================
"""

from __future__ import annotations

import os
import re
import stat
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from cloudanix_guard.inspector.types import Payload


_READ_TOOLS = {"read", "fs_read", "fsread"}
# `apply_patch` is OpenAI Codex's canonical edit primitive — same
# shape as Claude's Edit/Write (file_path + content / patch text).
_WRITE_TOOLS = {"write", "edit", "fs_write", "fswrite", "multiedit", "apply_patch", "applypatch"}
_SHELL_TOOLS = {"bash", "shell", "execute_bash", "execute_cmd", "executebash"}

# Rough token matcher used on shell commands: paths starting with /, ./, ~,
# or bare filenames that look dotted (.env, .env.local, id_rsa, ...).
_PATH_TOKEN = re.compile(
    r"""(?x)
    (?:
        (?:~|\.{1,2})?/[^\s'";&|<>]+        # /foo, ./foo, ~/foo
      | \.[A-Za-z][A-Za-z0-9_.\-]*          # .env, .env.local, .aws
      | [A-Za-z0-9_\-./]*id_(?:rsa|ed25519|ecdsa|dsa)[^\s'";&|<>]*
      | [A-Za-z0-9_\-./]+\.(?:pem|key|p12|pfx|crt)
    )
    """
)


def _extract_paths_from_command(command: str) -> List[str]:
    """Pull anything that *looks* like a file reference out of a shell command."""
    if not command:
        return []
    out: List[str] = []
    seen: set[str] = set()
    for m in _PATH_TOKEN.finditer(command):
        tok = m.group(0).rstrip(".,;:)]}")
        if tok and tok not in seen:
            seen.add(tok)
            out.append(tok)
    return out


def payload_from_tool_use(tool_name: str, tool_input: Dict[str, Any]) -> Payload:
    """Build a :class:`Payload` from a ``preToolUse`` event body.

    The returned payload is safe to hand to :meth:`Inspector.inspect`.
    """
    name = (tool_name or "").lower()
    tool_input = tool_input or {}
    files: List[Dict[str, str]] = []
    prompt = ""

    def _add_file(path: str | None, content: str = "") -> None:
        if not path:
            return
        files.append({"path": path, "content": content or ""})

    if name in _READ_TOOLS:
        # Claude Code shape
        _add_file(tool_input.get("file_path"))
        # Kiro fs_read shape (batch of operations)
        for op in tool_input.get("operations") or []:
            if isinstance(op, dict):
                _add_file(op.get("path"))

    elif name in _WRITE_TOOLS:
        _add_file(tool_input.get("file_path"), content=tool_input.get("content", "") or "")
        # Edit tools may carry old_string/new_string that can contain secrets.
        # Codex's apply_patch uses `patch` (unified-diff style); we treat it
        # as scannable text so embedded secrets / PII still fire.
        for key in ("new_string", "old_string", "content", "patch"):
            val = tool_input.get(key)
            if isinstance(val, str) and val:
                prompt += val + "\n"

    elif name in _SHELL_TOOLS:
        command = tool_input.get("command", "") or ""
        prompt = command
        for path in _extract_paths_from_command(command):
            _add_file(path)

    else:
        # Unknown tool — best effort: if there's a string `file_path`, capture it.
        if isinstance(tool_input.get("file_path"), str):
            _add_file(tool_input["file_path"])

    return Payload(prompt=prompt, files=files)


# ─── PreToolUse content-scan augmentation ────────────────────────

@dataclass
class FileScanResult:
    """Per-file metadata emitted alongside :func:`augment_with_file_content`
    so the caller can emit a ``read_content_scanned`` telemetry event.

    ``status`` is one of:

    - ``scanned``           — file was read and its content placed on the payload
    - ``cached_clean``      — cache hit on a previously-clean file; no I/O
    - ``cached_dirty``      — cache hit on a file with prior findings; no I/O.
                              The caller should replay those findings through
                              the policy engine.
    - ``skipped_missing``   — file does not exist on disk
    - ``skipped_too_large`` — file size exceeded ``max_scan_bytes``
    - ``skipped_binary``    — magic-byte check classified it as binary
    - ``skipped_symlink``   — path is a symlink; refused to follow (defense
                              against an attacker-controlled agent pointing at
                              /etc/shadow via a symlink)
    - ``skipped_denied_root`` — path is outside the configured allow-roots
                              (default: cwd ancestry + $HOME); refused on
                              the principle that the guard should not become
                              an exfil oracle for paths the agent can name
                              but the user wouldn't normally edit
    """

    path: str
    status: str
    bytes_scanned: int = 0
    mtime: Optional[float] = None
    size: Optional[int] = None
    # Set on `cached_dirty` so the caller knows what to replay without
    # poking the cache module a second time.
    cached_findings: List[Any] = field(default_factory=list)


_BINARY_PROBE_BYTES = 512


def _looks_binary(sample: bytes) -> bool:
    """Cheap magic-byte heuristic: a NUL byte in the first 512 is the
    classic "this is binary" tell that tools like ``grep`` use."""
    if not sample:
        return False
    return b"\x00" in sample


# System paths the guard refuses to scan regardless of allow-roots.
# Surgical on purpose — broad ``/var/`` etc. would catch pytest's
# tmpdir on macOS (which lives under ``/private/var/folders/``) and
# many legitimate dev workflows. The threat we're defending against
# is an attacker-controlled agent naming /etc/shadow or
# /proc/self/environ as a "Read this file please" — those specific
# trees, not all-of-/var/.
_DENIED_PATH_PREFIXES = (
    "/etc/",      "/private/etc/",            # /etc/shadow etc.
    "/proc/",                                 # Linux kernel surface
    "/sys/",                                  # Linux sysfs
    "/dev/",                                  # device nodes
    "/boot/",                                 # bootloader / kernel images
    "/root/",                                 # root's home
    "/var/log/",  "/private/var/log/",        # system logs
    "/var/db/",   "/private/var/db/",         # mac system db (TCC, etc.)
    "/var/lib/",                              # Linux service state
)


def _default_allow_roots() -> List[str]:
    """The default allow-list applied when the caller passes ``None``
    or ``[]``: the current working directory, the user's home
    directory, and the OS temp directory.

    The temp dir is included so quick dev experiments
    (``echo … > /tmp/scratch && agent Read /tmp/scratch``) still
    work, and so test fixtures created via ``tempfile`` /
    ``pytest tmp_path`` are scannable.
    """
    import tempfile
    roots = [os.getcwd(), str(Path.home()), tempfile.gettempdir(), "/tmp"]
    # Deduplicate after realpath so /tmp == /private/tmp on macOS
    # collapses to one entry — keeps the per-call loop short.
    seen: set = set()
    out: List[str] = []
    for r in roots:
        try:
            rp = os.path.realpath(r)
        except OSError:
            continue
        if rp in seen:
            continue
        seen.add(rp)
        out.append(rp)
    return out


def _path_is_allowed(resolved: str, allow_roots: Optional[List[str]]) -> bool:
    """Return True if ``resolved`` (already absolute, symlink-resolved)
    is inside at least one allow-root and not under a denied prefix.

    The principle: "the agent can scan files the developer would
    normally edit (their cwd / home / tmp); it cannot turn the guard
    into a reader for /etc/shadow, /proc/self/environ, or another
    user's home". Deny-prefix list takes precedence over allow-roots.
    """
    for denied in _DENIED_PATH_PREFIXES:
        if resolved == denied.rstrip("/") or resolved.startswith(denied):
            return False
    roots = list(allow_roots or [])
    if not roots:
        roots = _default_allow_roots()
    for root in roots:
        try:
            root_abs = os.path.realpath(root)
        except OSError:
            continue
        # commonpath raises on different drives / mismatched roots —
        # treat that as "no match" and try the next allow-root.
        try:
            common = os.path.commonpath([resolved, root_abs])
        except ValueError:
            continue
        if common == root_abs:
            return True
    return False


def augment_with_file_content(
    payload: Payload,
    *,
    max_scan_bytes: int,
    skip_binary: bool = True,
    cache_enabled: bool = True,
    cache_ttl_seconds: int = 3600,
    cache_max_entries: int = 2000,
    allow_roots: Optional[List[str]] = None,
) -> List[FileScanResult]:
    """Populate ``payload.files[].content`` for any file in the payload
    whose content is empty AND that exists on disk. Mutates ``payload``
    in place; returns a list of :class:`FileScanResult` for telemetry.

    The cache module is consulted first so unchanged files re-scanned
    in quick succession don't burn I/O. On a cache HIT for a clean
    file we leave the entry alone (the inspector finds nothing on an
    empty content string). On a cache HIT for a dirty file the caller
    is expected to replay ``result.cached_findings`` through the
    policy engine — that path is also content-free.

    Cache writes happen in :func:`record_scan_in_cache` (below) once
    the caller has the finding list — split out so this function stays
    purely about content augmentation and is easy to test in isolation.
    """
    # Late import to avoid a circular import (cache → inspector.types).
    from cloudanix_guard.inspector import file_content_cache as cache

    results: List[FileScanResult] = []

    for entry in payload.files:
        path = entry.get("path") or ""
        if not path or entry.get("content"):
            # Either no path, or the agent already supplied content
            # (Write / Edit / apply_patch case).
            continue

        # Refuse symlinks BEFORE the cache lookup. A symlink to
        # /etc/shadow that was cached as "clean" last week would
        # otherwise short-circuit to allow on a re-read; we want the
        # symlink refusal to be the load-bearing signal regardless
        # of cache state.
        try:
            lst = os.lstat(path)
            if stat.S_ISLNK(lst.st_mode):
                results.append(
                    FileScanResult(path=path, status="skipped_symlink")
                )
                continue
        except OSError:
            results.append(FileScanResult(path=path, status="skipped_missing"))
            continue

        # Resolve symlinks in any ancestor directory (the file itself
        # is not a symlink, we just checked) so the cache key is
        # canonical. Two different paths that point at the same file
        # share one cache entry.
        try:
            resolved = os.path.realpath(path)
        except OSError:
            results.append(FileScanResult(path=path, status="skipped_missing"))
            continue

        # Path-allowlist check. Default: cwd-ancestry + $HOME. Deny:
        # /etc/, /proc/, /sys/, /var/, /dev/, /private/etc/, etc.
        # This keeps the guard from turning into an exfil oracle for
        # an attacker-controlled MCP server / untrusted agent.
        if not _path_is_allowed(resolved, allow_roots):
            results.append(
                FileScanResult(path=path, status="skipped_denied_root")
            )
            continue

        # Cache lookup keyed on the resolved path.
        if cache_enabled:
            cached = cache.lookup(resolved, ttl_seconds=cache_ttl_seconds)
            if cached is not None:
                if cached.has_findings:
                    results.append(
                        FileScanResult(
                            path=path,
                            status="cached_dirty",
                            bytes_scanned=0,
                            mtime=cached.mtime,
                            size=cached.size,
                            cached_findings=cached.replay_findings(source=path),
                        )
                    )
                else:
                    results.append(
                        FileScanResult(
                            path=path,
                            status="cached_clean",
                            bytes_scanned=0,
                            mtime=cached.mtime,
                            size=cached.size,
                        )
                    )
                continue

        # Symlink-safe open: O_NOFOLLOW refuses to open a symlink we
        # somehow didn't catch above (TOCTOU race between lstat and
        # open). fstat after the fd is the only stat we trust.
        try:
            flags = os.O_RDONLY
            if hasattr(os, "O_NOFOLLOW"):
                flags |= os.O_NOFOLLOW
            fd = os.open(resolved, flags)
        except OSError as e:
            # ELOOP from O_NOFOLLOW maps to "skipped_symlink"; other
            # OSError (ENOENT after the realpath, EACCES) → missing.
            err = getattr(e, "errno", 0)
            import errno
            if err == errno.ELOOP:
                results.append(FileScanResult(path=path, status="skipped_symlink"))
            else:
                results.append(FileScanResult(path=path, status="skipped_missing"))
            continue

        try:
            try:
                st = os.fstat(fd)
            except OSError:
                results.append(FileScanResult(path=path, status="skipped_missing"))
                continue

            # Regular files only. Pipes, sockets, devices all skipped
            # — they'd either block forever, return endless data, or
            # crash the scanner.
            if not stat.S_ISREG(st.st_mode):
                results.append(
                    FileScanResult(path=path, status="skipped_missing")
                )
                continue

            if max_scan_bytes > 0 and st.st_size > max_scan_bytes:
                results.append(
                    FileScanResult(
                        path=path,
                        status="skipped_too_large",
                        mtime=st.st_mtime,
                        size=st.st_size,
                    )
                )
                continue

            try:
                with os.fdopen(fd, "rb") as fh:
                    # fd is now owned by fh; null it so the outer
                    # finally doesn't double-close.
                    fd = -1
                    head = fh.read(_BINARY_PROBE_BYTES)
                    if skip_binary and _looks_binary(head):
                        results.append(
                            FileScanResult(
                                path=path,
                                status="skipped_binary",
                                mtime=st.st_mtime,
                                size=st.st_size,
                            )
                        )
                        continue
                    remainder = b""
                    if max_scan_bytes > _BINARY_PROBE_BYTES:
                        remainder = fh.read(max_scan_bytes - len(head))
                    raw = head + remainder
            except OSError:
                results.append(FileScanResult(path=path, status="skipped_missing"))
                continue

            text = raw.decode("utf-8", errors="replace")

            entry["content"] = text
            results.append(
                FileScanResult(
                    path=resolved,
                    status="scanned",
                    bytes_scanned=len(raw),
                    mtime=st.st_mtime,
                    size=st.st_size,
                )
            )
        finally:
            if fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass

    return results


def record_scan_in_cache(
    results: List[FileScanResult],
    findings_by_source: Dict[str, list],
    *,
    cache_enabled: bool,
    cache_ttl_seconds: int,
    cache_max_entries: int,
) -> None:
    """Persist scan outcomes back to the cache after the inspector +
    policy chain ran. Only ``scanned`` results get written — cache
    hits already have an up-to-date entry, and skipped results
    intentionally don't get cached (we want to re-evaluate them next
    time in case the file appears / shrinks / the policy changes
    ``skip_binary``)."""
    if not cache_enabled:
        return
    # Late import — same circular reason as augment_with_file_content.
    from cloudanix_guard.inspector import file_content_cache as cache

    for r in results:
        if r.status != "scanned":
            continue
        if r.mtime is None or r.size is None:
            continue
        path_findings = findings_by_source.get(r.path, [])
        cache.store(
            r.path,
            mtime=r.mtime,
            size=r.size,
            has_findings=bool(path_findings),
            findings=path_findings,
            ttl_seconds=cache_ttl_seconds,
            max_entries=cache_max_entries,
        )
