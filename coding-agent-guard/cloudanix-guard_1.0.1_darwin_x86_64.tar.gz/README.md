# cloudanix-coding-agent-guard (Go)

> **Status:** scaffolding (2026-06-10). Strict 1:1 parity target with the
> Python implementation at v0.1.1 (see
> [`Cloudanix/cloudanix-coding-agent-guard`](https://github.com/Cloudanix/cloudanix-coding-agent-guard)).
> First release will tag **v1.0.0** when parity validation passes.

On-device firewall for coding agents (Claude Code, OpenAI Codex CLI,
Kiro). Inspects every prompt and every tool call for secrets, PII, and
sensitive files **before** anything leaves the developer's machine.
Decides **allow / redact / block** per a local policy synced from the
Cloudanix Console.

This Go rewrite preserves the same wire protocol, the same policy YAML
shape, the same NF-PRIV-1 privacy contract, and the same CLI surface as
the Python implementation. Customers using the Python `cloudanix-guard`
binary can drop in the Go binary at the same path with no
configuration change.

## Why Go (vs the Python at v0.1.1)

- **Single static binary, no Python runtime.** Customer install collapses
  to `curl -o cloudanix-guard …; chmod +x`. No venv, no `pip install`,
  no "Python 3.9+ on PATH" requirement.
- **Hook latency ~10 ms cold-start** vs 100–300 ms for Python. Hooks fire
  on every UserPromptSubmit and every PreToolUse — this is on the agent
  user's interactive critical path.
- **Cross-platform signing/notarization** trivial (Apple, Microsoft).
- **goreleaser-based release pipeline** with multi-arch builds, archived
  in `Cloudanix/artifacts/coding-agent-guard/` (same channel as the
  Python wheel today).

See [`PORTING.md`](https://github.com/Cloudanix/cloudanix-coding-agent-guard/blob/main/PORTING.md)
in the existing Python repo (TBD) for the module-by-module porting plan
and parity-validation strategy.

## Quick start (dev)

```bash
make build           # produces ./cloudanix-guard
make test            # unit tests with race detector
make lint            # golangci-lint
make smoke           # end-to-end smoke against a fixture corpus (TBD)
./cloudanix-guard --version
```

## Project layout

```
cmd/cloudanix-guard/    binary entry point
internal/
  cli/                  argument parsing + subcommand dispatch
  config/               ~/.cloudanix-guard/config.yaml read/write
  policy/               6-mode enforcement engine
  enforce/              apply(payload, decision); NF-PRIV-1 scrub on block
  inspector/            secret / PII / file scanners (regex-only in v1)
  hook/                 stdin JSON → Payload normalisation
  install/              Claude/Kiro/Codex hook wiring
  telemetry/            spool + flush + backoff
  sync/                 policy pull from console + heartbeat
  state/                pause / resume + audit log
  exceptions/           grant / revoke / find_active_for_rule
  directive/            cloudanix:allow parser
  buildinfo/            version + commit SHA (set via goreleaser ldflags)
```

## What changes vs Python v0.1.1

- **Presidio (NER-based PII detection) is dropped for v1.** Regex-based
  PII detection (the default) is preserved 1:1. NER will return as a
  separate workstream in v1.1+.
- Everything else is intended to be behaviourally identical.

## License

Proprietary. See [LICENSE](LICENSE).
