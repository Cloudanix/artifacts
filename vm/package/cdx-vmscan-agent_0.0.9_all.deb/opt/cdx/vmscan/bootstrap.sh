#!/bin/bash
# CDX VM Scan Agent bootstrap.
#
# Installs and configures the Wazuh-based VM security scanning agent. Run once
# by cdx-vmscan-bootstrap.service after the package is installed, or by
# hand for testing.
#
# Parameter precedence: CLI flag > environment variable > config file > default.

set -o errexit
set -o nounset
set -o pipefail
if [[ "${TRACE-0}" == "1" ]]; then
    set -o xtrace
fi

CDX_VMSCAN_HOME="${CDX_VMSCAN_HOME:-/opt/cdx/vmscan}"
CDX_VMSCAN_CONF="${CDX_VMSCAN_CONF:-/etc/cdx/vmscan.conf}"
SENTINEL_FILE="$CDX_VMSCAN_HOME/.bootstrap-done"

usage() {
    cat <<'EOF'
Usage: bootstrap.sh [--server_ip <ip>] [--agent_key <key>] [--cdx_auth_key <key>]
                    [--agent_version <ver>] [--vulnerabilities <true|false>]
                    [--ami_integration <true|false>]

Installs the CDX VM Security Scanning agent.
Values come from (highest first): CLI flags, environment variables,
/etc/cdx/vmscan.conf, built-in defaults.

  --server_ip        Wazuh manager IP (required with --agent_key)
  --agent_key        Base64 agent key (optional; fetched via the platform API if omitted)
  --cdx_auth_key     Base64 JSON with cdx_dc, cdx_token, cdx_service_account, server
                     (required when --agent_key is not provided)
  --agent_version    Ignored. The Wazuh agent version is fixed by this package
  --vulnerabilities  Package inventory / vulnerability detection (default: true)
  --ami_integration  Install the re-registration cron for AMI images (default: false)
EOF
}

if [[ "${1-}" =~ ^-*h(elp)?$ ]]; then
    usage
    exit 0
fi

# shellcheck source=lib/common.sh
source "$CDX_VMSCAN_HOME/lib/common.sh"
# shellcheck source=lib/cloud.sh
source "$CDX_VMSCAN_HOME/lib/cloud.sh"
# shellcheck source=lib/keyfetch.sh
source "$CDX_VMSCAN_HOME/lib/keyfetch.sh"
# shellcheck source=lib/configure.sh
source "$CDX_VMSCAN_HOME/lib/configure.sh"
# shellcheck source=lib/healthcheck.sh
source "$CDX_VMSCAN_HOME/lib/healthcheck.sh"

# ---------------------------------------------------------------------------
# Parameter resolution: env > config file, then CLI on top, then defaults.
# ---------------------------------------------------------------------------
CONFIG_KEYS=(SERVER_IP AGENT_KEY CDX_AUTH_KEY AGENT_VERSION VULNERABILITIES AMI_INTEGRATION RELEASE_VERSION)

declare -A ENV_OVERRIDES=()
for key in "${CONFIG_KEYS[@]}"; do
    if [[ -n "${!key-}" ]]; then
        ENV_OVERRIDES[$key]="${!key}"
    fi
    unset "$key"
done

if [[ -f "$CDX_VMSCAN_CONF" ]]; then
    conf_mode=$(stat -c '%a' "$CDX_VMSCAN_CONF" 2>/dev/null || echo "")
    if [[ -n "$conf_mode" && "$conf_mode" != "600" && "$conf_mode" != "400" ]]; then
        # It holds credentials and is sourced as shell, so tighten it before use.
        if chmod 600 "$CDX_VMSCAN_CONF" 2>/dev/null; then
            log "WARNING" "$CDX_VMSCAN_CONF had mode $conf_mode; changed it to 0600 because it holds credentials."
        else
            log "WARNING" "$CDX_VMSCAN_CONF has mode $conf_mode; it holds credentials and should be 0600 (could not change it)."
        fi
    fi
    # shellcheck disable=SC1090
    source "$CDX_VMSCAN_CONF"
else
    log "WARNING" "Config file $CDX_VMSCAN_CONF not found; relying on environment and CLI flags."
fi

for key in "${!ENV_OVERRIDES[@]}"; do
    printf -v "$key" '%s' "${ENV_OVERRIDES[$key]}"
done

require_value() {
    if [[ -z "${2:-}" || "$2" == --* ]]; then
        log "ERROR" "$1 requires a value"
        usage
        exit 1
    fi
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --server_ip)        require_value "$1" "${2:-}"; SERVER_IP="$2"; shift 2 ;;
        --agent_key)        require_value "$1" "${2:-}"; AGENT_KEY="$2"; shift 2 ;;
        --cdx_auth_key)     require_value "$1" "${2:-}"; CDX_AUTH_KEY="$2"; shift 2 ;;
        --agent_version)    require_value "$1" "${2:-}"; AGENT_VERSION="$2"; shift 2 ;;
        --vulnerabilities)  require_value "$1" "${2:-}"; VULNERABILITIES="$2"; shift 2 ;;
        --ami_integration)  require_value "$1" "${2:-}"; AMI_INTEGRATION="$2"; shift 2 ;;
        --ids)
            log "WARNING" "--ids is not supported by this package and is ignored."
            shift
            if [[ "${1:-}" == "true" || "${1:-}" == "false" ]]; then shift; fi
            ;;
        --help) usage; exit 0 ;;
        *) log "ERROR" "Unknown option: $1"; usage; exit 1 ;;
    esac
done

# Defaults for anything still unset.
: "${SERVER_IP:=}"
: "${AGENT_KEY:=}"
: "${CDX_AUTH_KEY:=}"
: "${AGENT_VERSION:=}"
: "${VULNERABILITIES:=true}"
: "${AMI_INTEGRATION:=false}"
: "${RELEASE_VERSION:=0.0.1}"

# The Wazuh agent is bundled in the package, so its version is fixed. Report the
# bundled version (used in logs and healthchecks) and ignore a different request.
if [[ ! -f "$WAZUH_DEB" ]]; then
    die "This package has no Wazuh agent for architecture '$HOST_ARCH' (supported: amd64, arm64)."
fi
BUNDLED_VERSION=$(dpkg-deb -f "$WAZUH_DEB" Version)
if [[ -n "$AGENT_VERSION" && "$BUNDLED_VERSION" != "$AGENT_VERSION"* ]]; then
    log "WARNING" "AGENT_VERSION=$AGENT_VERSION is ignored: this package installs Wazuh agent $BUNDLED_VERSION."
fi
AGENT_VERSION="${BUNDLED_VERSION%%-*}"

# Validate inputs before touching the system.
if [[ -z "$AGENT_KEY" && -z "$CDX_AUTH_KEY" ]]; then
    log "ERROR" "Either AGENT_KEY or CDX_AUTH_KEY is required (set it in $CDX_VMSCAN_CONF, the environment, or via CLI)."
    usage
    exit 1
fi
if [[ -n "$AGENT_KEY" && -z "$SERVER_IP" ]]; then
    log "ERROR" "SERVER_IP is required when AGENT_KEY is provided."
    usage
    exit 1
fi

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=l
export HOME="${HOME:-/root}"

if [[ "$(id -u)" -ne 0 ]]; then
    die "bootstrap.sh must run as root."
fi

# ---------------------------------------------------------------------------
# Execution flow
# ---------------------------------------------------------------------------
detect_package_manager
check_existing_wazuh

# Resolve the agent key (provided, or fetched from the platform API).
DC=""
CDX_TOKEN=""
CDX_SERVICE_ACCOUNT=""
if [[ -z "$AGENT_KEY" ]]; then
    fetch_agent_key
fi
decode_agent_key

log "DEBUG" "Cloud Type: $CLOUD_TYPE"
log "DEBUG" "Server Ip: $SERVER_IP"
log "DEBUG" "Agent Version: $AGENT_VERSION"
log "DEBUG" "Workspace: $WORKSPACE"
log "DEBUG" "Package Manager: $PACKAGE_MANAGER"

# Resolve VM identity (skip if auto-registration already did).
if [[ -z "${AGENT_NAME:-}" ]]; then
    get_agent_name
fi
detect_vm_details

if [[ -z "${AGENT_NAME:-}" ]]; then
    die "Invalid Agent name. Canceled Agent Installation"
fi

# The agent key is bound to one VM.
if [[ "$INSTANCE_ID" != "$AGENT_NAME" ]]; then
    die "This agent key was generated for a different VM. Please ensure you are running it on the correct virtual machine. Canceled Agent Installation"
fi
log "DEBUG" "Agent Name: $AGENT_NAME"

# Report failures to the platform if anything below exits non-zero.
INSTALLATION_COMPLETED=false
on_exit() {
    local rc=$?
    if [[ "$INSTALLATION_COMPLETED" == "false" && $rc -ne 0 ]]; then
        log "DEBUG" "Installation failed with exit code: $rc"
        send_healthcheck "failure" \
            "Agent installation did not complete successfully" \
            "Script exited with code $rc" \
            "$rc"
    fi
}
trap on_exit EXIT

# Everything that can fail on bad input is checked above (key, VM identity) or
# here (manager port) before the existing CDX-managed agent is removed, so a
# bad key or an unreachable manager on an upgrade leaves the working agent.
log "DEBUG" "checking server connectivity"
check_port 1514
remove_existing_wazuh

log "DEBUG" "Installing Agent"
install_agent
log "DEBUG" "Agent Installation Successful!"

configure_resource_limits

# Registration cron is only for AMI images and needs CDX credentials.
if [[ "$AMI_INTEGRATION" == "true" ]]; then
    if [[ -z "$CDX_TOKEN" || -z "$CDX_SERVICE_ACCOUNT" || -z "$DC" ]]; then
        log "WARNING" "AMI integration requested but CDX credentials are unavailable (set CDX_AUTH_KEY). Skipping registration cron setup."
    else
        log "DEBUG" "AMI integration enabled - setting up agent registration cron"
        setup_registration_cron
    fi
fi

INSTALLATION_COMPLETED=true
send_healthcheck "success"
log "DEBUG" "Healthcheck sent successfully"

# Mark first-boot bootstrap as done so the systemd unit does not run again.
touch "$SENTINEL_FILE"
