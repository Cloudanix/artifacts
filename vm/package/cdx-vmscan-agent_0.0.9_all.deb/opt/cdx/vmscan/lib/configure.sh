#!/bin/bash
# shellcheck disable=SC2034,SC2153,SC1091
# Wazuh agent pre-flight, installation and configuration (apt-based hosts).
# Sourced by bootstrap.sh; not meant to be executed directly.

MONITOR_SRC_DIR="${CDX_VMSCAN_HOME:-/opt/cdx/vmscan}/monitor"
MONITOR_DIR="$OSSEC_HOME/monitor"

# True if the dpkg package $1 is installed.
pkg_installed() {
    local state
    state=$(dpkg-query -W -f='${Status}' "$1" 2>/dev/null || true)
    [[ "$state" == "install ok installed" ]]
}

# --- Pre-flight check ---
# Refuse to run next to a Wazuh manager, and mark (only) a Wazuh agent that was
# previously installed by CDX for replacement. A foreign agent is never
# overwritten. This only checks: nothing is removed here, so a bad key or an
# unreachable manager found later leaves the working agent in place. The
# removal is remove_existing_wazuh, called once everything else is validated.
WAZUH_REPLACE=false
check_existing_wazuh() {
    WAZUH_REPLACE=false
    if pkg_installed wazuh-manager; then
        die "Cannot install an agent on a node that already runs the Wazuh manager. Exiting."
    fi

    if pkg_installed wazuh-agent; then
        log "INFO" "Wazuh agent is already installed on this host."
        if [[ -f "$WAZUH_OWNED_MARKER" ]]; then
            # An earlier run installed it and died before the labels were written.
            log "INFO" "Wazuh agent was installed by an earlier CDX bootstrap run (ownership marker found). Replacing it."
        elif [[ ! -f "$OSSEC_CONFIG_FILE" ]]; then
            die "Wazuh agent is installed but $OSSEC_CONFIG_FILE was not found. Cannot verify CDX ownership. Exiting."
        elif grep -q 'key="account_id"' "$OSSEC_CONFIG_FILE" \
            || grep -q 'key="cloud_type"' "$OSSEC_CONFIG_FILE" \
            || grep -q 'key="agent_unique_id"' "$OSSEC_CONFIG_FILE"; then
            log "INFO" "Wazuh agent was installed by CDX (CDX label keys found). Replacing it."
        else
            die "Wazuh agent is installed but has no CDX label keys in $OSSEC_CONFIG_FILE and no CDX ownership marker. Refusing to overwrite a non-CDX installation. Exiting."
        fi
        WAZUH_REPLACE=true
    fi
}

# Remove the CDX-managed agent that check_existing_wazuh marked. Call it only
# after the key, the VM identity and the manager connection have been checked.
remove_existing_wazuh() {
    if [[ "$WAZUH_REPLACE" == "true" ]]; then
        log "INFO" "Removing the existing CDX-managed Wazuh agent."
        apt_get remove --purge -y wazuh-agent
        svc_daemon_reload
        WAZUH_REPLACE=false
    fi
}

# --- Agent configuration ---

configure_agent() {
    local new_block
    new_block=$(cat <<EOF
<ossec_config>
  <labels>
    <label key="cloud_type">$CLOUD_TYPE</label>
    <label key="account_id">$ACCOUNT_ID</label>
    <label key="agent_unique_id">$AGENT_UNIQUE_ID</label>
    <label key="account_identifier">$ACCOUNT_IDENTIFIER</label>
    <label key="workspace">$WORKSPACE</label>
    <label key="dc">$DC</label>
    <label key="os">$VM_OS</label>
    <label key="os_version">$VM_OS_VERSION</label>
    <label key="architecture">$VM_ARCHITECTURE</label>
    <label key="package_manager">$VM_PACKAGE_MANAGER</label>
    <label key="release_version">$RELEASE_VERSION</label>
  </labels>
</ossec_config>

<!--auditd-->
<ossec_config>
  <localfile>
  <log_format>syslog</log_format>
  <location>/var/log/audit/audit.log</location>
  </localfile>
</ossec_config>
EOF
    )
    printf "\n%s" "$new_block" >> "$OSSEC_CONFIG_FILE"

    # Disable package inventory (vulnerability detection) if requested.
    if [[ "$VULNERABILITIES" == "false" ]]; then
        sed -i 's|<packages>yes</packages>|<packages>no</packages>|g' "$OSSEC_CONFIG_FILE"
    fi
}

add_auditd_rule() {
    cat > /etc/audit/rules.d/net_connect.rules <<'EOF'
-a always,exit -F arch=b64 -S connect -k net_connect
EOF
    # Not fatal: hardened hosts (e.g. CIS, `-e 2` in 99-finalize.rules) keep the
    # audit configuration immutable, so loading rules fails until a reboot.
    if ! augenrules --load; then
        log "WARNING" "Audit rules could not be loaded (immutable audit configuration?). The rule is saved in /etc/audit/rules.d and takes effect after a reboot."
    fi
}

# Enable whodata FIM on the default directories and reload auditd rules.
configure_auditd_fim() {
    add_auditd_rule
    svc_restart auditd || log "WARNING" "auditd could not be restarted (immutable audit configuration?). Continuing."
    sed -i 's|<directories>/etc,/usr/bin,/usr/sbin</directories>|<directories check_all="yes" whodata="yes">/etc,/usr/bin,/usr/sbin</directories>|' "$OSSEC_CONFIG_FILE"
    sed -i 's|<directories>/bin,/sbin,/boot</directories>|<directories check_all="yes" whodata="yes">/bin,/sbin,/boot</directories>|' "$OSSEC_CONFIG_FILE"
}

# --- Installation ---

# The Wazuh agent .deb is bundled in this package (see fetch-wazuh.sh), so the
# install needs no Wazuh repository, signing key or internet access. Its
# dependencies are declared in this package's own Depends.
install_agent() {
    [[ -f "$WAZUH_DEB" ]] || die "Bundled Wazuh agent package not found: $WAZUH_DEB"
    # Record ownership before the agent exists, so a run that dies before the
    # labels are written can still be recovered by the next boot.
    mkdir -p "$CDX_STATE_DIR"
    : > "$WAZUH_OWNED_MARKER"
    log "DEBUG" "Installing bundled Wazuh agent $(dpkg-deb -f "$WAZUH_DEB" Version)"
    # The Wazuh postinst reads these to set the manager address and agent name.
    WAZUH_MANAGER="$SERVER_IP" WAZUH_AGENT_NAME="$AGENT_NAME" \
        dpkg_install "$WAZUH_DEB"
    echo "y" | "$OSSEC_HOME/bin/manage_agents" -i "$REGISTRATION_KEY"
    log "DEBUG" "Wazuh Agent Installation completed"

    configure_agent

    svc_daemon_reload
    svc_enable wazuh-agent
    svc_start wazuh-agent
    svc_restart wazuh-agent
    log "DEBUG" "Wazuh Post-Installation steps completed"

    # auditd + audispd-plugins are package dependencies.
    configure_auditd_fim
    svc_restart wazuh-agent
    log "DEBUG" "Wazuh User data setup completed"
}

# Cap the wazuh-agent service: CPU up to 20% of each core, memory up to 20% of RAM.
configure_resource_limits() {
    if ! has_systemd; then
        log "WARNING" "Skipping agent resource limits: no systemd on this host. Agent runs unthrottled."
        return 0
    fi

    local cpu_cores mem_max_bytes cpu_quota
    cpu_cores=$(nproc)
    mem_max_bytes=$(awk '/MemTotal/ {printf "%.0f", $2*1024*0.20}' /proc/meminfo)
    cpu_quota=$((cpu_cores * 20))

    mkdir -p /etc/systemd/system/wazuh-agent.service.d
    printf '[Service]\nCPUQuota=%s%%\nMemoryMax=%s\n' "$cpu_quota" "$mem_max_bytes" \
        > /etc/systemd/system/wazuh-agent.service.d/resource-limit.conf

    svc_daemon_reload
    svc_restart wazuh-agent
    log "DEBUG" "Applied resource limits to agent (CPUQuota=${cpu_quota}%, MemoryMax=${mem_max_bytes} bytes)"
}

# Install the bundled registration helper and schedule it every 30 minutes.
# It re-registers the agent if the VM identity drifts (e.g. cloning/re-imaging).
setup_registration_cron() {
    local cron_job="*/30 * * * * $MONITOR_DIR/linux-agent-registration.sh"
    local auth_file="$MONITOR_DIR/.cdx_auth"

    mkdir -p "$MONITOR_DIR"

    # CDX credentials go to a root-only file, NOT into Wazuh <labels>, which are
    # sent to the manager and appear in alert payloads.
    (
        umask 077
        cat > "$auth_file" <<EOF
CDX_DC="$DC"
CDX_TOKEN="$CDX_TOKEN"
CDX_SERVICE_ACCOUNT="$CDX_SERVICE_ACCOUNT"
EOF
    )
    chmod 600 "$auth_file"
    chown root:root "$auth_file" 2>/dev/null || true

    install -m 0750 "$MONITOR_SRC_DIR/linux-agent-registration.sh" "$MONITOR_DIR/linux-agent-registration.sh"

    # cron is a package dependency; make sure it is enabled and running.
    if ! svc_is_enabled cron; then
        log "DEBUG" "The cron service is not enabled. Enabling it."
        svc_enable cron
        svc_start cron
        sleep 5
    fi

    if crontab -l 2>/dev/null | grep -qF "$cron_job"; then
        log "DEBUG" "The registration cron job is already set up."
        return 0
    fi

    log "DEBUG" "Adding the registration cron job (every 30 minutes)..."
    (crontab -l 2>/dev/null; echo "$cron_job") | crontab -
    if ! crontab -l 2>/dev/null | grep -qF "$cron_job"; then
        sleep 5
        (crontab -l 2>/dev/null; echo "$cron_job") | crontab -
    fi
    if crontab -l 2>/dev/null | grep -qF "$cron_job"; then
        log "DEBUG" "The registration cron job has been added successfully."
    else
        log "ERROR" "Failed to add the registration cron job."
    fi
}
