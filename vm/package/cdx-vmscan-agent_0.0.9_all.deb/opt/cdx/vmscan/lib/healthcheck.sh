#!/bin/bash
# shellcheck disable=SC2034,SC2153,SC1091
# Healthcheck reporting to the CDX platform.
# Sourced by bootstrap.sh; not meant to be executed directly.

# send_healthcheck <success|failure> [error_message] [raw_error_message] [error_code]
send_healthcheck() {
    local status="$1"
    local error_message="${2:-}"
    local raw_error_message="${3:-}"
    local error_code="${4:-}"
    local url vm_details agent_entry payload timestamp response

    # Without a DC/token (e.g. direct AGENT_KEY install) fall back to US / no auth,
    # matching the original script's behaviour.
    url=$(dc_url "$HEALTHCHECK_API_URL_US" "$HEALTHCHECK_API_URL_OTHER" "${DC:-US}")

    vm_details=$(cat <<VMEOF
{
      "os": "${VM_OS:-Unknown}",
      "osVersion": "${VM_OS_VERSION:-Unknown}",
      "architecture": "${VM_ARCHITECTURE:-Unknown}",
      "packageManager": "${VM_PACKAGE_MANAGER:-Unknown}",
      "cloud": "${CLOUD_TYPE:-Unknown}"
    }
VMEOF
    )

    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%S.%6N+00:00" 2>/dev/null || date -u +"%Y-%m-%dT%H:%M:%S+00:00")

    if [[ "$status" == "success" ]]; then
        agent_entry=$(cat <<JSONEOF
{
        "agent_name": "${AGENT_NAME:-}",
        "agent_unique_id": "${AGENT_UNIQUE_ID:-}",
        "account_id": "${ACCOUNT_IDENTIFIER:-}",
        "logsUrl": "",
        "vmDetails": $vm_details,
        "wazuhAgentInstallation": "success",
        "cdxManagerAgentInstallation": "success",
        "serverVersion": "${AGENT_VERSION:-}",
        "agentVersion": "${AGENT_VERSION:-}"
      }
JSONEOF
        )
        payload="{\"request\":{\"active_agents\":[$agent_entry],\"failed_agents\":[]}}"
    else
        agent_entry=$(cat <<JSONEOF
{
        "agent_name": "${AGENT_NAME:-}",
        "agent_unique_id": "${AGENT_UNIQUE_ID:-}",
        "account_id": "${ACCOUNT_IDENTIFIER:-}",
        "logsUrl": "",
        "vmDetails": $vm_details,
        "wazuhAgentInstallation": "failure",
        "cdxManagerAgentInstallation": "failure",
        "errorMessage": "${error_message:-Agent installation failed}",
        "rawErrorMessage": "${raw_error_message:-}",
        "errorCode": ${error_code:-500},
        "errorTimestamp": "$timestamp",
        "agentVersion": "${AGENT_VERSION:-}"
      }
JSONEOF
        )
        payload="{\"request\":{\"active_agents\":[],\"failed_agents\":[$agent_entry]}}"
    fi

    log "DEBUG" "Sending healthcheck to $url (status: $status)"
    response=$(curl -s -m 30 -X POST "$url" \
        -H "Content-Type: application/json" \
        -H "Accept: application/json" \
        -H "Authorization: Bearer ${CDX_TOKEN:-}" \
        -d "$payload" 2>/dev/null || true)

    if [[ -n "$response" ]]; then
        log "DEBUG" "Healthcheck API response: $response"
    else
        log "WARNING" "Healthcheck API call failed or returned empty response"
    fi
}
