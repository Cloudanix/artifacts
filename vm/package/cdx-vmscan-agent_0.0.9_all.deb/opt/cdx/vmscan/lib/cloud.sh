#!/bin/bash
# shellcheck disable=SC2034,SC2153,SC1091
# Cloud provider detection and VM identity resolution.
# Sourced by bootstrap.sh; not meant to be executed directly.

detect_cloud_type() {
    local cloud_type="" token check

    # AWS: IMDSv2 (token) first, then IMDSv1. Validate the "i-" prefix because
    # OCI serves metadata from the same 169.254.169.254 address.
    token=$(curl -s -m 2 -X PUT "http://169.254.169.254/latest/api/token" \
        -H "X-aws-ec2-metadata-token-ttl-seconds: 21600" 2>/dev/null || true)
    if [[ -n "$token" ]]; then
        check=$(curl -s -m 2 -H "X-aws-ec2-metadata-token: $token" \
            "http://169.254.169.254/latest/meta-data/instance-id" 2>/dev/null || true)
        [[ "$check" == i-* ]] && cloud_type="AWS"
    fi
    if [[ -z "$cloud_type" ]]; then
        check=$(curl -s -m 2 "http://169.254.169.254/latest/meta-data/instance-id" 2>/dev/null || true)
        [[ "$check" == i-* ]] && cloud_type="AWS"
    fi

    # GCP: unique hostname + required header; id is numeric.
    if [[ -z "$cloud_type" ]]; then
        check=$(curl -s -m 2 -H "Metadata-Flavor: Google" \
            "http://metadata.google.internal/computeMetadata/v1/instance/id" 2>/dev/null || true)
        [[ "$check" =~ ^[0-9]+$ ]] && cloud_type="GCP"
    fi

    # Azure: vmId is a bare GUID (validate shape, OCI returns a 404 page here).
    if [[ -z "$cloud_type" ]]; then
        check=$(curl -s -m 2 -H "Metadata:true" \
            "http://169.254.169.254/metadata/instance/compute/vmId?api-version=2021-08-01&format=text" 2>/dev/null || true)
        if [[ "$check" =~ ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$ ]]; then
            cloud_type="AZURE"
        fi
    fi

    # OCI: instance id is an OCID.
    if [[ -z "$cloud_type" ]]; then
        check=$(curl -s -m 2 -H "Authorization: Bearer Oracle" \
            "http://169.254.169.254/opc/v2/instance/id" 2>/dev/null || true)
        [[ "$check" == ocid1.instance.* ]] && cloud_type="OCI"
    fi

    if [[ -z "$cloud_type" ]]; then
        echo ""
        return 1
    fi
    echo "$cloud_type"
}

# Extract a string field from a JSON document on stdin using sed.
_json_field() {
    sed -n "s/.*\"$1\"[[:space:]]*:[[:space:]]*\"\\([^\"]*\\)\".*/\\1/p" | head -n 1
}

# Fetch from the AWS metadata service, using IMDSv2 if a token is available.
_aws_imds() {
    local path="$1" token
    token=$(curl -s -m 5 -X PUT "http://169.254.169.254/latest/api/token" \
        -H "X-aws-ec2-metadata-token-ttl-seconds: 21600" 2>/dev/null || true)
    if [[ -n "$token" ]]; then
        curl -s -m 5 -H "X-aws-ec2-metadata-token: $token" "http://169.254.169.254/latest/$path" || true
    else
        curl -s -m 5 "http://169.254.169.254/latest/$path" || true
    fi
}

# Resolve AGENT_NAME, ACCOUNT_ID and AGENT_UNIQUE_ID for $CLOUD_TYPE.
get_agent_name() {
    local doc region meta zone_full instance_name rg vm_name
    case "$CLOUD_TYPE" in
        AWS)
            AGENT_NAME=$(_aws_imds "meta-data/instance-id")
            doc=$(_aws_imds "dynamic/instance-identity/document")
            ACCOUNT_ID=$(echo "$doc" | _json_field accountId)
            region=$(echo "$doc" | _json_field region)
            AGENT_UNIQUE_ID="arn:aws:ec2:$region:$ACCOUNT_ID:instance/$AGENT_NAME"
            ;;
        AZURE)
            AGENT_NAME=$(curl -s -m 5 -H "Metadata:true" \
                "http://169.254.169.254/metadata/instance/compute/vmId?api-version=2021-08-01&format=text" || true)
            meta=$(curl -s -m 5 -H "Metadata:true" \
                "http://169.254.169.254/metadata/instance?api-version=2021-02-01&format=json" || true)
            ACCOUNT_ID=$(echo "$meta" | _json_field subscriptionId)
            rg=$(echo "$meta" | _json_field resourceGroupName)
            vm_name=$(echo "$meta" | _json_field name)
            AGENT_UNIQUE_ID="/subscriptions/$ACCOUNT_ID/resourceGroups/$rg/providers/Microsoft.Compute/virtualMachines/$vm_name"
            ;;
        GCP)
            local base="http://metadata.google.internal/computeMetadata/v1"
            local hdr="Metadata-Flavor: Google"
            AGENT_NAME=$(curl -s -m 5 -H "$hdr" "$base/instance/id" || true)
            ACCOUNT_ID=$(curl -s -m 5 -H "$hdr" "$base/project/project-id" || true)
            zone_full=$(curl -s -m 5 -H "$hdr" "$base/instance/zone" || true)
            instance_name=$(curl -s -m 5 -H "$hdr" "$base/instance/name" || true)
            AGENT_UNIQUE_ID="projects/$ACCOUNT_ID/zones/$(basename "$zone_full")/instances/$instance_name"
            ;;
        OCI)
            local oci="http://169.254.169.254/opc/v2"
            local oci_hdr="Authorization: Bearer Oracle"
            AGENT_NAME=$(curl -s -m 5 -H "$oci_hdr" "$oci/instance/id" || true)
            ACCOUNT_ID=$(curl -s -m 5 -H "$oci_hdr" "$oci/instance/compartmentId" || true)
            AGENT_UNIQUE_ID="$AGENT_NAME"
            ;;
        VMWARE)
            AGENT_NAME="$INSTANCE_ID"
            ACCOUNT_ID="UNKNOWN"
            AGENT_UNIQUE_ID="$AGENT_NAME"
            ;;
        *)
            die "Unknown Cloud Type: $CLOUD_TYPE. Canceled Agent Installation"
            ;;
    esac
}
