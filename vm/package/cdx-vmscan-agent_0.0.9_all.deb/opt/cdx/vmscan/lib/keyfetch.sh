#!/bin/bash
# shellcheck disable=SC2034,SC2153,SC1091
# Agent key resolution: decode CDX_AUTH_KEY, fetch the agent key from the
# platform API (auto-registration), and decode the agent key.
# Sourced by bootstrap.sh; not meant to be executed directly.

# Decode CDX_AUTH_KEY (base64 JSON) into DC, CDX_TOKEN, CDX_SERVICE_ACCOUNT,
# SERVER_IP (if not already set) and RELEASE_VERSION (if present).
decode_cdx_auth_key() {
    local decoded release_json
    decoded=$(echo "$CDX_AUTH_KEY" | base64 -d 2>/dev/null || echo "")
    if [[ -z "$decoded" ]]; then
        die "Failed to decode CDX_AUTH_KEY. Please ensure it's a valid base64 encoded JSON string."
    fi

    DC=$(json_get "$decoded" "cdx_dc")
    CDX_TOKEN=$(json_get "$decoded" "cdx_token")
    CDX_SERVICE_ACCOUNT=$(json_get "$decoded" "cdx_service_account")
    if [[ -z "$SERVER_IP" ]]; then
        SERVER_IP=$(json_get "$decoded" "server")
    fi
    release_json=$(json_get "$decoded" "release_version")
    if [[ -n "$release_json" ]]; then
        RELEASE_VERSION="$release_json"
    fi

    [[ -n "$DC" ]] || die "Missing 'cdx_dc' in CDX_AUTH_KEY JSON."
    [[ -n "$CDX_TOKEN" ]] || die "Missing 'cdx_token' in CDX_AUTH_KEY JSON."
    [[ -n "$CDX_SERVICE_ACCOUNT" ]] || die "Missing 'cdx_service_account' in CDX_AUTH_KEY JSON."
    [[ -n "$SERVER_IP" ]] || die "Server IP not provided. Set SERVER_IP or include 'server' in CDX_AUTH_KEY JSON."
}

# Auto-registration: detect the cloud, resolve identity, and fetch AGENT_KEY.
fetch_agent_key() {
    local url resource_type response error_message retryable
    log "DEBUG" "No AGENT_KEY provided, attempting auto-registration via VM metadata..."

    decode_cdx_auth_key

    CLOUD_TYPE=$(detect_cloud_type) || true
    if [[ -z "$CLOUD_TYPE" ]]; then
        die "Unable to detect cloud provider from VM metadata. Provide AGENT_KEY or run on a supported cloud VM (AWS, GCP, Azure, OCI)."
    fi
    log "DEBUG" "Auto-detected CLOUD_TYPE: $CLOUD_TYPE"

    get_agent_name
    if [[ -z "${AGENT_NAME:-}" ]]; then
        die "Failed to resolve VM identity from metadata. Cannot auto-register."
    fi
    log "DEBUG" "Resolved AGENT_NAME: $AGENT_NAME"

    url=$(dc_url "$AGENT_KEY_API_URL_US" "$AGENT_KEY_API_URL_OTHER" "$DC")
    resource_type="${RESOURCE_TYPES[$CLOUD_TYPE]:-}"

    # Retry transient failures: network errors, HTTP 408/429/5xx, and the
    # backend's "asset could not be created" error seen during fleet rollouts.
    # Auth and other client errors fail at once. Worst case is about 7 minutes,
    # well inside the unit's TimeoutStartSec.
    local attempt=1 max_attempts=5 http body wait reason
    local -a delays=(10 20 40 60)
    while :; do
        # The status code is appended on its own line, so the response body
        # (it holds the agent key) never has to be written to disk.
        response=$(curl -s -m 60 --connect-timeout 15 -w $'\n%{http_code}' -X POST "$url" \
            -H "Content-Type: application/json" \
            -H "Authorization: Bearer $CDX_TOKEN" \
            -H "X-Cdx-Service-Account-Name: $CDX_SERVICE_ACCOUNT" \
            -d "{\"cloud_type\":\"$CLOUD_TYPE\",\"account_id\":\"$ACCOUNT_ID\",\"agent_unique_id\":\"$AGENT_UNIQUE_ID\",\"instance_id\":\"$AGENT_NAME\",\"dc\":\"$DC\",\"resource_type\":\"$resource_type\"}" \
            2>/dev/null || true)
        http="${response##*$'\n'}"
        body="${response%$'\n'*}"
        [[ "$response" == *$'\n'* ]] || body=""
        [[ "$http" =~ ^[0-9]{3}$ ]] || http="000"

        AGENT_KEY=$(json_get "$body" "agent_key")
        if [[ "$http" == 2?? && -n "$AGENT_KEY" ]]; then
            break
        fi
        AGENT_KEY=""

        error_message=$(json_get "$body" "errorMessage")
        if [[ "$http" == "000" ]]; then
            reason="no response from platform API, check network connectivity"
        else
            reason="${error_message:-unexpected response from platform API}"
        fi
        reason="${reason%.}"
        retryable=false
        case "$http" in
            000|408|429|5??) retryable=true ;;
        esac
        # Wording varies between backend releases ("asset could not created
        # request.", "The asset could not be created for this request."),
        # so match loosely.
        if [[ "${error_message,,}" == *asset*could*not* ]]; then
            retryable=true
        fi

        if [[ "$retryable" != "true" || $attempt -ge $max_attempts ]]; then
            die "Agent registration failed after $attempt attempt(s) (HTTP $http): $reason"
        fi
        wait=$(( ${delays[attempt - 1]:-60} + RANDOM % 6 ))
        log "WARN" "Agent registration attempt $attempt/$max_attempts failed (HTTP $http): $reason. Retrying in ${wait}s"
        sleep "$wait"
        attempt=$((attempt + 1))
    done
    log "DEBUG" "Agent key retrieved from platform API (attempt $attempt)"
}

# Decode AGENT_KEY: workspace_dc_accountidentifier_cloudtype_instanceid_wazuhKey
decode_agent_key() {
    local decoded
    local -a parts
    log "DEBUG" "Decoding AGENT_KEY to extract configuration values"
    decoded=$(echo "$AGENT_KEY" | base64 -d 2>/dev/null || echo "")
    if [[ -z "$decoded" ]]; then
        die "Failed to decode AGENT_KEY. Please ensure it's a valid base64 encoded string."
    fi

    IFS='_' read -ra parts <<< "$decoded"
    if [[ ${#parts[@]} -lt 6 ]]; then
        log "ERROR" "Invalid AGENT_KEY format. Expected: workspaceidentifier_dc_accountidentifier_cloudtype_instanceid_wazuhKey"
        die "Received ${#parts[@]} parts, expected at least 6"
    fi

    WORKSPACE="${parts[0]}"
    # DC from CDX_AUTH_KEY wins; otherwise take it from the key.
    if [[ -z "${DC:-}" ]]; then
        DC="${parts[1]}"
    fi
    ACCOUNT_IDENTIFIER="${parts[2]}"
    CLOUD_TYPE="${parts[3]:-}"
    INSTANCE_ID="${parts[4]}"
    REGISTRATION_KEY=$(echo "$decoded" | cut -d'_' -f6-)

    if [[ -z "$CLOUD_TYPE" ]]; then
        log "DEBUG" "CLOUD_TYPE not found in AGENT_KEY, detecting from VM metadata..."
        CLOUD_TYPE=$(detect_cloud_type) || true
        if [[ -z "$CLOUD_TYPE" ]]; then
            die "Unable to detect cloud provider. Ensure CLOUD_TYPE is in AGENT_KEY or run on a supported cloud VM."
        fi
        log "DEBUG" "Auto-detected CLOUD_TYPE: $CLOUD_TYPE"
    fi

    log "DEBUG" "Extracted values:"
    log "DEBUG" "  Workspace: $WORKSPACE"
    log "DEBUG" "  DC: $DC"
    log "DEBUG" "  Account Identifier: $ACCOUNT_IDENTIFIER"
    log "DEBUG" "  Cloud Type: $CLOUD_TYPE"
    log "DEBUG" "  Instance ID: $INSTANCE_ID"
}
