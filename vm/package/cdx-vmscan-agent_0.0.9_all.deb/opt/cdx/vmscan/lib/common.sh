#!/bin/bash
# shellcheck disable=SC2034,SC2153,SC1091
# Shared constants and helpers for the CDX VM scan agent bootstrap.
# Sourced by bootstrap.sh; not meant to be executed directly.

# --- Resource type constants ---
declare -A RESOURCE_TYPES=(
    [AWS]="aws-compute-ec2-instance"
    [AZURE]="azure-compute-vm-machine"
    [GCP]="gcp-compute-computeengine-instance"
    [OCI]="oci-compute-vm-instance"
)

# --- API URL constants ({DC} is replaced with the lowercase DC value) ---
AGENT_KEY_API_URL_US="https://api.cloudanix.com/inbound/vms/agent-registration"
AGENT_KEY_API_URL_OTHER="https://api-{DC}.cloudanix.com/inbound/vms/agent-registration"
HEALTHCHECK_API_URL_US="https://api.cloudanix.com/inbound/vms/agent-healthcheck"
HEALTHCHECK_API_URL_OTHER="https://api-{DC}.cloudanix.com/inbound/vms/agent-healthcheck"

OSSEC_HOME="/var/ossec"
OSSEC_CONFIG_FILE="$OSSEC_HOME/etc/ossec.conf"
# Written before the Wazuh agent is installed. It proves CDX installed the agent
# even if bootstrap dies before the CDX labels reach ossec.conf.
CDX_STATE_DIR="/var/lib/cdx-vmscan"
WAZUH_OWNED_MARKER="$CDX_STATE_DIR/wazuh-owned"
# Wazuh agent package shipped inside this package, one per CPU architecture
# (amd64 or arm64); the one matching this host is used.
HOST_ARCH=$(dpkg --print-architecture 2>/dev/null || echo unknown)
WAZUH_DEB="${CDX_VMSCAN_HOME:-/opt/cdx/vmscan}/vendor/wazuh-agent_${HOST_ARCH}.deb"

log() {
    echo "$(date +"%d/%m/%Y %H:%M:%S") $1: $2"
}

# apt-get that waits for the dpkg lock. Bootstrap may be started by the
# package's own postinst, while the parent apt/dpkg still holds the lock.
apt_get() {
    apt-get -o DPkg::Lock::Timeout=600 "$@"
}

# dpkg -i that waits for the dpkg lock (dpkg has no lock timeout of its own).
# Retries for up to 10 minutes, and only when the failure is a held lock.
dpkg_install() {
    local out i rc=0
    out=$(mktemp)
    for ((i = 0; i < 60; i++)); do
        rc=0
        dpkg -i "$@" >"$out" 2>&1 || rc=$?
        cat "$out"
        [[ $rc -eq 0 ]] && break
        grep -qi "lock" "$out" || break
        log "INFO" "dpkg is locked by another process, retrying in 10s"
        sleep 10
    done
    rm -f "$out"
    return "$rc"
}

# Print a log line at ERROR level and exit non-zero.
die() {
    log "ERROR" "$1"
    exit "${2:-1}"
}

# Extract a string value from a flat JSON document: json_get <json> <key>
json_get() {
    local json="$1" key="$2"
    echo "$json" \
        | grep -o "\"$key\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" \
        | head -n 1 \
        | sed "s/\"$key\"[[:space:]]*:[[:space:]]*\"//;s/\"\$//" \
        || true
}

# Build the DC-specific URL: dc_url <us_url> <other_url_template> <dc>
dc_url() {
    local us_url="$1" other_url="$2" dc_lower
    dc_lower=$(echo "$3" | tr '[:upper:]' '[:lower:]')
    if [[ "$dc_lower" == "us" ]]; then
        echo "$us_url"
    else
        echo "${other_url/\{DC\}/$dc_lower}"
    fi
}

# --- Init-system abstraction (systemd vs SysV) ---

# True only when systemd is actually PID 1 (the binary can exist inside
# containers/chroots where systemctl does not work).
has_systemd() {
    [[ -d /run/systemd/system ]] && command -v systemctl &>/dev/null
}

svc_daemon_reload() {
    if has_systemd; then
        systemctl daemon-reload
    fi
}

svc_enable() {
    if has_systemd; then
        systemctl enable "$1"
    elif command -v update-rc.d &>/dev/null; then
        update-rc.d "$1" defaults || true
    fi
}

svc_start() {
    if has_systemd; then systemctl start "$1"; else service "$1" start; fi
}

svc_restart() {
    if has_systemd; then systemctl restart "$1"; else service "$1" restart; fi
}

# Force-stop a service by signalling its process. auditd refuses the normal
# stop path, so only use this for auditd.
svc_kill() {
    if has_systemd; then
        systemctl kill "$1"
    else
        pkill -TERM -x "$1" 2>/dev/null || true
    fi
}

svc_is_enabled() {
    if has_systemd; then
        systemctl is-enabled "$1" &>/dev/null
    else
        compgen -G "/etc/rc2.d/S*$1" >/dev/null
    fi
}

# Verify the Wazuh manager port is reachable from this host.
check_port() {
    local port="$1"
    if nc -z -w 3 "$SERVER_IP" "$port" 2>/dev/null; then
        log "DEBUG" "Port $port is reachable on $SERVER_IP"
    else
        die "Port $port is not reachable on $SERVER_IP. Exiting..."
    fi
}

# --- Platform detection ---

# This package targets Debian/Ubuntu: apt is the only supported manager.
detect_package_manager() {
    if command -v apt-get &>/dev/null; then
        PACKAGE_MANAGER="apt"
    else
        die "Unsupported Package Manager: apt-get not found. Canceled Agent Installation"
    fi
}

detect_vm_details() {
    VM_OS="Unknown"
    VM_OS_VERSION="Unknown"
    if [[ -f /etc/os-release ]]; then
        # Read in a subshell-safe way so os-release vars don't leak (e.g. ID, NAME).
        VM_OS=$(. /etc/os-release && echo "${NAME:-Unknown}")
        VM_OS_VERSION=$(. /etc/os-release && echo "${VERSION_ID:-Unknown}")
    fi
    VM_ARCHITECTURE=$(uname -m 2>/dev/null || echo "Unknown")
    VM_PACKAGE_MANAGER="$PACKAGE_MANAGER"
    log "DEBUG" "VM Details - OS: $VM_OS, Version: $VM_OS_VERSION, Arch: $VM_ARCHITECTURE, Package Manager: $VM_PACKAGE_MANAGER"
}
