#!/bin/bash

set -o errexit
set -o nounset
if [[ "${TRACE-0}" == "1" ]]; then
  set -o xtrace
fi

if [[ "${1-}" =~ ^-*h(elp)?$ ]]; then
  echo 'Usage: ./linux-agent-registration.sh
This script would register the agent with server for VM Security Scanning.'
  exit
fi

if [[ ! -e "/var/ossec/monitor" ]]; then
    mkdir -p /var/ossec/monitor
fi

# --- Resource Type Constants ---
declare -A RESOURCE_TYPES=(
    [AWS]="aws-compute-ec2-instance"
    [AZURE]="azure-compute-vm-machine"
    [GCP]="gcp-compute-computeengine-instance"
    [OCI]="oci-compute-vm-instance"
)

# --- API URL Constants ---
# For non-US DCs, {DC} will be replaced with the lowercase DC value
AGENT_KEY_API_URL_US="https://api.cloudanix.com/inbound/vms/agent-registration"
AGENT_KEY_API_URL_OTHER="https://api-{DC}.cloudanix.com/inbound/vms/agent-registration"

# Function to log messages
log() {
  echo "$(date +"%d/%m/%Y %H:%M:%S") $1: $2"
}
# --- Init-system abstraction (systemd vs SysV) ---
# True only when systemd is actually PID 1.
has_systemd() {
  [[ -d /run/systemd/system ]] && command -v systemctl &>/dev/null
}
svc_stop() {
  if has_systemd; then systemctl stop "$1"; else service "$1" stop; fi
}
svc_restart() {
  if has_systemd; then systemctl restart "$1"; else service "$1" restart; fi
}

# Function to get agent name
get_agent_name(){
    AGENT_NAME=""
    if [[ "$CLOUD_TYPE" == "AWS" ]]; then
        STATUS_CODE=$(curl -s -I http://169.254.169.254/latest/meta-data/instance-id | grep HTTP | awk '{print $2}')
        if [[ "$STATUS_CODE" == "200" ]]; then
            AGENT_NAME=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
            IDENTITY_DOCUMENT=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document)
            ACCOUNT_ID=$(echo "$IDENTITY_DOCUMENT" | sed -n 's/.*"accountId"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
            REGION=$(echo "$IDENTITY_DOCUMENT" | sed -n 's/.*"region"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
            AGENT_UNIQUE_ID="arn:aws:ec2:$REGION:$ACCOUNT_ID:instance/$AGENT_NAME"
        else
            token=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
            headers=("X-aws-ec2-metadata-token: $token")
            status_code=$(curl -s -o /dev/null -w "%{http_code}" -H "${headers[@]}" "http://169.254.169.254/latest/meta-data/instance-id")
            if [[ "$status_code" -eq 200 ]]; then
                AGENT_NAME=$(curl -s -H "${headers[@]}" "http://169.254.169.254/latest/meta-data/instance-id")
                IDENTITY_DOCUMENT=$(curl -s -H "${headers[@]}" http://169.254.169.254/latest/dynamic/instance-identity/document)
                ACCOUNT_ID=$(echo "$IDENTITY_DOCUMENT" | sed -n 's/.*"accountId"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
                REGION=$(echo "$IDENTITY_DOCUMENT" | sed -n 's/.*"region"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
                AGENT_UNIQUE_ID="arn:aws:ec2:$REGION:$ACCOUNT_ID:instance/$AGENT_NAME"
            fi
        fi
        if [[ -z "$AGENT_NAME" ]]; then
            AGENT_NAME=$(ec2-metadata -i | awk '{print $2}')
            token=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
            headers=("X-aws-ec2-metadata-token: $token")
            IDENTITY_DOCUMENT=$(curl -s -H "${headers[@]}" http://169.254.169.254/latest/dynamic/instance-identity/document)
            ACCOUNT_ID=$(echo "$IDENTITY_DOCUMENT" | sed -n 's/.*"accountId"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
            REGION=$(echo "$IDENTITY_DOCUMENT" | sed -n 's/.*"region"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
            AGENT_UNIQUE_ID="arn:aws:ec2:$REGION:$ACCOUNT_ID:instance/$AGENT_NAME"
        fi
    elif [[ "$CLOUD_TYPE" == "AZURE" ]]; then
        AGENT_NAME=$(curl -H Metadata:true "http://169.254.169.254/metadata/instance/compute/vmId?api-version=2021-08-01&format=text")
        METADATA_URL="http://169.254.169.254/metadata/instance?api-version=2021-02-01"
        HEADER="Metadata:true"
        METADATA_JSON=$(curl -s -H "$HEADER" "$METADATA_URL&format=json")
        ACCOUNT_ID=$(echo "$METADATA_JSON" | sed -n 's/.*"subscriptionId"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
        RESOURCE_GROUP_NAME=$(echo "$METADATA_JSON" | sed -n 's/.*"resourceGroupName"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
        VM_NAME=$(echo "$METADATA_JSON" | sed -n 's/.*"name"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
        AGENT_UNIQUE_ID="/subscriptions/$ACCOUNT_ID/resourceGroups/$RESOURCE_GROUP_NAME/providers/Microsoft.Compute/virtualMachines/$VM_NAME"
    elif [[ "$CLOUD_TYPE" == "GCP" ]]; then
        AGENT_NAME=$(curl -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/id)
        METADATA_URL="http://169.254.169.254/computeMetadata/v1"
        HEADER="Metadata-Flavor: Google"
        ACCOUNT_ID=$(curl -s -H "$HEADER" "$METADATA_URL/project/project-id")
        ZONE_FULL=$(curl -s -H "$HEADER" "$METADATA_URL/instance/zone")
        INSTANCE_NAME=$(curl -s -H "$HEADER" "$METADATA_URL/instance/name")
        ZONE=$(basename "$ZONE_FULL")
        AGENT_UNIQUE_ID="projects/$ACCOUNT_ID/zones/$ZONE/instances/$INSTANCE_NAME"
    elif [[ "$CLOUD_TYPE" == "OCI" ]]; then
        OCI_METADATA_URL="http://169.254.169.254/opc/v2"
        OCI_HEADER="Authorization: Bearer Oracle"
        AGENT_NAME=$(curl -s -H "$OCI_HEADER" "$OCI_METADATA_URL/instance/id")
        ACCOUNT_ID=$(curl -s -H "$OCI_HEADER" "$OCI_METADATA_URL/instance/compartmentId")
        AGENT_UNIQUE_ID="$AGENT_NAME"
    else
        log "ERROR" "Unknown Cloud Type. Canceled Agent Registration"
        exit 1
    fi
}

configure_agent(){
# Removing existing Labels
CONFIG_FILE="/var/ossec/etc/ossec.conf"
BACKUP_FILE="${CONFIG_FILE}.bak"
cp "$CONFIG_FILE" "$BACKUP_FILE"
awk '
BEGIN { inside=0; skip=0; buffer="" }
/<ossec_config>/ { inside=1; skip=0; buffer=$0 ORS; next }
/<\/ossec_config>/ {
    buffer = buffer $0 ORS;
    if (skip == 0) {
        printf "%s", buffer;
    }
    inside = 0; skip = 0; buffer = "";
    next
}
{
    if (inside) {
        buffer = buffer $0 ORS;
        if ($0 ~ /account_id/ || $0 ~ /agent_unique_id/) {
            skip = 1;
        }
    } else {
        print;
    }
}
' "$BACKUP_FILE" > "$CONFIG_FILE"
rm -rf $BACKUP_FILE

# Adding Labels
new_block=$(cat <<EOF
<ossec_config>
  <labels>
    <label key="account_id">$ACCOUNT_ID</label>
    <label key="agent_unique_id">$AGENT_UNIQUE_ID</label>
  </labels>
</ossec_config>
EOF
)
printf "\n%s" "$new_block" >> /var/ossec/etc/ossec.conf

}

# Rewrite labels, preserving the non-sensitive dc label. CDX credentials are
# NOT written to labels (they would be sent to the manager and appear in
# event/alert payloads); they live in the root-only file /var/ossec/monitor/.cdx_auth.
configure_agent_cdx(){
    CONFIG_FILE="/var/ossec/etc/ossec.conf"
    BACKUP_FILE="${CONFIG_FILE}.bak"
    cp "$CONFIG_FILE" "$BACKUP_FILE"
    awk '
    BEGIN { inside=0; skip=0; buffer="" }
    /<ossec_config>/ { inside=1; skip=0; buffer=$0 ORS; next }
    /<\/ossec_config>/ {
        buffer = buffer $0 ORS;
        if (skip == 0) { printf "%s", buffer; }
        inside = 0; skip = 0; buffer = "";
        next
    }
    {
        if (inside) {
            buffer = buffer $0 ORS;
            if ($0 ~ /account_id/ || $0 ~ /agent_unique_id/) { skip = 1; }
        } else {
            print;
        }
    }
    ' "$BACKUP_FILE" > "$CONFIG_FILE"
    rm -rf "$BACKUP_FILE"

    new_block=$(cat <<EOF
<ossec_config>
  <labels>
    <label key="account_id">$ACCOUNT_ID</label>
    <label key="agent_unique_id">$AGENT_UNIQUE_ID</label>
    <label key="dc">$DC</label>
  </labels>
</ossec_config>
EOF
)
    printf "\n%s" "$new_block" >> /var/ossec/etc/ossec.conf
}

# Function to check for AWS
check_aws() {
  # Check for AWS instance metadata service
  if curl -s --connect-timeout 1 http://169.254.169.254/latest/meta-data/ &>/dev/null; then
    return 0
  fi

  # Check for AWS system UUID format in DMI
  if [ -f /sys/devices/virtual/dmi/id/product_uuid ]; then
    UUID=$(cat /sys/devices/virtual/dmi/id/product_uuid | cut -c-3)
    if [ "$UUID" = "EC2" ]; then
      return 0
    fi
  fi

  # Check for AWS-specific files or directories
  if [ -d /etc/amazon ]; then
    return 0
  fi

  return 1
}

# Function to check for GCP
check_gcp() {
  # Check for GCP metadata service
  if curl -s --connect-timeout 1 -H "Metadata-Flavor: Google" http://metadata.google.internal/ &>/dev/null; then
    return 0
  fi

  # Check for GCP-specific files
  if [ -f /etc/google_oslogin ]; then
    return 0
  fi

  # Check for GCP in product name
  if [ -f /sys/devices/virtual/dmi/id/product_name ]; then
    if grep -q "Google" /sys/devices/virtual/dmi/id/product_name; then
      return 0
    fi
  fi

  return 1
}

# Function to check for Azure
check_azure() {
  # Check for Azure instance metadata service
  if curl -s --connect-timeout 1 -H "Metadata: true" "http://169.254.169.254/metadata/instance?api-version=2021-02-01" &>/dev/null; then
    return 0
  fi

  # Check for Azure-specific files or directories
  if [ -f /var/lib/waagent/waagent.conf ] || [ -f /var/lib/waagent/provisioned ]; then
    return 0
  fi

  # Check for Azure in manufacturer or product name
  if [ -f /sys/devices/virtual/dmi/id/chassis_asset_tag ]; then
    if grep -q "Microsoft" /sys/devices/virtual/dmi/id/chassis_asset_tag; then
      return 0
    fi
  fi

  if [ -f /sys/devices/virtual/dmi/id/sys_vendor ]; then
    if grep -q -E "Microsoft|Azure" /sys/devices/virtual/dmi/id/sys_vendor; then
      return 0
    fi
  fi

  return 1
}

# Function to check for OCI (Oracle Cloud Infrastructure)
check_oci() {
  # Check for OCI instance metadata service
  if curl -s --connect-timeout 1 -H "Authorization: Bearer Oracle" "http://169.254.169.254/opc/v2/instance/id" &>/dev/null; then
    return 0
  fi

  # Check for OCI in chassis asset tag
  if [ -f /sys/devices/virtual/dmi/id/chassis_asset_tag ]; then
    if grep -q -i "OracleCloud" /sys/devices/virtual/dmi/id/chassis_asset_tag; then
      return 0
    fi
  fi

  return 1
}

cron_job_exists() {
    crontab -l | grep -Fxq "$1"
}

if check_aws; then
  CLOUD_TYPE="AWS"
elif check_gcp; then
  CLOUD_TYPE="GCP"
elif check_azure; then
  CLOUD_TYPE="AZURE"
elif check_oci; then
  CLOUD_TYPE="OCI"
else
  CLOUD_TYPE="UNKNOWN"
fi

get_agent_name

CONFIG_AGENT_NAME=$(grep -A 2 "<enrollment>" /var/ossec/etc/ossec.conf | grep "<agent_name>" | cut -d'>' -f2 | cut -d'<' -f1)


SERVER_IP=$(grep -A 5 "<server>" /var/ossec/etc/ossec.conf | grep "<address>" | sed -e 's/.*<address>\(.*\)<\/address>.*/\1/' | head -n 1)

if [ "$AGENT_NAME" != "$CONFIG_AGENT_NAME" ]; then

  # Read CDX credentials from the root-only file written at install time.
  # These are intentionally NOT stored in Wazuh labels (which leave the VM).
  CDX_AUTH_FILE="/var/ossec/monitor/.cdx_auth"

  if [[ -f "$CDX_AUTH_FILE" ]]; then
    # ---- On-demand re-registration via the CDX API ----
    log "DEBUG" "CDX auth file found. Fetching fresh agent key from platform API."

    CDX_TOKEN=""
    CDX_SERVICE_ACCOUNT=""
    CDX_DC=""
    # shellcheck disable=SC1090
    . "$CDX_AUTH_FILE"
    DC="$CDX_DC"

    if [[ -z "$CDX_TOKEN" || -z "$CDX_SERVICE_ACCOUNT" ]]; then
      log "ERROR" "Missing credentials in CDX auth file. Canceled Agent Registration"
      exit 1
    fi
    if [[ -z "$DC" ]]; then
      log "ERROR" "Missing 'dc' in CDX auth file. Canceled Agent Registration"
      exit 1
    fi

    # Build DC-specific API URL
    DC_LOWER=$(echo "$DC" | tr '[:upper:]' '[:lower:]')
    if [[ "$DC_LOWER" == "us" ]]; then
      AGENT_KEY_API_URL="$AGENT_KEY_API_URL_US"
    else
      AGENT_KEY_API_URL="${AGENT_KEY_API_URL_OTHER/\{DC\}/$DC_LOWER}"
    fi

    RESOURCE_TYPE="${RESOURCE_TYPES[$CLOUD_TYPE]:-}"

    AGENT_KEY_RESPONSE=$(curl -s -m 300 -X POST "$AGENT_KEY_API_URL" \
      -H "Content-Type: application/json" \
      -H "Authorization: Bearer $CDX_TOKEN" \
      -H "X-Cdx-Service-Account-Name: $CDX_SERVICE_ACCOUNT" \
      -d "{\"cloud_type\":\"$CLOUD_TYPE\",\"account_id\":\"$ACCOUNT_ID\",\"agent_unique_id\":\"$AGENT_UNIQUE_ID\",\"instance_id\":\"$AGENT_NAME\",\"dc\":\"$DC\",\"resource_type\":\"$RESOURCE_TYPE\"}" \
      2>/dev/null || true)

    if [[ -z "$AGENT_KEY_RESPONSE" ]]; then
      log "ERROR" "Failed to fetch agent key from platform API. Check network connectivity. Canceled Agent Registration"
      exit 1
    fi

    # Extract agent_key from JSON response
    AGENT_KEY=$(echo "$AGENT_KEY_RESPONSE" | grep -o '"agent_key"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/"agent_key"[[:space:]]*:[[:space:]]*"//;s/"$//')
    if [[ -z "$AGENT_KEY" ]]; then
      ERROR_MESSAGE=$(echo "$AGENT_KEY_RESPONSE" | grep -o '"errorMessage"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/"errorMessage"[[:space:]]*:[[:space:]]*"//;s/"$//')
      if [[ -n "$ERROR_MESSAGE" ]]; then
        log "ERROR" "$ERROR_MESSAGE"
      else
        log "ERROR" "Failed to extract agent_key from platform API response."
      fi
      exit 1
    fi

    # The API returns a base64 agent_key; the registration key is the wazuh portion
    DECODED_KEY=$(echo "$AGENT_KEY" | base64 -d 2>/dev/null || echo "")
    if [[ -z "$DECODED_KEY" ]]; then
      log "ERROR" "Failed to decode agent_key from platform API response."
      exit 1
    fi
    REGISTRATION_KEY=$(echo "$DECODED_KEY" | cut -d'_' -f6-)
    if [[ -z "$REGISTRATION_KEY" ]]; then
      log "ERROR" "Failed to extract registration key from agent_key."
      exit 1
    fi

    log "DEBUG" "Stopping Agent"
    svc_stop wazuh-agent

    log "DEBUG" "Deleting existing key"
    if [ -f "/var/ossec/etc/client.keys" ]; then
        rm /var/ossec/etc/client.keys
    fi

    configure_agent_cdx

    log "DEBUG" "Registering Agent with key from platform API"
    echo "y" | /var/ossec/bin/manage_agents -i "$REGISTRATION_KEY"

    sed -i "s|<agent_name>.*</agent_name>|<agent_name>${AGENT_NAME}</agent_name>|" /var/ossec/etc/ossec.conf

    log "DEBUG" "Restart Agent"
    svc_restart wazuh-agent

  else
    # ---- Legacy path: re-register via agent-auth ----
    log "DEBUG" "No CDX auth file found. Re-registering via agent-auth."

    log "DEBUG" "Stopping Agent"
    svc_stop wazuh-agent

    log "DEBUG" "Deleting existing key"
    if [ -f "/var/ossec/etc/client.keys" ]; then
        rm /var/ossec/etc/client.keys
    fi

    configure_agent
    log "DEBUG" "Register Agent"
    /var/ossec/bin/agent-auth -m "$SERVER_IP" -A "$AGENT_NAME"

    sed -i "s|<agent_name>.*</agent_name>|<agent_name>${AGENT_NAME}</agent_name>|" /var/ossec/etc/ossec.conf

    log "DEBUG" "Restart Agent"
    svc_restart wazuh-agent
  fi
fi